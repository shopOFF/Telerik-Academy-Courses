﻿namespace Homework
{
    public enum BatteryType
    {
        None,
        LiIon,
        NiMH,
        NiCd,
        LiPo,
        Li        
    }
}
