﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DivisibleBy7and3
{
    public static class ExtArray
    {
        public static void PrintDivisibleBy7And3(this int[] arrey)
        {
            var toPrint = arrey
                .Where(x => x % 3 == 0 && x % 7 == 0)
                .ToArray();

            foreach (var number in toPrint)
            {
                System.Console.WriteLine(number);
            }
        }
    }
}
