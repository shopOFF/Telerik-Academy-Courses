﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IEnumerableExt
{
    class Program
    {
        static void Main(string[] args)
        {
            var arrey = new int[] { 31, 102, 475, 808 };

            System.Console.WriteLine(arrey.Average());
        }
    }
}
