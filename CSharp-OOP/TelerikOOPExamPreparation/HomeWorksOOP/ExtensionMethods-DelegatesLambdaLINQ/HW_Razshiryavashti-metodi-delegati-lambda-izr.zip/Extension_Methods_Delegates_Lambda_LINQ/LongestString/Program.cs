﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LongestString
{
    class Program
    {
        static void Main(string[] args)
        {
            var stringsList = new List<string>() { "da", "dadab", "abcbcaabc", "abcd" };

            var longestString = stringsList
                .First(str => str.Length == stringsList.Max(st => st.Length));

            Console.WriteLine(longestString);
        }
    }
}
