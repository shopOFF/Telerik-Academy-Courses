﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringBuilderExt
{
    class Program
    {
        static void Main(string[] args)
        {
            var forSubstring = new StringBuilder();

            forSubstring.Append("This is the test");

            System.Console.WriteLine(forSubstring.Substring(12, 4));
        }
    }
}
