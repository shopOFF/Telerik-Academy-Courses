﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringBuilderExt
{
    using System.Text;
    public static class StringBuilderExtensions
    {
        public static StringBuilder Substring(this StringBuilder builder, int index, int lenght)
        {
            string forAppend = builder.ToString().Substring(index, lenght);
            builder.Clear();
            builder.Append(forAppend);

            return builder;
        }
    }
}
