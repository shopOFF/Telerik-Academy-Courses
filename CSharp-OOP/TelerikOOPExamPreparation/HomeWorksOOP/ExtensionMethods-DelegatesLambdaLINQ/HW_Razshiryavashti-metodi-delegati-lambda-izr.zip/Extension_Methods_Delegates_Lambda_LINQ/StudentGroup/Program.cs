﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentGroup
{
    class Program
    {
        static void Main(string[] args)
        {
            var studentsList = new List<Student>()
            {
                new Student("Ivan", "Simeonov", 364919, "0212345678", 1, "ivan@abv.bg"),
                new Student("Pesho", "Peshev", 304050, "0312332112", 1, "pesho@gmail.com"),
                new Student("Petyr", "Stefanov", 402106, "0216015591", 2, "petyr@gmail.com"),
                new Student("Stefan", "Stoqnov", 344306, "0411291116", 2, "goteniA@abv.bg"),
                new Student("Hristo", "Iordanov", 338122, "0278287212", 3, "hristoIor@gmail.com"),
                new Student("Stoqn", "Georgiev", 391806, "0378672345", 3, "StGeogriev@abv.bg"),
                new Student("Georgi", "Petkov", 371706, "0493296601", 4, "georgiPetkov@gmail.com"),
                new Student("Zahari", "Baharov", 334455, "0345398712", 4, "IvoAndonov@abv.bg")
            };

            // Add Marks
            studentsList[0].AddMark(2);
            studentsList[0].AddMark(2);
            studentsList[1].AddMark(6);
            studentsList[1].AddMark(4);
            studentsList[2].AddMark(6);
            studentsList[2].AddMark(6);
            studentsList[3].AddMark(2);
            studentsList[3].AddMark(2);
            studentsList[4].AddMark(4);
            studentsList[4].AddMark(5);
            studentsList[5].AddMark(3);
            studentsList[5].AddMark(3);
            studentsList[6].AddMark(5);
            studentsList[6].AddMark(6);
            studentsList[7].AddMark(2);
            studentsList[7].AddMark(2);
            studentsList[7].AddMark(2);

            // Task 9 
            var studetnsFromGroup2 = studentsList
                .Where(st => st.GroupNumber == 2)
                .OrderBy(st => st.FirstName)
                .ToList();

            foreach (var student in studetnsFromGroup2)
            {
                Console.WriteLine(student.FirstName + " " + student.LastName + "    Group: " + student.GroupNumber);
            }


            Console.WriteLine(new string('-', 60));
            Console.WriteLine();


            //Taks 10
            var secondListofStudentsGroup2 = studentsList.FindStudentsFromGroup2();

            foreach (var student in secondListofStudentsGroup2)
            {
                Console.WriteLine(student.FirstName + " " + student.LastName + "    Group: " + student.GroupNumber);
            }


            Console.WriteLine(new string('-', 60));
            Console.WriteLine();


            //Task 11
            var extractedStudents = studentsList
                .Where(st => st.Email.Contains("abv.bg"))
                .ToList();

            foreach (var student in extractedStudents)
            {
                Console.WriteLine(student.FirstName + " " + student.LastName + "   email: " + student.Email);
            }


            Console.WriteLine(new string('-', 60));
            Console.WriteLine();


            //Task 12
            var studentFromSofia = studentsList
                .Where(st => st.TelNumber[0] == '0' && st.TelNumber[1] == '2')
                .ToList();

            foreach (var student in studentFromSofia)
            {
                Console.WriteLine(student.FirstName + " " + student.LastName + "   tel: " + student.TelNumber);
            }


            Console.WriteLine(new string('-', 60));
            Console.WriteLine();


            // Task 13
            var studentsWith6 = studentsList
                .Where(st => st.Marks.Contains(6))
                .ToList();

            var anonymousType = new
            {
                FullName = studentsWith6.Select(st => st.FirstName + " " + st.LastName),
                Marks = studentsWith6.Select(st => st.Marks)
            };


            Console.WriteLine("Students  that have at least one mark Excellent (6):");

            foreach (var name in anonymousType.FullName)
            {
                Console.WriteLine(name);
            }


            Console.WriteLine(new string('-', 60));
            Console.WriteLine();


            // Task 14
            var weakStudents = studentsList.ExtraxtStudentsWithMark2();

            foreach (var student in weakStudents)
            {
                Console.Write(student.FirstName + " " + student.LastName + "   Marks: ");
                Console.WriteLine(string.Join(", ", student.Marks));
            }


            Console.WriteLine(new string('-', 60));
            Console.WriteLine();


            //Task 15 
            var studentsFrom06 = studentsList
                .Where(st => st.FacNumber.ToString().Substring(4, 2) == "06")
                .Select(st => st.Marks)
                .ToList();

            Console.WriteLine("Marks of students from 2006:");

            foreach (var marks in studentsFrom06)
            {
                Console.WriteLine(string.Join(", ", marks));
            }


            Console.WriteLine(new string('-', 60));
            Console.WriteLine();


            //Task 18
            var groupedStudents = studentsList.GroupBy(st => st.GroupNumber);

            int i = 1;
            foreach (var students in groupedStudents)
            {
                Console.WriteLine("Group {0}", i);
                foreach (var student in students)
                {
                    if (i == 0)
                    {
                        Console.WriteLine(student.GroupNumber);
                    }
                    Console.WriteLine(student.FirstName + " " + student.LastName);
                }
                Console.WriteLine();
                i++;
            }


            Console.WriteLine(new string('-', 60));
            Console.WriteLine();


            //Task 19
            studentsList.GroupedByGroupNumber();

        }
    }
}
