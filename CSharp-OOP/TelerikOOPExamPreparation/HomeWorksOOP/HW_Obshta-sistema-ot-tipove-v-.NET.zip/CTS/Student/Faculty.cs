﻿namespace Student
{
    public enum Faculty
    {
        History,
        ClassicalAndModernPhilology,
        MathematicsAndInformatics,
        Biology,
        Medicine
    }
}