﻿namespace Student
{
    public enum Speciality
    {
        Engineering,
        Medecine,
        Sports,
        Art
    }
}