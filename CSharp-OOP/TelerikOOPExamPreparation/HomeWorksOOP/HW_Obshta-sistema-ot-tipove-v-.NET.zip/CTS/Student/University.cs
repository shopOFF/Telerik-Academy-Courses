﻿namespace Student
{
    public enum University
    {
        Harvard,
        MIT,
        Stanford,
        Oxford
    }
}