﻿namespace P01.SchoolClasses.Interfaces
{
    public interface IComment
    {
        string Comment { get; }
    }
}
