﻿namespace P01.SchoolClasses.Models
{
    using System.Collections.Generic;
    using Interfaces;
    using Person;

    internal class Class : IComment
    {
        private string id;
        private List<Teacher> teachers;
        private List<Student> students;

        public Class(string id)
        {
            this.Id = id;
            this.teachers = new List<Teacher>();
            this.students = new List<Student>();
        }

        public Class(string id, string comment) : this(id)
        {
            this.Comment = comment;
        }


        public string Id { get; set; }

        public string Comment { get; }

        public List<Teacher> Teachers
        {
            get
            {
                return new List<Teacher>(this.teachers);
            }

            private set
            {
                this.teachers = value;
            }
        }

        public List<Student> Students
        {
            get
            {
                return new List<Student>(this.students);
            }

            private set
            {
                this.students = value;
            }
        }

        public void AddStudent(Student student)
        {
            this.students.Add(student);
        }

        public void RemoveStudent(Student student)
        {
            this.students.Remove(student);
        }

        public void AddTeacher(Teacher teacher)
        {
            this.teachers.Add(teacher);
        }

        public void RemoveTeacher(Teacher teacher)
        {
            this.teachers.Remove(teacher);
        }
    }
}
