﻿namespace P01.SchoolClasses.Models
{
    using System;
    using Interfaces;

    internal class Discipline : IComment
    {
        private string name;
        private int numberOfLectures;
        private int numberOfExcercises;

        public Discipline(string name, int numberOfLectures, int numberOfExcercises)
        {
            this.Name = name;
            this.NumberOfLectures = numberOfLectures;
            this.NumberOfExcercises = numberOfExcercises;
        }
        
        public string Name
        {
            get
            {
                return this.name;
            }

            private set
            {
                if (value == string.Empty)
                {
                    throw new ArgumentException("The name cannot be empty!");
                }
            }
        }

        public int NumberOfLectures
        {
            get
            {
                return this.numberOfLectures;
            }

            private set
            {
                if (value < 0)
                {
                    throw new ArgumentException("Number of lectures cannot be negative");
                }

                this.NumberOfLectures = value;
            }
        }

        public int NumberOfExcercises
        {
            get
            {
                return this.numberOfExcercises;
            }

            private set
            {
                if (value < 0)
                {
                    throw new ArgumentException("Number of excercises cannot be negative");
                }

                this.NumberOfExcercises = value;
            }
        }

        public string Comment { get; }
    }
}
