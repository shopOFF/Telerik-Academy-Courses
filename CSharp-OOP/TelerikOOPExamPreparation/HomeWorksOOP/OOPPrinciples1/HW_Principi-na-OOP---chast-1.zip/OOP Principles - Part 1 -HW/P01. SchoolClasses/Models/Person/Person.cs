﻿namespace P01.SchoolClasses.Models.Person
{
    using System;
    using Interfaces;

    internal abstract class Person : IComment
    {
        private string name;
        private string comment; 

        protected Person(string name)
        {
            this.Name = name;
        }

        public string Name
        {
            get
            {
                return this.name;
            }

            private set
            {
                if (value == string.Empty)
                {
                    throw new ArgumentException("The name cannot be empty!");
                }
            }
        }

        public string Comment
        {
            get
            {
                return this.comment;
            }

            private set
            {
                this.comment = value;
            }
        }
    }
}
