﻿namespace P01.SchoolClasses.Models.Person
{
    using System;

    internal class Student : Person
    {
        private int classNum;

        public Student(string name, int classNum) : base(name)
        {
            this.ClassNum = classNum;
        }

        public int ClassNum
        {
            get
            {
                return this.classNum;
            }

            private set
            {
                if (value < 0)
                {
                    throw new ArgumentException("Class number cannot be negative");
                }

                this.classNum = value;
            }

        }
    }
}
