﻿namespace P01.SchoolClasses.Models.Person
{
    using Interfaces;

    internal class Teacher : Person
    {
        public Teacher(string name) : base(name)
        {

        }
    }
}
