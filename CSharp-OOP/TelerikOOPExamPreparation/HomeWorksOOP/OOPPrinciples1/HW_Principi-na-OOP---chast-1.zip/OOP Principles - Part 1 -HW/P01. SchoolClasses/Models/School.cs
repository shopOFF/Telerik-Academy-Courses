﻿namespace P01.SchoolClasses.Models
{
    using System.Collections.Generic;

    internal class School
    {
        List<Class> classes;

        public School()
        {
            this.classes = new List<Class>();
        }

        public List<Class> Classes
        {
            get
            {
                return new List<Class>(this.classes);
            }

            private set
            {
                this.classes = value;
            }
        }

        public void AddClass(Class cClas)
        {
            this.Classes.Add(cClas);
        }

        public void RemoveClass(Class cClass)
        {
            this.Classes.Remove(cClass);
        }
    }
}
