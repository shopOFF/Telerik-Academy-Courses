﻿namespace P01.SchoolClasses
{
    class StartingPoint
    {
        static void Main()
        {

        }
    }
}
