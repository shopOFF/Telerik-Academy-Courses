﻿namespace P02.StudentsAndWorkers
{
    using System;

    public class ChangeConsoleColors
    {
        public static void ChangeColorIntoConsole(string task)
        {
            Console.BackgroundColor = ConsoleColor.Blue;
            Console.ForegroundColor = ConsoleColor.White;

            Console.WriteLine(task);

            Console.ResetColor();
        }
    }
}
