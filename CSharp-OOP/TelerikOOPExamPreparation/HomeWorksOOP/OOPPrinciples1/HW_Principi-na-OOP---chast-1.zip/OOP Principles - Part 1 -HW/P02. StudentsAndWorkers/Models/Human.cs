﻿namespace P02.StudentsAndWorkers.Models
{
    using static Validations.EmptyStringValidation;

    public abstract class Human
    {
        private string firstName;
        private string lastName;

        public Human(string firstName, string lastName)
        {
            this.FirstName = firstName;
            this.LastName = lastName;
        }

        public string LastName
        {
            get
            {
                return this.lastName;
            }

            private set
            {
                CheckForEmptyString(value, "Last name cannot be empty!");
                this.lastName = value;
            }
        }

        public string FirstName
        {
            get
            {
                return this.firstName;
            }

            private set
            {
                CheckForEmptyString(value, "First name cannot be empty!");
                this.firstName = value;
            }

        }
    }
}
