﻿namespace P02.StudentsAndWorkers.Models
{
    using Validations;

    public class Worker : Human
    {
        private decimal weekSalary;
        private int workingHoursPerDay;

        public Worker(string firstName, string lastName, decimal weekSalary, int workingHoursPerDay)
            : base(firstName, lastName)
        {
            this.WeekSalary = weekSalary;
            this.WorkHoursPerDay = workingHoursPerDay;
        }

        public int WorkHoursPerDay
        {
            get
            {
                return this.workingHoursPerDay;
            }
            private set
            {
                NegativeNumberValidation<int>.CheckForNegativeNumber(value, "Work hours cannot be negative");
                this.workingHoursPerDay = value;
            }
        }

        public decimal WeekSalary
        {
            get
            {
                return this.weekSalary;
            }

            private set
            {
                NegativeNumberValidation<decimal>.CheckForNegativeNumber(value, "Week salary cannot be negative");
                this.weekSalary = value;
            }
            
        }

        public decimal MoneyPerHour()
        {
            return this.WeekSalary / this.WorkHoursPerDay;
        }

        public override string ToString()
        {
            return string.Format("{0} {1} {2}", this.FirstName, this.LastName);
        }
    }
}
