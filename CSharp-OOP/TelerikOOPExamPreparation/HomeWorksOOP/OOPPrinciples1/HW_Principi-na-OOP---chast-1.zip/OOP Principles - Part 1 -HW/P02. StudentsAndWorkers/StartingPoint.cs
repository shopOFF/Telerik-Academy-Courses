﻿namespace P02.StudentsAndWorkers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using Models;

    public class StartingPoint
    {
        public static void Main()
        {
            var students = new List<Student>();
            students.Add(new Student("Jorko", "Dimitrov", 5));
            students.Add(new Student("Metodi", "Jechev", 2));
            students.Add(new Student("Toni", "Binkov", 3));
            students.Add(new Student("Haralampi", "Prokopiev", 4));
            students.Add(new Student("Mitio", "TheEyes", 5));
            students.Add(new Student("Qvor", "Georgiev", 6));
            students.Add(new Student("Maria", "Pincheva", 2));
            students.Add(new Student("Stanislava", "Metodieva", 3));
            students.Add(new Student("Elena", "Atanasaova", 5));
            students.Add(new Student("Huben", "Svilenov", 6));

            var studsByGrades = students.OrderBy(x => x.Grade);

            ChangeConsoleColors.ChangeColorIntoConsole("Students ordered by grades in ascending order:");
            
            foreach (var stud in studsByGrades)
            {
                Console.WriteLine(stud.ToString());
            }

            var workers = new List<Worker>();

            workers.Add(new Worker("Blagoi", "Dimitriev", 1246, 8));
            workers.Add(new Worker("Haralampi", "Petrov", 600, 6));
            workers.Add(new Worker("Tihomir", "Tapalev", 876, 8));
            workers.Add(new Worker("Yordan", "Filipiev", 1246, 5));
            workers.Add(new Worker("Konstantin", "Pentriev", 2000, 11));
            workers.Add(new Worker("Florian", "Ignatov", 1246, 8));
            workers.Add(new Worker("Ana", "Mitrova", 241, 4));
            workers.Add(new Worker("Vesela", "Elenova", 899, 10));
            workers.Add(new Worker("Traqn", "Firkov", 999, 8));
            workers.Add(new Worker("Jana", "Boqnova", 741, 6));

            var workersByMoneyPerHour = workers.Select(x => new
                                        {
                                            FullName = x.FirstName + " " + x.LastName,
                                            MoneyPerHour = x.MoneyPerHour()
                                        })
                                        .OrderByDescending(x => x.MoneyPerHour);

            ChangeConsoleColors.ChangeColorIntoConsole("Workers ordered by money per hour in descending order:");

            foreach (var worker in workersByMoneyPerHour)
            {
                Console.WriteLine("{0} {1:f2}", worker.FullName, worker.MoneyPerHour);
            }

            var humans = new List<Human>();
            humans.AddRange(students);
            humans.AddRange(workers);

            var sortedHumans = from human in humans
                         orderby human.FirstName, human.LastName
                         select human;

            ChangeConsoleColors.ChangeColorIntoConsole("Students and workers ordered by first and last name in ascending order:");

            foreach (var human in sortedHumans)
            {
                Console.WriteLine("{0} {1}", human.FirstName, human.LastName);
            }
        }
    }
}
