﻿namespace P02.StudentsAndWorkers.Validations
{
    using System;

    public class EmptyStringValidation
    {
        public static void CheckForEmptyString(string value, string message)
        {
            if (string.IsNullOrEmpty(value))
            {
                throw new ArgumentNullException(message);
            }
        }

    }
}
