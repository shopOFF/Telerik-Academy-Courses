﻿namespace P02.StudentsAndWorkers.Validations
{
    using System;

    public class NegativeNumberValidation<T> where T : IComparable
    {
        public static void CheckForNegativeNumber(T value, string message)
        {
            if ((dynamic)value < 0)
            {
                throw new ArgumentException(message);
            }
        }
    }
}
