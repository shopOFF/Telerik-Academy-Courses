﻿namespace P03.AnimalHierarchy.Enums
{
    public enum Gender
    {
        Male,
        Female,
        Other
    }
}
