﻿namespace P03.AnimalHierarchy.Interfaces
{
    public interface ISound
    {
        void ProduceSound();
    }
}
