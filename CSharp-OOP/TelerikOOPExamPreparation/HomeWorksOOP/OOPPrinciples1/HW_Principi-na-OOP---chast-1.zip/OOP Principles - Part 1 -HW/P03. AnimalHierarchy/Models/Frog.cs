﻿namespace P03.AnimalHierarchy.Models
{
    using System;
    using Enums;
    using Interfaces;

    public class Frog : Animal, ISound
    {
        public Frog(int age, string name, Gender gender) 
            : base(age, name, gender)
        {
        }

        public override void ProduceSound()
        {
            Console.WriteLine("Kwa-kwa");
        }
    }
}
