﻿namespace P03.AnimalHierarchy.Models
{
    using System;
    using Enums;
    using Interfaces;

    public class Kitten : Animal, ISound
    {
        public Kitten(int age, string name) 
            : base(age, name, Gender.Female)
        {
        }

        public override void ProduceSound()
        {
            Console.WriteLine("Kitten says miay");
        }
    }
}
