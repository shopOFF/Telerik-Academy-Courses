﻿namespace P03.AnimalHierarchy
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using Enums;
    using Models;

    public class StartingPoint
    {
        static void Main()
        {
            List<Animal> animals = new List<Animal>();
            animals.Add(new Dog(6, "Miki", Gender.Male));
            animals.Add(new Frog(3, "Tin", Gender.Other));
            animals.Add(new Kitten(12, "Tom"));
            animals.Add(new Tomcat(10, "Mia"));

            var avarageAge = animals.Sum(x => x.Age) / (double)animals.Count;
            Console.WriteLine("Avarage age: " + avarageAge);
        }
    }
}
