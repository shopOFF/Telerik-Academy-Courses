﻿namespace Dealership.Contracts
{
    public interface ICar
    {
        int Seats { get; }
    }
}
