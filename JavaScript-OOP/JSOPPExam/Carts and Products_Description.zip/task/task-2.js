/* globals module */

"use strict";

function solve(){
    class Product{
        /* .... */
    }

    class ShoppingCart {
        /* .... */
    }
    return {
        Product, ShoppingCart
    };
}

module.exports = solve;