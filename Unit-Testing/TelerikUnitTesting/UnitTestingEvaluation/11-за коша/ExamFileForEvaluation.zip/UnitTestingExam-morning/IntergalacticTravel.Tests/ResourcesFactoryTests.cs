﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace IntergalacticTravel.Tests
{
    [TestClass]
    public class ResourcesFactoryTests
    {
        [TestMethod]
        public void TestMethod1()
        {

        }
    }
}
