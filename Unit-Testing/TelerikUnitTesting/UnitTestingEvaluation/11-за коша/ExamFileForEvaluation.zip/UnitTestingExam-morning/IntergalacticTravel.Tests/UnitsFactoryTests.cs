﻿extern alias custom;
using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using IntergalacticTravel;


namespace IntergalacticTravel.Tests
{
    [TestClass]
    public class UnitsFactoryTests
    {
        [TestMethod]
        public void UnitFactory_PassingAProcyonConstructionCommand_ExpectingAProcyonObject()
        {
            // Arrange
            var command = "create unit Procyon Gosho 1";
            
            // Act


            // Assert


        }
    }
}
