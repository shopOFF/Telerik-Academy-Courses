﻿namespace IntergalacticTravel.Tests.ResourcesFactory.Tests.Mocks
{
    using System.Collections.Generic;
    using ResourcesFactory = IntergalacticTravel.ResourcesFactory;

    public class MockedResourcesFactory : ResourcesFactory
    {
        

        
    }
}
