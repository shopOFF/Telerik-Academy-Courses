﻿namespace IntergalacticTravel.Tests.TeleportStation.Tests
{
    using NUnit.Framework;

    [TestFixture]
    public class Constructor_Should
    {
        [Test]
        public void SetUp_OwnerGalacticMapLocation_WhenANewTeleportStationsIsCreated_WithValidParameters()
        {

        }
    }
}


//set up all of the provided fields (owner, galacticMap & location), when a new TeleportStation is created with valid parameters passed to the constructor.