﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IntergalacticTravel.Tests.BusninessOwnerTests
{
    [TestFixture]
    class CollectProfits_Should
    {

        [Test]
        public void IncreaseOwnersResourcesByTotalAmountOfResourcesFromTeleportStationsThatAreInHisPossession()
        {
            //TODO
        }
    }
}
