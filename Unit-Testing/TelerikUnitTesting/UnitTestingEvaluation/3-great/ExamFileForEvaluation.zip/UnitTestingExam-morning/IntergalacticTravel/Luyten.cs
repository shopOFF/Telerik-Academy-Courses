﻿namespace IntergalacticTravel
{
    /// <summary>
    /// Imma dummy class
    /// </summary>
    internal class Luyten : Unit
    {
        public Luyten(int identificationNumber, string nickName) : base(identificationNumber, nickName)
        {
        }
    }
}
