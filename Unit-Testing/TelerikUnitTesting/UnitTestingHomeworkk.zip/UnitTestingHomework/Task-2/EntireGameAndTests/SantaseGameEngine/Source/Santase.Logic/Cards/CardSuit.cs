﻿namespace Santase.Logic.Cards
{
    public enum CardSuit
    {
        Club = 0, // ♣
        Diamond = 1, // ♦
        Heart = 2, // ♥
        Spade = 3 // ♠
    }
}
