﻿using System;
using System.Linq;
using System.Collections.Generic;
using NUnit.Framework;
using Telerik.JustMock;

using Cars.Contracts;
using Cars.Data;
using Cars.Models;

namespace Tests.CarsJustMock
{
    [TestFixture]
    public class CarsJustMock
    {
        [Test]
        public void CarsRepoConstructor_ShouldArgumentNullException_IfTakeNull()
        {
            Assert.Throws<ArgumentNullException>(() => new CarsRepository(null));
        }
        [Test]
        public void CarsRepoData_ShouldTotalCarsProperly()
        {
            var collection = Mock.Create<IList<Car>>();
            Mock.Arrange(() => collection.Count).Occurs(2);

            var Db = Mock.Create<IDatabase>();
            Mock.Arrange(() => Db.Cars).Returns(collection);

            var carRepo = new CarsRepository(Db);

            var act1 = carRepo.TotalCars;
            var act2 = carRepo.TotalCars;

            Mock.Assert(collection);
        }

        [Test]
        public void CarsRepoAdd_ShouldArgumentNullException_IfCarIsNull()
        {
            var r = new CarsRepository();

            Assert.Throws<ArgumentNullException>(() => r.Add(null));
        }

        [Test]
        public void CarRepoAdd_ShouldProperlyAddACar()
        {
            var Car = Mock.Create<Car>();

            var Collection = Mock.Create<IList<Car>>();
            Mock.Arrange(() => Collection.Add(Car)).Occurs(3);

            var Db = Mock.Create<IDatabase>();
            Mock.Arrange(() => Db.Cars).Returns(Collection);

            var r = new CarsRepository(Db);

            r.Add(Car);
            r.Add(Car);
            r.Add(Car);

            Mock.Assert(Collection);
        }

        [Test]
        public void CarsRepoRemove_ShouldArgumentNullException_IfCarIsNull()
        {
            var r = new CarsRepository();

            Assert.Throws<ArgumentNullException>(() => r.Remove(null));
        }

        [Test]
        public void CarsRepoRemove_ShouldRemoveCarProperly()
        {
            var mockCar = Mock.Create<Car>();

            var Collection = Mock.Create<IList<Car>>();
            Mock.Arrange(() => Collection.Remove(mockCar)).Occurs(2, "why only once?");

            var Db = Mock.Create<IDatabase>();
            Mock.Arrange(() => Db.Cars).Returns(Collection);

            var repo = new CarsRepository(Db);

            //ACT
            repo.Remove(mockCar);
            repo.Remove(mockCar);

            //ASSERT
            Mock.Assert(Collection);
        }

        [Test]
        public void CarsRepoAll_shouldProperslyReturnResult()
        {
            var Collection = new List<Car>();

            var car = Mock.Create<Car>();
            Collection.Add(car);

            var Db = Mock.Create<IDatabase>();
            Mock.Arrange(() => Db.Cars).Returns(Collection);

            var r = new CarsRepository(Db);

            var expectedList = new List<Car>(Collection);

            bool areEquals = expectedList.TrueForAll(x => r.All().Contains(x));

            Assert.IsTrue(areEquals);
        }

        [Test]
        public void CarsRepoSearch_ShouldReturnOriginalCollection_IfConditionIsNull()
        {
            
            var numberOfCars = 18;
            var collection = new List<Car>();

            for (int i = 0; i < numberOfCars; i++)
            {
                var mockCar = Mock.Create<Car>();
                collection.Add(mockCar);
            }

            var Db = Mock.Create<IDatabase>();
            Mock.Arrange(() => Db.Cars).Returns(collection);

            var r = new CarsRepository(Db);

            var expected = collection;

            var result = r.Search(null).ToList();

            var areEquls = expected.Count == result.Count;

            if (areEquls)
            {
                for (int i = 0; i < numberOfCars; i++)
                {                 
                        areEquls &= expected[i].Equals(result[i]);             
                }
            }

            Assert.IsTrue(areEquls);
        }

        [Test]
        public void CarsRepoSearch_ShouldReturnOriginalCollection_IfConditionIsStringEmpty()
        {
            var numberOfCars = 10;

            var collection = new List<Car>();

            for (int i = 0; i < numberOfCars; i++)
            {
                var mockCar = Mock.Create<Car>();
                collection.Add(mockCar);
            }

            var Db = Mock.Create<IDatabase>();
            Mock.Arrange(() => Db.Cars).Returns(collection);

            var r = new CarsRepository(Db);

            var expected = collection;

            var result = r.Search(string.Empty).ToList();

            var areEquls = expected.Count == result.Count;

            if (areEquls)
            {
                for (int i = 0; i < numberOfCars; i++)
                {
                        areEquls &= expected[i].Equals(result[i]);                
                }
            }

            Assert.IsTrue(areEquls);
        }

        [Test]
        public void CarsRepoSearch_ShouldReturnEmptyCollection_IfNoMatch()
        {
            int MagicNumberThatScaleCarsCreated = 5;
            var valid = "valid";
            var notValid = "NotValid";
            var collection = new List<Car>();
            var car = new Car();


            for (int i = 0; i < MagicNumberThatScaleCarsCreated; i++)
            {
                car.Id = i;
                car.Year = 1980;
                car.Make = notValid;
                car.Model = notValid;
                collection.Add(car);
            }

            var Db = Mock.Create<IDatabase>();
            Mock.Arrange(() => Db.Cars).Returns(collection);

            var r = new CarsRepository(Db);

            Assert.AreEqual(0, r.Search(valid).Count);
        }

    }
}
