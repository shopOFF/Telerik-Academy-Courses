﻿namespace Cars.Tests.JustMock
{
    using System;
    using System.Linq;
    using System.Collections.Generic;
    using Moq;
    using NUnit.Framework;

    using Data;
    using Models;

    [TestFixture]
    public class CarRepoTests
    {
        private static IList<Car> cars = new List<Car>() {
                (new Mock<Car>()).Object,
                (new Mock<Car>()).Object,
                (new Mock<Car>()).Object,
                (new Mock<Car>()).Object
            };


        [Test]
        public void CarsRepository_AddShouldThrow_WhenNullIsPassed()
        {
            var carRepo = new CarsRepository();
            Assert.Throws<ArgumentException>(() => carRepo.Add(null));
        }
        [Test]
        public void CarsRepository_AddCarr_ShouldAddCorrectly()
        {
            var carRepo = new CarsRepository();
            var mockedCar = new Mock<Car>();
            var initialCount = carRepo.TotalCars;
            carRepo.Add(mockedCar.Object);
            var finalCount = carRepo.TotalCars;
            Assert.AreEqual(initialCount + 1, finalCount);
        }

        [Test]
        public void CarsRepository_RemoveShouldThrow_WhenNullIsPassed()
        {
            var carRepo = new CarsRepository();
            Assert.Throws<ArgumentException>(() => carRepo.Remove(null));
        }

        [Test]
        public void CarsRepository_RemoveCar_ShouldRemoveCorrectly()
        {
            var carRepo = new CarsRepository();
            var mockedCar = new Mock<Car>();
            var initialCount = carRepo.TotalCars;

            carRepo.Add(mockedCar.Object);
            carRepo.Remove(mockedCar.Object);
            var finalCount = carRepo.TotalCars;

            Assert.AreEqual(initialCount, finalCount);
        }

        [Test]
        public void CarsRepository_GetByInvalidId_ShouldThrowArgumentException()
        {
            var carRepo = new CarsRepository();

            Assert.Throws<ArgumentException>(() => carRepo.GetById(5));
        }

        [Test]
        public void CarsRepository_GetByValidId_ShouldReturnTheCorrectCar()
        {
            var carRepo = new CarsRepository();
            var car = new Car { Id = 1, Make = "Mazda", Model = "7", Year = 2012 };

            carRepo.Add(car);

            Assert.AreEqual(car, carRepo.GetById(car.Id));
        }

    

        [Test]
        public void CarsRepository_SortByMake_ShouldShouldSortCorrectly()
        {
            var carRepo = new CarsRepository();

            foreach (var car in cars)
            {
                carRepo.Add(car);
            }

            Assert.AreEqual(cars.OrderBy(c => c.Make).ToList(), carRepo.SortedByMake());
        }

        [Test]
        public void CarsRepository_SortByYear_ShouldSortCorrectly()
        {
            var carRepo = new CarsRepository();

            foreach (var car in cars)
            {
                carRepo.Add(car);
            }

            Assert.AreEqual(cars.OrderBy(c => c.Year).ToList(), carRepo.SortedByYear());
        }

        [Test]
        public void CarsRepository_ShouldReturnAllCars_WhenNullIsPassed()
        {
            var carRepo = new CarsRepository();

            foreach (var car in cars)
            {
                carRepo.Add(car);
            }

            Assert.AreEqual(cars, carRepo.Search(null));
        }

        [Test]
        public void CarsRepository_ShouldReturnAllCars_WhenEmptyIsPassed()
        {
            var carRepo = new CarsRepository();

            foreach (var car in cars)
            {
                carRepo.Add(car);
            }

            Assert.AreEqual(cars, carRepo.Search(string.Empty));
        }


    }
}
