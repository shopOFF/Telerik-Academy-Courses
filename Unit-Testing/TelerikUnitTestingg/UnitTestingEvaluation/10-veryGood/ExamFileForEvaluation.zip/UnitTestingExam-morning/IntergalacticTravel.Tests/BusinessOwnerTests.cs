﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Moq;
using NUnit.Framework;
using IntergalacticTravel.Contracts;

namespace IntergalacticTravel.Tests
{  [TestFixture]
  public  class BusinessOwnerTests
    {
       // [Test]
       // public void CollectProfits_WhenInvoked_Should_IncreaseTheOwnerResources()
      //  {
       //     var Bowner1 = new BusinessOwner(12, "Jabaa", new List<ITeleportStation> { });
        //    var mcLocation = new Mock<ILocation>();
       //     var mcPath = new Mock<IPath>();
        //    var mcTpStation = new Mock<TeleportStation>(Bowner1,new List<IPath> { mcPath.Object},mcLocation.Object);
        //    var Profit = new Resources(5, 10, 20);
         //   mcTpStation.Setup(tp => tp.PayProfits(Bowner1)).Returns(Profit);
         //   var Bowner = new BusinessOwner(12, "Jabaa",new List<ITeleportStation> { mcTpStation.Object });
            
           // mcTpStation.Setup(tp => tp.PayProfits(Bowner)).Returns(Profit);

        //    Bowner1.CollectProfits();
          //  Assert.AreEqual((uint)5, Bowner.Resources.BronzeCoins);
      //  }
    }
}
