﻿using System;
using System.Text;
using System.Collections.Generic;
using NUnit.Framework;
using IntergalacticTravel;

namespace IntergalacticTravel.Tests.UnitsFactory.TeleportStation.Test
{
    [TestClass]
    public class UnitsFactory
    {
        [TestMethod]
        public UnitsFactory()
        {
                        
        }
    }
}
