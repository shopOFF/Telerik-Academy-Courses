﻿namespace IntergalacticTravel.Tests
{
    using System;
    using NUnit.Framework;

    [TestClass]
    public class UnitsFactoryTest
    {
        [TestMethod]
        public void GetUnit_ShouldReturnNewProcyonUnit()
        {

        }
    }
}
