﻿namespace IntergalacticTravel
{
    /// <summary>
    /// Imma dummy class
    /// </summary>
    internal class Procyon : Unit
    {
        public Procyon(int identificationNumber, string nickName) : base(identificationNumber, nickName)
        {
        }
    }
}
