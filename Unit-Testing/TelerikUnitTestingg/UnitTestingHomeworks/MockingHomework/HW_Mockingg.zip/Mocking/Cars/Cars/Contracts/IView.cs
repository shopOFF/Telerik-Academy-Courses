﻿namespace Cars.Contracts
{
    public interface IView
    {
        object Model { get; }
    }
}
