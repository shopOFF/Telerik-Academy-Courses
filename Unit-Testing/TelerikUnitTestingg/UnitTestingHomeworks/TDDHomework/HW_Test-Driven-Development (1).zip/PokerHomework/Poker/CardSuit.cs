﻿namespace Poker
{
    public enum CardSuit
    {
        Clubs = 1,    // ♣ u2663
        Diamonds = 2, // ♦ u2666
        Hearts = 3,   // ♥ u2665
        Spades = 4    // ♠ u2660
    }
}
