﻿using Moq;
using NUnit.Framework;
using PackageManager.Commands;
using PackageManager.Core.Contracts;
using PackageManager.Enums;
using PackageManager.Models.Contracts;
using PackageManager.Tests.Commands.Mocks;
using System;

namespace PackageManager.Tests.Commands.InstallCommandTests
{
    [TestFixture]
    public class Constructor_Should
    {
        [Test]
        public void ThrowAnArgumentNullException_WhenNullInstallerIsPassed()
        {
            //Arrange & Act
            IInstaller<IPackage> invalidInstaller = null;
            var packageStub = new Mock<IPackage>();

            //Assert
            Assert.Throws<ArgumentNullException>(() => new InstallCommand(invalidInstaller, packageStub.Object));
        }

        [Test]
        public void ThrowAnArgumentNullException_WhenNullPackageIsPassed()
        {
            //Arrange & Act
            var installer = new Mock<IInstaller<IPackage>>();
            IPackage invalidPackage = null;

            //Assert
            Assert.Throws<ArgumentNullException>(() => new InstallCommand(installer.Object, invalidPackage));
        }

        [Test]
        public void NotThrowAnArgumentNullException_WhenvalidInstallerAndPackageIsPassed()
        {
            //Arrange & Act
            var installer = new Mock<IInstaller<IPackage>>(); ;
            var package = new Mock<IPackage>();

            //Assert
            Assert.DoesNotThrow(() => new InstallCommand(installer.Object, package.Object));
        }

        [Test]
        public void SetInstallerAndPackage_WhenvalidInstallerAndPackageIsPassed()
        {
            //Arrange
            var installer = new Mock<IInstaller<IPackage>>(); ;
            var package = new Mock<IPackage>();

            //Act
            var sut = new InstallCommandMock(installer.Object, package.Object);

            //Assert
            Assert.AreSame(installer.Object, sut.InstallerExposed);
            Assert.AreSame(package.Object, sut.PackageExposed);
        }

        [Test]
        public void SetInstallerOperation_WhenValidInstallerAndPackagePassed()
        {
            //Arrange & Act
            var installer = new Mock<IInstaller<IPackage>>(); ;
            var package = new Mock<IPackage>();

            //Act
            var sut = new InstallCommand(installer.Object, package.Object);

            //Assert
            installer.VerifySet(x => x.Operation = InstallerOperation.Install);
        }
    }
}
