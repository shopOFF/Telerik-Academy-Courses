﻿using Moq;
using NUnit.Framework;
using PackageManager.Commands;
using PackageManager.Core.Contracts;
using PackageManager.Models.Contracts;

namespace PackageManager.Tests.Commands.InstallCommandTests
{
    [TestFixture]
    public class Execute_Should
    {
        [Test]
        public void CallPerformOperationOnce_WhenValidInstallerAndPackageArePassed()
        {
            //Arrange & Act
            var installer = new Mock<IInstaller<IPackage>>(); ;
            var package = new Mock<IPackage>();
            var sut = new InstallCommand(installer.Object, package.Object);

            //Act
            sut.Execute();

            //Assert
            installer.Verify(x => x.PerformOperation(package.Object), Times.Once);
        }
    }
}
