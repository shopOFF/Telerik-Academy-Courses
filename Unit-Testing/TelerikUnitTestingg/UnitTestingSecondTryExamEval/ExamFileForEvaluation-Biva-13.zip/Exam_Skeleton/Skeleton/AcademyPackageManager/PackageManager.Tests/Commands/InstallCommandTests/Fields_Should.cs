﻿using Moq;
using NUnit.Framework;
using PackageManager.Core.Contracts;
using PackageManager.Models.Contracts;
using PackageManager.Tests.Commands.Mocks;

namespace PackageManager.Tests.Commands.InstallCommandTests
{
    [TestFixture]
    class Fields_Should
    {
        [Test]
        public void SetInstaller_WhenValidInstallerPassed()
        {
            //Arrange & Act
            var installerStub = new Mock<IInstaller<IPackage>>();
            var packageStub = new Mock<IPackage>();
            var sut = new InstallCommandMock(installerStub.Object, packageStub.Object);

            //Assert
            Assert.AreSame(installerStub.Object, sut.InstallerExposed);
        }

        [Test]
        public void SetPackage_WhenValidPackagePassed()
        {
            //Arrange & Act
            var installerStub = new Mock<IInstaller<IPackage>>();
            var packageStub = new Mock<IPackage>();
            var sut = new InstallCommandMock(installerStub.Object, packageStub.Object);

            //Assert
            Assert.AreSame(packageStub.Object, sut.PackageExposed);
        }
    }
}
