﻿using PackageManager.Commands;
using PackageManager.Core.Contracts;
using PackageManager.Models.Contracts;

namespace PackageManager.Tests.Commands.Mocks
{
    internal class InstallCommandMock : InstallCommand
    {
        public InstallCommandMock(IInstaller<IPackage> installer, IPackage package) 
            : base(installer, package)
        {
        }

        internal IInstaller<IPackage> InstallerExposed
        {
            get
            {
                return this.installer;
            }
        }

        internal IPackage PackageExposed
        {
            get
            {
                return this.package;
            }
        }
    }
}
