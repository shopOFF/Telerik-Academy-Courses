﻿using Moq;
using NUnit.Framework;
using PackageManager.Core;
using PackageManager.Core.Contracts;
using PackageManager.Enums;
using PackageManager.Models.Contracts;
using PackageManager.Repositories.Contracts;
using System.Collections.Generic;

namespace PackageManager.Tests.Core.PackageInstallerTests
{
    [TestFixture]
    public class Constructor_Should
    {
        [Test]
        public void RestoreEachPackage_WhenValidProjectWithDependenciesIsPassed()
        {
            //Arrange & Act
            var downloadStub = new Mock<IDownloader>();
            var projectStub = new Mock<IProject>();

            var packageRepositoryStub = new Mock<PackageRepository<IPackage>>();
            var packageStub = new Mock<IPackage>();
            packageStub.SetupGet(x => x.Dependencies).Returns(new List<IPackage>());

            var listOfMocks = new List<IPackage>() { packageStub.Object, packageStub.Object };
            packageRepositoryStub.Setup(x => x.GetAll()).Returns(listOfMocks);

            projectStub.SetupGet(x => x.PackageRepository).Returns(packageRepositoryStub.Object);

            //Act
            var sut = new PackageInstaller(downloadStub.Object, projectStub.Object);

            //Assert
            Assert.AreEqual(InstallerOperation.Install, sut.Operation); //RestorePackages sets Operation to Install each time
        }
    }
}
