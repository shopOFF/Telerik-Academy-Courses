﻿using Moq;
using NUnit.Framework;
using PackageManager.Core;
using PackageManager.Core.Contracts;
using PackageManager.Models.Contracts;
using PackageManager.Repositories.Contracts;
using System.Collections.Generic;

namespace PackageManager.Tests.Core.PackageInstallerTests
{
    [TestFixture]
    public class PerformOperation_Should
    {
        [Test]
        public void CallDownloadTwoTimesAndRemoveOnce_WhenEmptyDependencyListIsPassed()
        {
            // Arrange & Act
            var downloaderMock = new Mock<IDownloader>();
            var projectStub = new Mock<IProject>();

            var packageMock = new Mock<IPackage>();
            packageMock.SetupGet(x => x.Dependencies).Returns(new List<IPackage>());

            var listOfPackages = new List<IPackage>() { packageMock.Object };

            var packageRepositoryStub = new Mock<PackageRepository<IPackage>>();
            packageRepositoryStub.Setup(x => x.GetAll()).Returns(listOfPackages);

            projectStub.SetupGet(x => x.PackageRepository).Returns(packageRepositoryStub.Object);

            var sut = new PackageInstaller(downloaderMock.Object, projectStub.Object);

            //Asssert
            downloaderMock.Verify(x => x.Download(It.IsAny<string>()), Times.Exactly(2));
            downloaderMock.Verify(x => x.Remove(It.IsAny<string>()), Times.Once);
        }

        [TestCase(1)]
        [TestCase(5)]
        public void CallDownloadAndRemove_WhenDependencyListIsPassed(int dependencies)
        {
            // Arrange & Act
            var downloaderMock = new Mock<IDownloader>();
            var projectStub = new Mock<IProject>();


            var packageMock = new Mock<IPackage>();

            var dependenciesList = new List<IPackage>();
            var dependencyMock = new Mock<IPackage>();
            dependencyMock.SetupGet(x => x.Dependencies).Returns(new List<IPackage>());

            for (int i = 0; i < dependencies; i++)
            {
                dependenciesList.Add(dependencyMock.Object);
            }

            packageMock.SetupGet(x => x.Dependencies).Returns(dependenciesList);

            var listOfPackages = new List<IPackage>() { packageMock.Object };

            var packageRepositoryStub = new Mock<PackageRepository<IPackage>>();
            packageRepositoryStub.Setup(x => x.GetAll()).Returns(listOfPackages);

            projectStub.SetupGet(x => x.PackageRepository).Returns(packageRepositoryStub.Object);

            var sut = new PackageInstaller(downloaderMock.Object, projectStub.Object);

            //Asssert
            downloaderMock.Verify(x => x.Download(It.IsAny<string>()), Times.Exactly(dependencies * 2  + 2));
            downloaderMock.Verify(x => x.Remove(It.IsAny<string>()), Times.Exactly(dependencies +  1));
        }
    }
}
