﻿using Moq;
using NUnit.Framework;
using PackageManager.Enums;
using PackageManager.Models;
using PackageManager.Models.Contracts;
using System;

namespace PackageManager.Tests.Models.PackageTests
{
    [TestFixture]
    public class CompareTo_Should
    {
        [Test]
        public void ThrowAnArgumentNullException_WhenInvlidPackagePassed()
        {
            // Arrange 
            const string validName = "Valid name";
            var versionStub = new Mock<IVersion>();
            IPackage invalidPackage = null;
            var sut = new Package(validName, versionStub.Object);

            //Assert & Act
            Assert.Throws<ArgumentNullException>(() => sut.CompareTo(invalidPackage));
        }

        [Test]
        public void NotThrowAnException_WhenVlidPackagePassed()
        {
            // Arrange 
            const string validName = "Valid name";
            const int major = 1;
            const int minor = 2;
            const int patch = 3;
            const VersionType versionType = VersionType.alpha;

            var versionStub = new Mock<IVersion>();
            versionStub.SetupGet(x => x.Major).Returns(major);
            versionStub.SetupGet(x => x.Minor).Returns(minor);
            versionStub.SetupGet(x => x.Patch).Returns(patch);
            versionStub.SetupGet(x => x.VersionType).Returns(versionType);

            var packageStub = new Mock<IPackage>();
            packageStub.SetupGet(x => x.Name).Returns(validName);
            packageStub.SetupGet(x => x.Version).Returns(versionStub.Object);

            var sut = new Package(validName, versionStub.Object);

            //Assert & Act
            Assert.DoesNotThrow(() => sut.CompareTo(packageStub.Object));
        }

        [Test]
        public void ThrowAnArgumentException_WhenPackageWithDifferentNamePassed()
        {
            // Arrange 
            const string validName = "Valid name";
            const string differentName = validName + "2";
            var versionStub = new Mock<IVersion>();
            var packageStub = new Mock<IPackage>();
            packageStub.SetupGet(x => x.Name).Returns(differentName);
            var sut = new Package(validName, versionStub.Object);

            //Assert & Act
            Assert.Throws<ArgumentException>(() => sut.CompareTo(packageStub.Object));
        }

        [Test]
        public void ReturnMinusOne_WhenPackageWithHigherVersionIsPassed()
        {
            // Arrange 
            const string validName = "Valid name";
            const int major = 1;
            const int minor = 2;
            const int patch = 3;
            const VersionType versionType = VersionType.alpha;
            const int expectedResult = -1;

            var versionStubLower = new Mock<IVersion>();
            versionStubLower.SetupGet(x => x.Major).Returns(major);
            versionStubLower.SetupGet(x => x.Minor).Returns(minor);
            versionStubLower.SetupGet(x => x.Patch).Returns(patch);
            versionStubLower.SetupGet(x => x.VersionType).Returns(versionType);

            var versionStubHigher = new Mock<IVersion>();
            versionStubHigher.SetupGet(x => x.Major).Returns(major + 1);
            versionStubHigher.SetupGet(x => x.Minor).Returns(minor + 1);
            versionStubHigher.SetupGet(x => x.Patch).Returns(patch + 1);
            versionStubHigher.SetupGet(x => x.VersionType).Returns(versionType);

            var packageStub = new Mock<IPackage>();
            packageStub.SetupGet(x => x.Name).Returns(validName);
            packageStub.SetupGet(x => x.Version).Returns(versionStubHigher.Object);

            var sut = new Package(validName, versionStubLower.Object);

            //Assert & Act
            Assert.AreEqual(expectedResult, sut.CompareTo(packageStub.Object));
        }

        [Test]
        public void ReturnOne_WhenPackageWithLowerVersionIsPassed()
        {
            // Arrange 
            const string validName = "Valid name";
            const int major = 1;
            const int minor = 2;
            const int patch = 3;
            const VersionType versionType = VersionType.alpha;
            const int expectedResult = 1;

            var versionStubLower = new Mock<IVersion>();
            versionStubLower.SetupGet(x => x.Major).Returns(major);
            versionStubLower.SetupGet(x => x.Minor).Returns(minor);
            versionStubLower.SetupGet(x => x.Patch).Returns(patch);
            versionStubLower.SetupGet(x => x.VersionType).Returns(versionType);

            var versionStubHigher = new Mock<IVersion>();
            versionStubHigher.SetupGet(x => x.Major).Returns(major + 1);
            versionStubHigher.SetupGet(x => x.Minor).Returns(minor + 1);
            versionStubHigher.SetupGet(x => x.Patch).Returns(patch + 1);
            versionStubHigher.SetupGet(x => x.VersionType).Returns(versionType);

            var packageStub = new Mock<IPackage>();
            packageStub.SetupGet(x => x.Name).Returns(validName);
            packageStub.SetupGet(x => x.Version).Returns(versionStubLower.Object);

            var sut = new Package(validName, versionStubHigher.Object);

            //Assert & Act
            Assert.AreEqual(expectedResult, sut.CompareTo(packageStub.Object));
        }

        [Test]
        public void ReturnZero_WhenPackageWithSameVersionIsPassed()
        {
            // Arrange 
            const string validName = "Valid name";
            const int major = 1;
            const int minor = 2;
            const int patch = 3;
            const VersionType versionType = VersionType.alpha;
            const int expectedResult = 0;

            var versionStub = new Mock<IVersion>();
            versionStub.SetupGet(x => x.Major).Returns(major);
            versionStub.SetupGet(x => x.Minor).Returns(minor);
            versionStub.SetupGet(x => x.Patch).Returns(patch);
            versionStub.SetupGet(x => x.VersionType).Returns(versionType);

            var packageStub = new Mock<IPackage>();
            packageStub.SetupGet(x => x.Name).Returns(validName);
            packageStub.SetupGet(x => x.Version).Returns(versionStub.Object);

            var sut = new Package(validName, versionStub.Object);

            //Assert & Act
            Assert.AreEqual(expectedResult, sut.CompareTo(packageStub.Object));
        }
    }
}
