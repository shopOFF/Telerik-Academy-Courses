﻿using Moq;
using NUnit.Framework;
using PackageManager.Models;
using PackageManager.Models.Contracts;
using System.Collections.Generic;

namespace PackageManager.Tests.Models.PackageTests
{
    [TestFixture]
    public class Constructor_Should
    {
        [Test]
        public void SetDependencies_WhenDependenciesPassed()
        {
            //Arrange & Act
            const string validName = "Valid Name";
            var versionStub = new Mock<IVersion>();
            var dependenciesStub = new Mock<ICollection<IPackage>>();
            var sut = new Package(validName, versionStub.Object, dependenciesStub.Object);

            // Assert
            Assert.AreSame(dependenciesStub.Object, sut.Dependencies);
        }

        [Test]
        public void SetDefaultDependencies_WhenNoDependenciesPassed()
        {
            //Arrange & Act
            const string validName = "Valid Name";
            var versionStub = new Mock<IVersion>();
            var sut = new Package(validName, versionStub.Object);

            // Assert
            Assert.IsInstanceOf<ICollection<IPackage>>(sut.Dependencies);
        }
    }
}
