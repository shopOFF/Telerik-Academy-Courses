﻿using Moq;
using NUnit.Framework;
using PackageManager.Enums;
using PackageManager.Models;
using PackageManager.Models.Contracts;
using System;

namespace PackageManager.Tests.Models.PackageTests
{
    [TestFixture]
    public class Equals_Should
    {
        [Test]
        public void ThrowAnArgumentNullException_WhenNullIsPassed()
        {
            // Arrange 
            const string validName = "Valid name";
            var versionStub = new Mock<IVersion>();
            object passedObject = null;
            var sut = new Package(validName, versionStub.Object);

            //Assert & Act
            Assert.Throws<ArgumentNullException>(() => sut.Equals(passedObject));
        }

        [Test]
        public void ThrowAnArgumentException_WhenObjectPassedIsNotAnIPackage()
        {
            // Arrange 
            const string validName = "Valid name";
            var versionStub = new Mock<IVersion>();
            var passedObject = new object();
            var sut = new Package(validName, versionStub.Object);

            //Assert & Act
            Assert.Throws<ArgumentException>(() => sut.Equals(passedObject));
        }

        [Test]
        public void NotThrowAnException_WhenValidPackageIsPassed()
        {
            // Arrange 
            const string validName = "Valid name";
            var versionStub = new Mock<IVersion>();
            var packageStub = new Mock<IPackage>();
            var sut = new Package(validName, versionStub.Object);

            //Assert & Act
            Assert.DoesNotThrow(() => sut.Equals(packageStub.Object));
        }

        [Test]
        public void ReturnTrue_WhenEqualPackageIsPassed()
        {
            // Arrange 
            const string validName = "Valid name";
            const int major = 1;
            const int minor = 2;
            const int patch = 3;
            const VersionType versionType = VersionType.alpha;

            var versionStub = new Mock<IVersion>();
            versionStub.SetupGet(x => x.Major).Returns(major);
            versionStub.SetupGet(x => x.Minor).Returns(minor);
            versionStub.SetupGet(x => x.Patch).Returns(patch);
            versionStub.SetupGet(x => x.VersionType).Returns(versionType);

            var packageStub = new Mock<IPackage>();
            packageStub.SetupGet(x => x.Name).Returns(validName);
            packageStub.SetupGet(x => x.Version).Returns(versionStub.Object);

            var sut = new Package(validName, versionStub.Object);

            //Assert & Act
            Assert.IsTrue(sut.Equals(packageStub.Object));
        }

        [Test]
        public void ReturnFalse_WhenNotEqualPackageIsPassed()
        {
            // Arrange 
            const string validName = "Valid name";
            const int major = 1;
            const int minor = 2;
            const int patch = 3;
            const VersionType versionType = VersionType.alpha;

            var firstVersionStub = new Mock<IVersion>();
            firstVersionStub.SetupGet(x => x.Major).Returns(major);
            firstVersionStub.SetupGet(x => x.Minor).Returns(minor);
            firstVersionStub.SetupGet(x => x.Patch).Returns(patch);
            firstVersionStub.SetupGet(x => x.VersionType).Returns(versionType);

            var secondVersionStub = new Mock<IVersion>();
            secondVersionStub.SetupGet(x => x.Major).Returns(major + 1);
            secondVersionStub.SetupGet(x => x.Minor).Returns(minor + 1);
            secondVersionStub.SetupGet(x => x.Patch).Returns(patch + 1);
            secondVersionStub.SetupGet(x => x.VersionType).Returns(versionType);

            var packageStub = new Mock<IPackage>();
            packageStub.SetupGet(x => x.Name).Returns(validName);
            packageStub.SetupGet(x => x.Version).Returns(firstVersionStub.Object);

            var sut = new Package(validName, secondVersionStub.Object);

            //Assert & Act
            Assert.IsFalse(sut.Equals(packageStub.Object));
        }
    }
}
