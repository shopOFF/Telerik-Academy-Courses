﻿using Moq;
using NUnit.Framework;
using PackageManager.Enums;
using PackageManager.Models;
using PackageManager.Models.Contracts;
using System;

namespace PackageManager.Tests.Models.PackageTests
{
    [TestFixture]
    public class Url_Should
    {
        [Test]
        public void SetUrl_WhenValidUrlPassed()
        {
            //Arrange & Act
            const string validName = "Valid Name";
            const int major = 1;
            const int minor = 2;
            const int patch = 3;
            const VersionType versionType = VersionType.alpha;
            string resultUrl = string.Format("{0}.{1}.{2}-{3}", major, minor, patch, versionType);
            var versionStub = new Mock<IVersion>();

            versionStub.SetupGet(x => x.Major).Returns(major);
            versionStub.SetupGet(x => x.Minor).Returns(minor);
            versionStub.SetupGet(x => x.Patch).Returns(patch);
            versionStub.SetupGet(x => x.VersionType).Returns(versionType);
            var sut = new Package(validName, versionStub.Object);

            //Assert
            Assert.AreEqual(resultUrl, sut.Url);
        }

    }
}
