﻿using Moq;
using NUnit.Framework;
using PackageManager.Models;
using PackageManager.Models.Contracts;
using System;

namespace PackageManager.Tests.Models.PackageTests
{
    [TestFixture]
    public class Version_Should
    {
        [Test]
        public void SetVersion_WhenValidVersionPassed()
        {
            //Arrange & Act
            const string validName = "Valid Name";
            var versionStub = new Mock<IVersion>();
            var sut = new Package(validName, versionStub.Object);

            //Assert
            Assert.AreEqual(versionStub.Object, sut.Version);
        }

        [Test]
        public void ThrowAnArgumenNullException_WhenInvalidNamePassed()
        {
            //Arrange
            const string validName = "Valid Name";
            IVersion versionStub = null;

            //Act & Assert
            Assert.Throws<ArgumentNullException>(() => new Package(validName, versionStub));
        }
    }
}
