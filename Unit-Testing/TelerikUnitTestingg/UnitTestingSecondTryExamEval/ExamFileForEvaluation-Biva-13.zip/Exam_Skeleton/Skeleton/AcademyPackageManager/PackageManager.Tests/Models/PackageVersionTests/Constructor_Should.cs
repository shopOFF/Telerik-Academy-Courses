﻿using NUnit.Framework;
using PackageManager.Enums;
using PackageManager.Models;

namespace PackageManager.Tests.Core.PackageVersionTests
{
    [TestFixture]
    public class Constructor_Should
    {
        [Test]
        public void SetMajor_WhenValidMajorPassed()
        {
            //Arrange & Act
            const int validMajor = 1;
            const int validMinor = 1;
            const int validPatch = 1;
            const VersionType validVersionType = VersionType.alpha;
            var sut = new PackageVersion(validMajor, validMinor, validPatch, validVersionType);

            //Assert
            Assert.AreEqual(validMajor, sut.Major);
        }

        [Test]
        public void SetMinor_WhenValidMinorPassed()
        {
            //Arrange & Act
            const int validMajor = 1;
            const int validMinor = 1;
            const int validPatch = 1;
            const VersionType validVersionType = VersionType.alpha;
            var sut = new PackageVersion(validMajor, validMinor, validPatch, validVersionType);

            //Assert
            Assert.AreEqual(validMinor, sut.Minor);
        }

        [Test]
        public void SetPath_WhenValidPathPassed()
        {
            //Arrange & Act
            const int validMajor = 1;
            const int validMinor = 1;
            const int validPatch = 1;
            const VersionType validVersionType = VersionType.alpha;
            var sut = new PackageVersion(validMajor, validMinor, validPatch, validVersionType);

            //Assert
            Assert.AreEqual(validPatch, sut.Patch);
        }

        [Test]
        public void SetVersionType_WhenValidVersionTypePassed()
        {
            //Arrange & Act
            const int validMajor = 1;
            const int validMinor = 1;
            const int validPatch = 1;
            const VersionType validVersionType = VersionType.alpha;
            var sut = new PackageVersion(validMajor, validMinor, validPatch, validVersionType);

            //Assert
            Assert.AreEqual(validVersionType, sut.VersionType);
        }
    }
}
