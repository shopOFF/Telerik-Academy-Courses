﻿using NUnit.Framework;
using PackageManager.Enums;
using PackageManager.Models;
using System;

namespace PackageManager.Tests.Models.PackageVersionTests
{
    [TestFixture]
    public class Major_Should
    {
        [Test]
        public void ThrowAnArgumentException_WhenInvalidMajorIsPassed()
        {
            //Arrange
            const int invalidMajor = -1;
            const int validMinor = 1;
            const int validPatch = 1;
            const VersionType validVersionType = VersionType.alpha;

            //Act & Assert 
            Assert.Throws<ArgumentException>(() => new PackageVersion(invalidMajor, validMinor, validPatch, validVersionType));
        }

        [Test]
        public void SetMajor_WhenValidMajorIsPassed()
        {
            //Arrange
            const int validMajor = 1;
            const int validMinor = 1;
            const int validPatch = 1;
            const VersionType validVersionType = VersionType.alpha;
            var sut = new PackageVersion(validMajor, validMinor, validPatch, validVersionType);

            //Act & Assert 
            Assert.AreEqual(validMajor, sut.Major);
        }
    }
}
