﻿using NUnit.Framework;
using PackageManager.Enums;
using PackageManager.Models;
using System;

namespace PackageManager.Tests.Models.PackageVersionTests
{
    public class Minor_Should
    {
        [Test]
        public void ThrowAnArgumentException_WhenInvalidMinorIsPassed()
        {
            //Arrange
            const int validMajor = 1;
            const int invalidMinor = -1;
            const int validPatch = 1;
            const VersionType validVersionType = VersionType.alpha;

            //Act & Assert 
            Assert.Throws<ArgumentException>(() => new PackageVersion(validMajor, invalidMinor, validPatch, validVersionType));
        }

        [Test]
        public void SetMajor_WhenValidMinorIsPassed()
        {
            //Arrange
            const int validMajor = 1;
            const int validMinor = 1;
            const int validPatch = 1;
            const VersionType validVersionType = VersionType.alpha;
            var sut = new PackageVersion(validMajor, validMinor, validPatch, validVersionType);

            //Act & Assert 
            Assert.AreEqual(validMinor, sut.Minor);
        }
    }
}
