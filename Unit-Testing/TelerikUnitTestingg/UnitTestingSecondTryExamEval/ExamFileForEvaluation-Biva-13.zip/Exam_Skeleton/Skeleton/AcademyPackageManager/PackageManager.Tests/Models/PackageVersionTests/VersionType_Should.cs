﻿using NUnit.Framework;
using PackageManager.Enums;
using PackageManager.Models;
using System;

namespace PackageManager.Tests.Models.PackageVersionTests
{
    public class VersionType_Should
    {
        [TestCase(-1)]
        [TestCase(4)]
        public void ThrowAnArgumentException_WhenInvalidVersionTypeIsPassed(int type)
        {
            //Arrange
            const int validMajor = 1;
            const int validMinor = 1;
            const int validPatch = 1;
            VersionType invalidVersionType = (VersionType)type;

            //Act & Assert 
            Assert.Throws<ArgumentException>(() => new PackageVersion(validMajor, validMinor, validPatch, invalidVersionType));
        }

        [Test]
        public void SetMajor_WhenValidVersionTypeIsPassed()
        {
            //Arrange
            const int validMajor = 1;
            const int validMinor = 1;
            const int validPatch = 1;
            const VersionType validVersionType = VersionType.alpha;
            var sut = new PackageVersion(validMajor, validMinor, validPatch, validVersionType);

            //Act & Assert 
            Assert.AreEqual(validVersionType, sut.VersionType);
        }
    }
}
