﻿using Moq;
using NUnit.Framework;
using PackageManager.Models;
using PackageManager.Models.Contracts;
using PackageManager.Repositories.Contracts;

namespace PackageManager.Tests.Models.ProjectTests
{
    [TestFixture]
    public class Constructor_Should
    {
        [Test]
        public void SetPackageRepository_WhenPackageRepositoryPassed()
        {
            //Arrange & Act
            const string validName = "Valid Name";
            const string validLocation = "Valid Location";
            var packageRepositoryStub = new Mock<PackageRepository<IPackage>>();
            var sut = new Project(validName, validLocation, packageRepositoryStub.Object);

            //Assert
            Assert.AreSame(packageRepositoryStub.Object, sut.PackageRepository);
        }

        [Test]
        public void SetNewDefaultPackageRepository_WhenNoPackageRepositoryPassed()
        {
            //Arrange & Act
            const string validName = "Valid Name";
            const string validLocation = "Valid Location";
            var sut = new Project(validName, validLocation);

            //Assert
            Assert.IsInstanceOf<PackageRepository<IPackage>>(sut.PackageRepository);
        }

        [Test]
        public void SetName_WhenValidNamePassed()
        {
            //Arrange & Act
            const string validName = "Valid Name";
            const string validLocation = "Valid Location";
            var sut = new Project(validName, validLocation);

            //Assert
            Assert.AreEqual(validName, sut.Name);
        }

        [Test]
        public void SetLocation_WhenValidLocationPassed()
        {
            //Arrange & Act
            const string validName = "Valid Name";
            const string validLocation = "Valid Location";
            var sut = new Project(validName, validLocation);

            //Assert
            Assert.AreEqual(validLocation, sut.Location);
        }
    }
}
