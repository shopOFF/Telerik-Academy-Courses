﻿using Moq;
using NUnit.Framework;
using PackageManager.Models;
using PackageManager.Models.Contracts;
using PackageManager.Repositories.Contracts;
using System;

namespace PackageManager.Tests.Models.ProjectTests
{
    [TestFixture]
    public class Location_Should
    {
        [Test]
        public void ThrowAnArgumentException_WhenNullIsPassed()
        {
            //Arrange & Act
            const string validName = "Valid Name";
            const string invalidLocation = null;

            //Assert
            Assert.Throws<ArgumentNullException>(() => new Project(validName, invalidLocation));
        }

        [Test]
        public void SetLocation_WhenValidLocationPassed()
        {
            //Arrange & Act
            const string validName = "Valid Name";
            const string validLocation = "Valid Location";
            var sut = new Project(validName, validLocation);

            //Assert
            Assert.AreEqual(validLocation, sut.Location);
        }
    }
}
