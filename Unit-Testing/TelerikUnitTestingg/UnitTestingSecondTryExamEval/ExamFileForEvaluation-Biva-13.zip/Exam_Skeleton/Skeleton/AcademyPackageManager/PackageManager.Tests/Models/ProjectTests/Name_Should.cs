﻿using Moq;
using NUnit.Framework;
using PackageManager.Models;
using PackageManager.Models.Contracts;
using PackageManager.Repositories.Contracts;
using System;

namespace PackageManager.Tests.Models.ProjectTests
{
    [TestFixture]
    public class Name_Should
    {
        [Test]
        public void ThrowAnArgumentException_WhenNullIsPassed()
        {
            //Arrange & Act
            const string invalidName = null;
            const string validLocation = "Valid Location";

            //Assert
            Assert.Throws<ArgumentNullException>(() => new Project(invalidName, validLocation));
        }

        [Test]
        public void SetName_WhenValidNamePassed()
        {
            //Arrange & Act
            const string validName = "Valid Name";
            const string validLocation = "Valid Location";
            var sut = new Project(validName, validLocation);

            //Assert
            Assert.AreEqual(validName, sut.Name);
        }
    }
}
