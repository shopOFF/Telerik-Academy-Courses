﻿using Moq;
using NUnit.Framework;
using PackageManager.Repositories;
using System;

namespace PackageManager.Tests.Repositories.PackageRepositoryTests
{
    [TestFixture]
    public class Add_Should
    {
        [Test]
        public void ThrowAnArgumenException_WhenNullIsPassed()
        {
            //Arrange
            var loggerStub = new Mock<PackageManager.Info.Contracts.ILogger>();
            var sut = new PackageRepository(loggerStub.Object);

            //Assert & Act
            Assert.Throws<ArgumentNullException>(() => sut.Add(null));
        }
    }
}
