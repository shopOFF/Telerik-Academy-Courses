﻿using System.Collections.Generic;

namespace PackageManager.Repositories.Contracts
{
    public interface PackageRepository<T>
    {
        void Add(T package);

        bool Update(T package);

        IEnumerable<T> GetAll();

        T Delete(T package);
    }
}
