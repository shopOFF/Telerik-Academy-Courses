﻿namespace PackageManager.Tests.Commands.InstallCommandTests
{
    using Enums;
    using Mocks;
    using Moq;
    using NUnit.Framework;
    using PackageManager.Commands;
    using PackageManager.Core.Contracts;
    using PackageManager.Models.Contracts;
    using System;

    [TestFixture]
    public class Constructor_Should
    {
        [Test]
        public void ThrowArgumentNullException_WhenInstallerIsNull()
        {
            // Arrange
            var packageMock = new Mock<IPackage>();

            // Act & Assert
            Assert.Throws<ArgumentNullException>(() => new InstallCommand(null, packageMock.Object));
        }

        [Test]
        public void ThrowArgumentNullException_WhenPackageIsNull()
        {
            // Arrange
            var installerMock = new Mock<IInstaller<IPackage>>();

            // Act & Assert
            Assert.Throws<ArgumentNullException>(() => new InstallCommand(installerMock.Object, null));
        }

        [Test]
        public void SetInstaller_WhenPassedInstallerIsNotNull()
        {
            // Arrange
            var packageMock = new Mock<IPackage>();
            var installerMock = new Mock<IInstaller<IPackage>>();

            // Act
            var result = new InstallCommandMock(installerMock.Object, packageMock.Object);

            // Assert
            Assert.AreSame(installerMock.Object, result.Installer);
        }

        [Test]
        public void SetPackage_WhenPassedPackageIsNotNull()
        {
            // Arrange
            var packageMock = new Mock<IPackage>();
            var installerMock = new Mock<IInstaller<IPackage>>();

            // Act
            var result = new InstallCommandMock(installerMock.Object, packageMock.Object);

            // Assert
            Assert.AreSame(packageMock.Object, result.Package);
        }

        [Test]
        public void SetInstallerOperations_WhenCorrectValuesArePassed()
        {
            // Arrange
            var packageMock = new Mock<IPackage>();
            var installerMock = new Mock<IInstaller<IPackage>>();

            // Act
            var result = new InstallCommandMock(installerMock.Object, packageMock.Object);

            // Assert
            Assert.AreEqual(InstallerOperation.Install, result.Installer.Operation);
        }
    }
}
