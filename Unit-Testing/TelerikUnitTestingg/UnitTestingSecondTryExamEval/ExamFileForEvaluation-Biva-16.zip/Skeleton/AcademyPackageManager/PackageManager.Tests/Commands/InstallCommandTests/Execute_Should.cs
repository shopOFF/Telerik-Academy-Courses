﻿namespace PackageManager.Tests.Commands.InstallCommandTests
{
    using Mocks;
    using Moq;
    using NUnit.Framework;
    using PackageManager.Core.Contracts;
    using PackageManager.Models.Contracts;

    [TestFixture]
    public class Execute_Should
    {
        [Test]
        public void CallPerformOperation_WhenInvoked()
        {
            // Arrange
            var packageMock = new Mock<IPackage>();
            var installerMock = new Mock<IInstaller<IPackage>>();

            var passedPackageMock = new Mock<IPackage>();
            installerMock.Setup(x => x.PerformOperation(passedPackageMock.Object));

            var result = new InstallCommandMock(installerMock.Object, packageMock.Object);
            result.Execute();

            // Act & Assert
            installerMock.Verify(x => x.PerformOperation(It.IsAny<IPackage>()), Times.Once);
        }
    }
}
