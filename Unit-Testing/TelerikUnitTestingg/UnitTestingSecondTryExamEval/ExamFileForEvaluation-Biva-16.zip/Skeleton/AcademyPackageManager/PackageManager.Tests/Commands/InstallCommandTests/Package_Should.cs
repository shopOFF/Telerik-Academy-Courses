﻿namespace PackageManager.Tests.Commands.InstallCommandTests
{
    using Mocks;
    using Moq;
    using NUnit.Framework;
    using PackageManager.Core.Contracts;
    using PackageManager.Models.Contracts;

    [TestFixture]
    public class Package_Should
    {
        [Test]
        public void ReturnCorrectValue__WhenPassedValueIsValid()
        {
            // Arrange
            var packageMock = new Mock<IPackage>();
            var installerMock = new Mock<IInstaller<IPackage>>();

            // Act
            var result = new InstallCommandMock(installerMock.Object, packageMock.Object);

            // Assert
            Assert.AreSame(packageMock.Object, result.Package);
        }
    }
}
