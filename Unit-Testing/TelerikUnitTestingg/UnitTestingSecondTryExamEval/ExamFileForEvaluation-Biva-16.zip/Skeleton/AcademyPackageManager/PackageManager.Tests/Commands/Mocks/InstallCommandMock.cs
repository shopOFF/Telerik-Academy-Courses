﻿namespace PackageManager.Tests.Commands.Mocks
{
    using PackageManager.Commands;
    using PackageManager.Models.Contracts;
    using PackageManager.Core.Contracts;

    internal class InstallCommandMock : InstallCommand
    {
        public InstallCommandMock(IInstaller<IPackage> installer, IPackage package) 
            : base(installer, package)
        {
        }

        public IInstaller<IPackage> Installer
        {
            get
            {
                return base.installer;
            }
        }

        public IPackage Package
        {
            get
            {
                return base.package;
            }
        }
    }
}
