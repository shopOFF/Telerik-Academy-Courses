﻿namespace PackageManager.Tests.Core.PackageInstallerTests
{
    using Info.Contracts;
    using Mocks;
    using Moq;
    using NUnit.Framework;
    using PackageManager.Core;
    using PackageManager.Core.Contracts;
    using PackageManager.Models.Contracts;
    using PackageManager.Repositories;
    using Repositories;
    using System.Collections;
    using System.Collections.Generic;

    [TestFixture]
    public class Constructor_Should
    {
        [Test]
        public void CallToRestorePackages_WhenTheObjectIsConstructed()
        {
            // Arrange
            var loggerMock = new Mock<ILogger>();

            var downloaderMock = new Mock<IDownloader>();
            var projectMock = new Mock<IProject>();

            var packageMock = new Mock<IPackage>();
            packageMock.Setup(x => x.Name).Returns("Gosho");
            packageMock.Setup(x => x.Dependencies).Returns(new List<IPackage>() { });


            var passedPackageMock = new Mock<IPackage>();
            passedPackageMock.Setup(x => x.Name).Returns("Pesho");
            passedPackageMock.Setup(x => x.Dependencies).Returns(new List<IPackage>() { packageMock.Object });

            var packages = new List<IPackage>() { passedPackageMock.Object };
            projectMock.Setup(x => x.PackageRepository).Returns(new PackageRepository(loggerMock.Object, new List<IPackage>() { passedPackageMock.Object }));
            // projectMock.Object.PackageRepository.Add(packageMock.Object);

            // Act
            var result = new PackageInstallerMock(downloaderMock.Object, projectMock.Object);

            // Assert
            Assert.AreEqual(1, ((ICollection)result.Project.PackageRepository.GetAll()).Count);
        }
    }
}
