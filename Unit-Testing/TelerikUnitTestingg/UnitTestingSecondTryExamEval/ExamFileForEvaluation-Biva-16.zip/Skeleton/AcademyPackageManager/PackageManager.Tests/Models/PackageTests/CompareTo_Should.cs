﻿namespace PackageManager.Tests.Models.PackageTests
{
    using Enums;
    using Moq;
    using NUnit.Framework;
    using PackageManager.Models;
    using PackageManager.Models.Contracts;
    using System;

    [TestFixture]
    public class CompareTo_Should
    {
        [Test]
        public void ThrowsArgumentNullException_WhenOtherIsNull()
        {
            // Arrange
            var name = "Pesho";
            var versionMock = new Mock<IVersion>();

            var package = new Package(name, versionMock.Object);

            // Act & Assert
            Assert.Throws<ArgumentNullException>(() => package.CompareTo(null));
        }

        [Test]
        public void ThrowArgumentException_WhenThePassedPackageIsNotWithTheSameName()
        {
            // Arrange
            var name = "Pesho";
            var versionMock = new Mock<IVersion>();

            var package = new Package(name, versionMock.Object);

            var passedPackageMock = new Mock<IPackage>();
            passedPackageMock.Setup(x => x.Name).Returns("Not pesho");

            // Act & Assert
            Assert.Throws<ArgumentException>(() => package.CompareTo(passedPackageMock.Object));
        }

        [Test]
        public void ReturnOne_WhenPackagePassedIsLowerVersion()
        {
            // Arrange
            var name = "Pesho";
            var versionMock = new Mock<IVersion>();

            versionMock.SetupGet(x => x.Major).Returns(10);
            versionMock.SetupGet(x => x.Minor).Returns(10);
            versionMock.SetupGet(x => x.Patch).Returns(10);
            versionMock.SetupGet(x => x.VersionType).Returns(VersionType.beta);

            var package = new Package(name, versionMock.Object);

            var passedPackageMock = new Mock<IPackage>();
            passedPackageMock.SetupGet(x => x.Name).Returns("Pesho");

            var passedVersionMock = new Mock<IVersion>();
            passedVersionMock.SetupGet(x => x.Major).Returns(1);
            passedVersionMock.SetupGet(x => x.Minor).Returns(2);
            passedVersionMock.SetupGet(x => x.Patch).Returns(3);
            passedVersionMock.SetupGet(x => x.VersionType).Returns(VersionType.alpha);

            passedPackageMock.SetupGet(x => x.Version).Returns(passedVersionMock.Object);

            // Act
            var result = package.CompareTo(passedPackageMock.Object);

            // Assert
            Assert.AreEqual(1, result);
        }

        [Test]
        public void ReturnMinusOne_WhenPackagePassedIsHigherVersion()
        {
            // Arrange
            var name = "Pesho";
            var versionMock = new Mock<IVersion>();

            versionMock.SetupGet(x => x.Major).Returns(1);
            versionMock.SetupGet(x => x.Minor).Returns(2);
            versionMock.SetupGet(x => x.Patch).Returns(3);
            versionMock.SetupGet(x => x.VersionType).Returns(VersionType.alpha);

            var package = new Package(name, versionMock.Object);

            var passedPackageMock = new Mock<IPackage>();
            passedPackageMock.SetupGet(x => x.Name).Returns("Pesho");

            var passedVersionMock = new Mock<IVersion>();
            passedVersionMock.SetupGet(x => x.Major).Returns(10);
            passedVersionMock.SetupGet(x => x.Minor).Returns(10);
            passedVersionMock.SetupGet(x => x.Patch).Returns(10);
            passedVersionMock.SetupGet(x => x.VersionType).Returns(VersionType.beta);

            passedPackageMock.SetupGet(x => x.Version).Returns(passedVersionMock.Object);

            // Act
            var result = package.CompareTo(passedPackageMock.Object);

            // Assert
            Assert.AreEqual(-1, result);
        }

        [Test]
        public void ReturnZero_WhenPackagePassedIsSameVersion()
        {
            // Arrange
            var name = "Pesho";
            var versionMock = new Mock<IVersion>();

            versionMock.SetupGet(x => x.Major).Returns(1);
            versionMock.SetupGet(x => x.Minor).Returns(2);
            versionMock.SetupGet(x => x.Patch).Returns(3);
            versionMock.SetupGet(x => x.VersionType).Returns(VersionType.alpha);

            var package = new Package(name, versionMock.Object);

            var passedPackageMock = new Mock<IPackage>();
            passedPackageMock.SetupGet(x => x.Name).Returns("Pesho");

            var passedVersionMock = new Mock<IVersion>();
            passedVersionMock.SetupGet(x => x.Major).Returns(1);
            passedVersionMock.SetupGet(x => x.Minor).Returns(2);
            passedVersionMock.SetupGet(x => x.Patch).Returns(3);
            passedVersionMock.SetupGet(x => x.VersionType).Returns(VersionType.alpha);

            passedPackageMock.SetupGet(x => x.Version).Returns(passedVersionMock.Object);

            // Act
            var result = package.CompareTo(passedPackageMock.Object);

            // Assert
            Assert.AreEqual(0, result);
        }
    }
}
