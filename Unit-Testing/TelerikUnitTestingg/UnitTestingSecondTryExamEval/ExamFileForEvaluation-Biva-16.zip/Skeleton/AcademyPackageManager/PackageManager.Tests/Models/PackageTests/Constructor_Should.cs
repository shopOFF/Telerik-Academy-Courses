﻿namespace PackageManager.Tests.Models.PackageTests
{
    using Moq;
    using NUnit.Framework;
    using PackageManager.Models;
    using PackageManager.Models.Contracts;
    using System;
    using System.Collections.Generic;

    [TestFixture]
    public class Constructor_Should
    {
        [Test]
        public void ThrowArgumentNullException_WhenPassedNameIsNull()
        {
            // Arrange
            var versionMock = new Mock<IVersion>();

            // Act & Assert
            Assert.Throws<ArgumentNullException>(() => new Package(null, versionMock.Object));
        }

        [Test]
        public void ThrowArgumentNullException_WhenPassedVersionIsNull()
        {
            // Arrange
            var name = "Pesho";

            // Act & Assert
            Assert.Throws<ArgumentNullException>(() => new Package(name, null));
        }

        [Test]
        public void SetProperName_WhenThePassedValuesAreAppropriate()
        {
            // Arrange
            var name = "Pesho";
            var versionMock = new Mock<IVersion>();

            // Act
            var result = new Package(name, versionMock.Object);

            // Assert
            Assert.AreEqual(name, result.Name);
        }

        [Test]
        public void SetProperVersion_WhenThePassedValuesAreAppropriate()
        {
            // Arrange
            var name = "Pesho";
            var versionMock = new Mock<IVersion>();

            // Act
            var result = new Package(name, versionMock.Object);

            // Assert
            Assert.AreSame(versionMock.Object, result.Version);
        }

        [Test]
        public void SetCorrectlyDependencies_WhenOptionalParameter()
        {
            // Arrange
            var name = "Pesho";
            var versionMock = new Mock<IVersion>();

            // Act
            var result = new Package(name, versionMock.Object);

            // Assert
            Assert.IsNotNull(result.Dependencies); // Varian 1
            // Assert.IsInstanceOf(typeof(ICollection<IPackage>), result.Dependencies); // Variant 2
            // Assert.AreEqual(0, result.Dependencies.Count); // Variant 3
        }

        [Test]
        public void SetCorrectlyDependencies_WhenPassedParameter()
        {
            // Arrange
            var name = "Pesho";
            var versionMock = new Mock<IVersion>();

            var dependenciesMock = new Mock<ICollection<IPackage>>();

            // Act
            var result = new Package(name, versionMock.Object, dependenciesMock.Object);

            // Assert
            Assert.AreSame(dependenciesMock.Object, result.Dependencies);
        }
    }
}
