﻿namespace PackageManager.Tests.Models.PackageTests
{
    using Enums;
    using Moq;
    using NUnit.Framework;
    using PackageManager.Models;
    using PackageManager.Models.Contracts;
    using System;

    [TestFixture]
    public class Equals_Should
    {
        [Test]
        public void ThrowArgumentNullException_WhenOtherIsNull()
        {
            // Arrange
            var name = "Pesho";
            var versionMock = new Mock<IVersion>();

            var package = new Package(name, versionMock.Object);

            // Act & Assert
            Assert.Throws<ArgumentNullException>(() => package.Equals(null));
        }

        [Test]
        public void ThrowArgumentException_WhenThePassedObjectIsNotPackage()
        {
            // Arrange
            var name = "Pesho";
            var versionMock = new Mock<IVersion>();

            var package = new Package(name, versionMock.Object);

            // Act & Assert
            Assert.Throws<ArgumentException>(() => package.Equals(new Object()));
        }

        [Test]
        public void ReturnTrue_WhenThePassedObjectIsEqualToThePackage()
        {
            // Arrange
            var name = "Pesho";
            var versionMock = new Mock<IVersion>();
            versionMock.SetupGet(x => x.Major).Returns(1);
            versionMock.SetupGet(x => x.Minor).Returns(2);
            versionMock.SetupGet(x => x.Patch).Returns(3);
            versionMock.SetupGet(x => x.VersionType).Returns(VersionType.alpha);

            var package = new Package(name, versionMock.Object);

            var passedPackageMock = new Mock<IPackage>();
            passedPackageMock.SetupGet(x => x.Name).Returns("Pesho");

            var passedVersionMock = new Mock<IVersion>();
            passedVersionMock.SetupGet(x => x.Major).Returns(1);
            passedVersionMock.SetupGet(x => x.Minor).Returns(2);
            passedVersionMock.SetupGet(x => x.Patch).Returns(3);
            passedVersionMock.SetupGet(x => x.VersionType).Returns(VersionType.alpha);

            passedPackageMock.SetupGet(x => x.Version).Returns(passedVersionMock.Object);

            // Act & Assert
            Assert.AreEqual(true, package.Equals(passedPackageMock.Object));
        }

        [Test]
        public void ReturnFalse_WhenThePassedObjectIsNotEqualToThePackage()
        {
            // Arrange
            var name = "Pesho";
            var versionMock = new Mock<IVersion>();
            versionMock.SetupGet(x => x.Major).Returns(1);
            versionMock.SetupGet(x => x.Minor).Returns(2);
            versionMock.SetupGet(x => x.Patch).Returns(3);
            versionMock.SetupGet(x => x.VersionType).Returns(VersionType.alpha);

            var package = new Package(name, versionMock.Object);

            var passedPackageMock = new Mock<IPackage>();
            passedPackageMock.SetupGet(x => x.Name).Returns("Not Pesho");

            var passedVersionMock = new Mock<IVersion>();
            passedVersionMock.SetupGet(x => x.Major).Returns(1);
            passedVersionMock.SetupGet(x => x.Minor).Returns(2);
            passedVersionMock.SetupGet(x => x.Patch).Returns(3);
            passedVersionMock.SetupGet(x => x.VersionType).Returns(VersionType.alpha);

            passedPackageMock.SetupGet(x => x.Version).Returns(passedVersionMock.Object);

            // Act & Assert
            Assert.AreEqual(false, package.Equals(passedPackageMock.Object));
        }
    }
}
