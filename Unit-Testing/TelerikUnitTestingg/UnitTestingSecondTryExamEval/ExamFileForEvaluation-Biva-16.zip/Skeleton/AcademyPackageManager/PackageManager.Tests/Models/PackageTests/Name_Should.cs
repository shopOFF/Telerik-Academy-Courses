﻿namespace PackageManager.Tests.Models.PackageTests
{
    using Moq;
    using NUnit.Framework;
    using PackageManager.Models;
    using PackageManager.Models.Contracts;

    [TestFixture]
    public class Name_Should
    {
        [Test]
        public void ReturnCorrectValue_WhenGetMethodIsCalled()
        {
            // Arrange
            var name = "Pesho";
            var versionMock = new Mock<IVersion>();

            var package = new Package(name, versionMock.Object);

            // Act
            var result = package.Name;

            // Assert
            Assert.AreEqual(name, result);
        }
    }
}

