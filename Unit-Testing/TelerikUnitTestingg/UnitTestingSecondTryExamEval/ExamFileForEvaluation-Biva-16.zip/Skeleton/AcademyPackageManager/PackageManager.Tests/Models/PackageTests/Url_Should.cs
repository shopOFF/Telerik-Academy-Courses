﻿namespace PackageManager.Tests.Models.PackageTests
{
    using Moq;
    using NUnit.Framework;
    using PackageManager.Models;
    using PackageManager.Models.Contracts;

    [TestFixture]
    public class Url_Should
    {
        [Test]
        public void ReturnCorrectValue_WhenGetMethodIsCalled()
        {
            // Arrange
            var expectedUrl = "1.2.3-alpha";
            var name = "Pesho";
            var versionMock = new Mock<IVersion>();

            versionMock.SetupGet(x => x.Major).Returns(1);
            versionMock.SetupGet(x => x.Minor).Returns(2);
            versionMock.SetupGet(x => x.Patch).Returns(3);
            versionMock.SetupGet(x => x.VersionType).Returns(Enums.VersionType.alpha);

            // Act
            var package = new Package(name, versionMock.Object);

            // Assert
            Assert.AreEqual(expectedUrl, package.Url);
        }
    }
}
