﻿namespace PackageManager.Tests.Models.PackageVersionTests
{
    using Enums;
    using NUnit.Framework;
    using PackageManager.Models;

    [TestFixture]
    public class Constructor_Should
    {
        [Test]
        public void SetProperMajor_WhenThePassedValuesAreAppropriate()
        {
            // Arrange
            int major = 1;
            int minor = 2;
            int patch = 3;
            var versionType = VersionType.alpha;

            // Act
            var result = new PackageVersion(major, minor, patch, versionType);

            // Assert
            Assert.AreEqual(major, result.Major);
        }

        [Test]
        public void SetProperMinor_WhenThePassedValuesAreAppropriate()
        {
            // Arrange
            int major = 1;
            int minor = 2;
            int patch = 3;
            var versionType = VersionType.alpha;

            // Act
            var result = new PackageVersion(major, minor, patch, versionType);

            // Assert
            Assert.AreEqual(minor, result.Minor);
        }

        [Test]
        public void SetProperPatch_WhenThePassedValuesAreAppropriate()
        {
            // Arrange
            int major = 1;
            int minor = 2;
            int patch = 3;
            var versionType = VersionType.alpha;

            // Act
            var result = new PackageVersion(major, minor, patch, versionType);

            // Assert
            Assert.AreEqual(patch, result.Patch);
        }

        [Test]
        public void SetProperVersionType_WhenThePassedValuesAreAppropriate()
        {
            // Arrange
            int major = 1;
            int minor = 2;
            int patch = 3;
            var versionType = VersionType.alpha;

            // Act
            var result = new PackageVersion(major, minor, patch, versionType);

            // Assert
            Assert.AreEqual(versionType, result.VersionType);
        }
    }
}
