﻿namespace PackageManager.Tests.Models.PackageVersionTests
{
    using Enums;
    using NUnit.Framework;
    using PackageManager.Models;
    using System;

    [TestFixture]
    public class Patch_Should
    {
        [Test]
        public void ThrowArgumentException_WhenInvalidValueIsPassed()
        {
            // Arrange
            int major = 1;
            int minor = 2;
            int patch = -3;
            var versionType = VersionType.alpha;

            // Act & Assert
            Assert.Throws<ArgumentException>(() => new PackageVersion(major, minor, patch, versionType));
        }

        [Test]
        public void ReturnCorrectValue_WhenGetMethodIsCalled()
        {
            // Arrange
            int major = 1;
            int minor = 2;
            int patch = 3;
            var versionType = VersionType.alpha;

            var packageVersion = new PackageVersion(major, minor, patch, versionType);

            // Act
            var result = packageVersion.Patch;

            // Assert
            Assert.AreEqual(patch, result);
        }
    }
}
