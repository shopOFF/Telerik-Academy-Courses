﻿namespace PackageManager.Tests.Models.ProjectTests
{
    using Moq;
    using NUnit.Framework;
    using PackageManager.Models;
    using PackageManager.Models.Contracts;
    using PackageManager.Repositories.Contracts;
    using System;

    [TestFixture]
    public class Constructor_Should
    {
        [Test]
        public void ThrowArgumentNullException_WhenPassedNameIsNull()
        {
            // Arrange
            var location = "Sofia";

            // Act & Assert
            Assert.Throws<ArgumentNullException>(() => new Project(null, location));
        }

        [Test]
        public void ThrowArgumentNullException_WhenPassedLocationIsNull()
        {
            // Arrange
            var name = "Pesho";

            // Act & Assert
            Assert.Throws<ArgumentNullException>(() => new Project(name, null));
        }

        [Test]
        public void SetProperName_WhenThePassedValuesAreAppropriate()
        {
            // Arrange
            var name = "Pesho";
            var location = "Sofia";

            // Act
            var result = new Project(name, location);

            // Assert
            Assert.AreEqual(name, result.Name);
        }

        [Test]
        public void SetProperLocation_WhenThePassedValuesAreAppropriate()
        {
            // Arrange
            var name = "Pesho";
            var location = "Sofia";

            // Act
            var result = new Project(name, location);

            // Assert
            Assert.AreEqual(location, result.Location);
        }

        [Test]
        public void SetCorrectlyPackageRepository_WhenOptionalParameter()
        {
            // Arrange
            var name = "Pesho";
            var location = "Sofia";

            // Act
            var result = new Project(name, location);

            // Assert
            Assert.IsNotNull(result.PackageRepository); // Varian 1
            // Assert.IsInstanceOf(typeof(IRepository<IPackage>), result.PackageRepository); // Variant 2
        }

        [Test]
        public void SetCorrectlyPackageRepository_WhenPassedParameter()
        {
            // Arrange
            var name = "Pesho";
            var location = "Sofia";

            var packageRepositoryMock = new Mock<IRepository<IPackage>>();

            // Act
            var result = new Project(name, location, packageRepositoryMock.Object);

            // Assert
            Assert.AreSame(packageRepositoryMock.Object, result.PackageRepository);
        }
    }
}
