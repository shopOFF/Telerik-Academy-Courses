﻿namespace PackageManager.Tests.Models.ProjectTests
{
    using NUnit.Framework;
    using PackageManager.Models;

    [TestFixture]
    public class Name_Should
    {
        [Test]
        public void ReturnCorrectValue_WhenGetMethodIsCalled()
        {
            // Arrange
            var name = "Pesho";
            var location = "Sofia";

            var project = new Project(name, location);

            // Act
            var result = project.Name;

            // Assert
            Assert.AreEqual(name, result);
        }
    }
}
