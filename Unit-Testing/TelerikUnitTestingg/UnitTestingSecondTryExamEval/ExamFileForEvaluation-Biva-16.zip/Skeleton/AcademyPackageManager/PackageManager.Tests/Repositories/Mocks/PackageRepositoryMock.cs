﻿namespace PackageManager.Tests.Repositories.Mocks
{
    using System.Collections.Generic;
    using Info.Contracts;
    using PackageManager.Models.Contracts;
    using PackageManager.Repositories;

    internal class PackageRepositoryMock : PackageRepository
    {
        public PackageRepositoryMock(ILogger logger, ICollection<IPackage> packages = null) 
            : base(logger, packages)
        {
        }

        public ICollection<IPackage> Package
        {
            get
            {
                return base.packages;
            }
        }

        public ILogger Logger
        {
            get
            {
                return base.logger;
            }
        }

    }
}
