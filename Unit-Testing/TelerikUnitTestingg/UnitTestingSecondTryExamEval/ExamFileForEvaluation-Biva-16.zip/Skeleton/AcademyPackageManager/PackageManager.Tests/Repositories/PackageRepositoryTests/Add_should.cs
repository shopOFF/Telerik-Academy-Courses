﻿namespace PackageManager.Tests.Repositories.PackageRepositoryTests
{
    using Info.Contracts;
    using Mocks;
    using Moq;
    using NUnit.Framework;
    using PackageManager.Models.Contracts;
    using PackageManager.Repositories;
    using System;
    using System.Collections.Generic;

    [TestFixture]
    public class Add_should
    {
        [Test]
        public void ThrowsArgumentNullException_WhenPackageIsNull()
        {
            // Arrange
            var loggerMock = new Mock<ILogger>();

            var result = new PackageRepository(loggerMock.Object);

            // Act & ssert
            Assert.Throws<ArgumentNullException>(() => result.Add(null));
        }

        [Test]
        public void AddPackage_WhenThePackageIsNull()
        {
            // Arrange
            var loggerMock = new Mock<ILogger>();

            var packageMock = new Mock<IPackage>();
            packageMock.Setup(x => x.Name).Returns("Gosho");

            var listPackagesMock = new Mock<ICollection<IPackage>>();

            var passedPackageMock = new Mock<IPackage>();
            passedPackageMock.Setup(x => x.Name).Returns("Pesho");

            var result = new PackageRepositoryMock(loggerMock.Object);
            result.Add(passedPackageMock.Object);

            // Act & ssert
            Assert.AreEqual(1, result.Package.Count);

        }
    }
}
