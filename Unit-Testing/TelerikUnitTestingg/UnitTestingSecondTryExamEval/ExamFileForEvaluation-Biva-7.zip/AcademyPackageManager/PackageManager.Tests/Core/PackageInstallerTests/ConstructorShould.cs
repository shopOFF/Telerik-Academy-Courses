﻿using NUnit.Framework;

namespace PackageManager.Tests.Core.PackageInstallerTests
{
    [TestFixture]
    public class ConstructorShould
    {
        
    }
}