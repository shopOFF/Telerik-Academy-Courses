﻿namespace PackageManager.Commands.Contracts
{
    public interface ICommand
    {
        void Execute();
    }
}
