﻿using Moq;
using NUnit.Framework;
using PackageManager.Core.Contracts;
using PackageManager.Enums;
using PackageManager.Models.Contracts;
using PackageManager.Tests.Commands.Fakes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PackageManager.Tests.Commands.InstallCommandTests
{
    [TestFixture]
    public class Constructor_Should
    {
        [Test]
        public void AssignProperInstaller_WhenValidDateIsPassed()
        {
            //Arrange & Act
            var installerMock = new Mock<IInstaller<IPackage>>();
            var packageMock = new Mock<IPackage>();
            var sut = new InstallCommandFake(installerMock.Object, packageMock.Object);
            //Assert
            Assert.AreSame(installerMock.Object, sut.Installer);
        }
        [Test]
        public void AssignProperPackage_WhenValidDateIsPassed()
        {
            //Arrange & Act
            var installerMock = new Mock<IInstaller<IPackage>>();
            var packageMock = new Mock<IPackage>();
            var sut = new InstallCommandFake(installerMock.Object, packageMock.Object);
            //Assert
            Assert.AreSame(packageMock.Object, sut.Package);
        }
        [Test]
        public void ThrowArgumentNullException_WhenInstallerIsNull()
        {

            //Arrange
            var packageMock = new Mock<IPackage>();

            //Act & Assert
            Assert.Throws<ArgumentNullException>(() => new InstallCommandFake(null, packageMock.Object));
        }
        [Test]
        public void ThrowArgumentNullException_WhenPackageIsNull()
        {

            //Arrange
            var installerMock = new Mock<IInstaller<IPackage>>();

            //Act & Assert
            Assert.Throws<ArgumentNullException>(() => new InstallCommandFake(installerMock.Object, null));

        }
        [Test]
        public void InitInstallerOperationValue_With_Install()
        {
            //Arrange & Act
            var installerMock = new Mock<IInstaller<IPackage>>();
            var packageMock = new Mock<IPackage>();
            var sut = new InstallCommandFake(installerMock.Object, packageMock.Object);

            //Assert
            Assert.AreEqual(InstallerOperation.Install, installerMock.Object.Operation);
        }
    }
}
