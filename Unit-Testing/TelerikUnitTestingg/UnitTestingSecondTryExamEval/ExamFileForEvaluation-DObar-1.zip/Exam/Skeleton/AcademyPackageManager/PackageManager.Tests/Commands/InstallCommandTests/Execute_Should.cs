﻿using Moq;
using NUnit.Framework;
using PackageManager.Core.Contracts;
using PackageManager.Models.Contracts;
using PackageManager.Tests.Commands.Fakes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PackageManager.Tests.Commands.InstallCommandTests
{
    [TestFixture]
    public class Execute_Should
    {
        [Test]
        public void CallPerformOperationOfTheInstaller()
        {
            // Arrange
            var installerMock = new Mock<IInstaller<IPackage>>();
            installerMock.Setup(i => i.PerformOperation(It.IsAny<IPackage>()));
            var packageMock = new Mock<IPackage>();
            var sut = new InstallCommandFake(installerMock.Object, packageMock.Object);
            //Act
            sut.Execute();
            //Assert
            installerMock.Verify(i => i.PerformOperation(It.IsAny<IPackage>()), Times.Once);
        }
    }
}
