﻿using Moq;
using NUnit.Framework;
using PackageManager.Core;
using PackageManager.Core.Contracts;
using PackageManager.Models.Contracts;
using PackageManager.Repositories.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PackageManager.Tests.Core.PackageInstallerTests
{
    [TestFixture]
    public class Constructor_Should
    {
        [Test]
        public void TestForRestoringPackages_WhenItIsCalled()
        {
            //Arrange & Act
            var downloaderMock = new Mock<IDownloader>();
            var projectMock = new Mock<IProject>();
            projectMock.Setup(p => p.Location).Returns("MyLocation");
            var packageRepositoryMock = new Mock<IRepository<IPackage>>();
            packageRepositoryMock.Setup(p => p.GetAll()).Returns(new HashSet<IPackage>());
            projectMock.Setup(p => p.PackageRepository).Returns(packageRepositoryMock.Object);

            var sut = new PackageInstaller(downloaderMock.Object, projectMock.Object);
            //Assert
            packageRepositoryMock.Verify(p => p.GetAll(), Times.Once);
        }
    }
}
