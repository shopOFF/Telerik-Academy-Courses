﻿using Moq;
using NUnit.Framework;
using PackageManager.Enums;
using PackageManager.Models;
using PackageManager.Models.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PackageManager.Tests.Models.PackageTests
{
    [TestFixture]
    public class CompareTo_Should
    {
        [Test]
        public void ThrowArgumentNullException_WhenNullOtherValueIsPassed()
        {
            // Arrange
            string name = "ValidName";
            var versionStub = new Mock<IVersion>();
            var sut = new Package(name, versionStub.Object);
            //Act & Assert
            Assert.Throws<ArgumentNullException>(() => sut.CompareTo(null));
        }
        [Test]
        public void ThrowArgumentException_WhenTheNamesOfThePackagesAreDifferent()
        {
            // Arrange
            string name = "ValidName";
            var versionStub = new Mock<IVersion>();
            var sut = new Package(name, versionStub.Object);
            var otherPackage = new Mock<IPackage>();
            otherPackage.Setup(p => p.Name).Returns("otherValidName");
            //Act & Assert
            Assert.Throws<ArgumentException>(() => sut.CompareTo(otherPackage.Object));
        }
        [Test]
        public void Return_1_When_PassedVersionIsLower()
        {
            // Arrange
            string name = "ValidName";
            var versionStub = new Mock<IVersion>();
            versionStub.Setup(v => v.Major).Returns(2);
            versionStub.Setup(v => v.Minor).Returns(2);
            versionStub.Setup(v => v.Patch).Returns(2);
            versionStub.Setup(v => v.VersionType).Returns(VersionType.alpha);
            var sut = new Package(name, versionStub.Object);
            var otherPackageStub = new Mock<IPackage>();
            otherPackageStub.Setup(p => p.Name).Returns(name);
            otherPackageStub.Setup(p => p.Version.Major).Returns(1);
            otherPackageStub.Setup(p => p.Version.Minor).Returns(1);
            otherPackageStub.Setup(p => p.Version.Patch).Returns(1);
            otherPackageStub.Setup(p => p.Version.VersionType).Returns(VersionType.alpha);

            //Act
            var result = sut.CompareTo(otherPackageStub.Object);

            //Assert
            Assert.AreEqual(1, result);
        }
        [Test]
        public void Return_minus1_When_PassedVersionIsHigher()
        {
            // Arrange
            string name = "ValidName";
            var versionStub = new Mock<IVersion>();
            versionStub.Setup(v => v.Major).Returns(1);
            versionStub.Setup(v => v.Minor).Returns(1);
            versionStub.Setup(v => v.Patch).Returns(1);
            versionStub.Setup(v => v.VersionType).Returns(VersionType.final);
            var sut = new Package(name, versionStub.Object);
            var otherPackageStub = new Mock<IPackage>();
            otherPackageStub.Setup(p => p.Name).Returns(name);
            otherPackageStub.Setup(p => p.Version.Major).Returns(2);
            otherPackageStub.Setup(p => p.Version.Minor).Returns(2);
            otherPackageStub.Setup(p => p.Version.Patch).Returns(2);
            otherPackageStub.Setup(p => p.Version.VersionType).Returns(VersionType.final);

            //Act
            var result = sut.CompareTo(otherPackageStub.Object);

            //Assert
            Assert.AreEqual(-1, result);
        }
        [Test]
        public void Return_0_When_PassedVersionAreTheSame()
        {
            // Arrange
            string name = "ValidName";
            var versionStub = new Mock<IVersion>();
            versionStub.Setup(v => v.Major).Returns(1);
            versionStub.Setup(v => v.Minor).Returns(1);
            versionStub.Setup(v => v.Patch).Returns(1);
            versionStub.Setup(v => v.VersionType).Returns(VersionType.alpha);
            var sut = new Package(name, versionStub.Object);
            var otherPackageStub = new Mock<IPackage>();
            otherPackageStub.Setup(p => p.Name).Returns(name);
            otherPackageStub.Setup(p => p.Version.Major).Returns(1);
            otherPackageStub.Setup(p => p.Version.Minor).Returns(1);
            otherPackageStub.Setup(p => p.Version.Patch).Returns(1);
            otherPackageStub.Setup(p => p.Version.VersionType).Returns(VersionType.alpha);

            //Act
            var result = sut.CompareTo(otherPackageStub.Object);

            //Assert
            Assert.AreEqual(0, result);
        }
    }
}
