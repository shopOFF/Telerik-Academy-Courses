﻿using Moq;
using NUnit.Framework;
using PackageManager.Enums;
using PackageManager.Models;
using PackageManager.Models.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PackageManager.Tests.Models.PackageTests
{
    [TestFixture]
    public class Constructor_Should
    {
        [Test]
        public void AssignProperName_WhenValidDataIsPassed()
        {
            //Arrange & Act
            string name = "ValidName";
            var versionMock = new Mock<IVersion>();
            var sut = new Package(name, versionMock.Object);
            //Assert
            Assert.AreEqual(name, sut.Name);
        }
        [Test]
        public void AssignProperVersion_WhenValidDataIsPassed()
        {
            //Arrange & Act
            string name = "ValidName";
            var versionMock = new Mock<IVersion>();
            var sut = new Package(name, versionMock.Object);
            //Assert
            Assert.AreSame(versionMock.Object, sut.Version);
        }
        [Test]
        public void AssignProperDependencies_WhenOptionalParameterIsNotPassed()
        {
            //Arrange & Act
            string name = "ValidName";
            var versionMock = new Mock<IVersion>();
            var sut = new Package(name, versionMock.Object);
            //Assert
            Assert.IsNotNull(sut.Dependencies);
        }
        [Test]
        public void AssignProperDependencies_WhenOptionalParameterIsPassed()
        {
            //Arrange & Act
            string name = "ValidName";
            var versionMock = new Mock<IVersion>();
            var dependencies = new HashSet<IPackage>();
            var sut = new Package(name, versionMock.Object, dependencies);
            //Assert
            Assert.AreSame(dependencies, sut.Dependencies);
        }
        [Test]
        public void ThrowArgumentNullException_WhenNullNameIsPassed()
        {
            //Arrange
            var versionMock = new Mock<IVersion>();

            //Assert & Act
            Assert.Throws<ArgumentNullException>(() => new Package(null, versionMock.Object));
        }
        [Test]
        public void ThrowArgumentNullException_WhenNullVersionIsPassed()
        {
            //Arrange
            var name = "ValidName";

            //Assert & Act
            Assert.Throws<ArgumentNullException>(() => new Package(name, null));
        }
        [Test]
        public void AssignProperUrl_WhenValidDataIsPassed()
        {
            //Arrange & Act
            string name = "ValidName";
            var versionMock = new Mock<IVersion>();
            versionMock.Setup(v => v.Major).Returns(1);
            versionMock.Setup(v => v.Minor).Returns(1);
            versionMock.Setup(v => v.Patch).Returns(1);
            versionMock.Setup(v => v.VersionType).Returns(VersionType.alpha);
            var expectedString = string.Format("1.1.1-{0}", versionMock.Object.VersionType);
            var sut = new Package(name, versionMock.Object);
            //Assert
            StringAssert.AreEqualIgnoringCase(expectedString, sut.Url);
        }
    }
}
