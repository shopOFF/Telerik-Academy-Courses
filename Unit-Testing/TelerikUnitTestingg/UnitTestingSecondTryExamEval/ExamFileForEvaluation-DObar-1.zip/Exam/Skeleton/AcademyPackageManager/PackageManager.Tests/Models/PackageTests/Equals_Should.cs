﻿using Moq;
using NUnit.Framework;
using PackageManager.Enums;
using PackageManager.Models;
using PackageManager.Models.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PackageManager.Tests.Models.PackageTests
{
    [TestFixture]
    public class Equals_Should
    {
        [Test]
        public void ThrowArgumentNullException_WhenPassedValueIsNull()
        {
            // Arrange
            string name = "ValidName";
            var versionStub = new Mock<IVersion>();
            var sut = new Package(name, versionStub.Object);
            //Act & Assert
            Assert.Throws<ArgumentNullException>(() => sut.Equals(null));
        }
        [Test]
        public void ThrowArgumentException_WhenPassedValueIsNotIPachageObject()
        {
            // Arrange
            string name = "ValidName";
            var versionStub = new Mock<IVersion>();
            var sut = new Package(name, versionStub.Object);
            //Act & Assert
            Assert.Throws<ArgumentException>(() => sut.Equals(versionStub.Object));
        }
        [Test]
        public void ReturnTrue_WhenThePackagesAreTheSame()
        {
            // Arrange
            string name = "ValidName";
            var versionStub = new Mock<IVersion>();
            versionStub.Setup(v => v.Major).Returns(1);
            versionStub.Setup(v => v.Minor).Returns(1);
            versionStub.Setup(v => v.Patch).Returns(1);
            versionStub.Setup(v => v.VersionType).Returns(VersionType.alpha);
            var sut = new Package(name, versionStub.Object);
            var otherPackageStub = new Mock<IPackage>();
            otherPackageStub.Setup(p => p.Name).Returns(name);
            otherPackageStub.Setup(p => p.Version.Major).Returns(1);
            otherPackageStub.Setup(p => p.Version.Minor).Returns(1);
            otherPackageStub.Setup(p => p.Version.Patch).Returns(1);
            otherPackageStub.Setup(p => p.Version.VersionType).Returns(VersionType.alpha);

            //Act
            var result = sut.Equals(otherPackageStub.Object);

            //Assert
            Assert.AreEqual(true, result);
        }
        [Test]
        public void ReturnFalse_WhenTheNamesOfThePackagesAreDifferent()
        {
            // Arrange
            string name = "ValidName";
            var versionStub = new Mock<IVersion>();
            versionStub.Setup(v => v.Major).Returns(1);
            versionStub.Setup(v => v.Minor).Returns(1);
            versionStub.Setup(v => v.Patch).Returns(1);
            versionStub.Setup(v => v.VersionType).Returns(VersionType.alpha);
            var sut = new Package(name, versionStub.Object);
            var otherPackageStub = new Mock<IPackage>();
            string otherPackageName = "OtherValidName";
            otherPackageStub.Setup(p => p.Name).Returns(otherPackageName);
            otherPackageStub.Setup(p => p.Version.Major).Returns(1);
            otherPackageStub.Setup(p => p.Version.Minor).Returns(1);
            otherPackageStub.Setup(p => p.Version.Patch).Returns(1);
            otherPackageStub.Setup(p => p.Version.VersionType).Returns(VersionType.alpha);

            //Act
            var result = sut.Equals(otherPackageStub.Object);

            //Assert
            Assert.AreEqual(false, result);
        }
        [Test]
        public void ReturnFalse_WhenVersionMajorOfThePackagesAreDifferent()
        {
            // Arrange
            string name = "ValidName";
            var versionStub = new Mock<IVersion>();
            versionStub.Setup(v => v.Major).Returns(2);
            versionStub.Setup(v => v.Minor).Returns(1);
            versionStub.Setup(v => v.Patch).Returns(1);
            versionStub.Setup(v => v.VersionType).Returns(VersionType.alpha);
            var sut = new Package(name, versionStub.Object);
            var otherPackageStub = new Mock<IPackage>();
            otherPackageStub.Setup(p => p.Name).Returns(name);
            otherPackageStub.Setup(p => p.Version.Major).Returns(1);
            otherPackageStub.Setup(p => p.Version.Minor).Returns(1);
            otherPackageStub.Setup(p => p.Version.Patch).Returns(1);
            otherPackageStub.Setup(p => p.Version.VersionType).Returns(VersionType.alpha);

            //Act
            var result = sut.Equals(otherPackageStub.Object);

            //Assert
            Assert.AreEqual(false, result);
        }
        [Test]
        public void ReturnFalse_WhenVersionMinorOfThePackagesAreDifferent()
        {
            // Arrange
            string name = "ValidName";
            var versionStub = new Mock<IVersion>();
            versionStub.Setup(v => v.Major).Returns(1);
            versionStub.Setup(v => v.Minor).Returns(2);
            versionStub.Setup(v => v.Patch).Returns(1);
            versionStub.Setup(v => v.VersionType).Returns(VersionType.alpha);
            var sut = new Package(name, versionStub.Object);
            var otherPackageStub = new Mock<IPackage>();
            otherPackageStub.Setup(p => p.Name).Returns(name);
            otherPackageStub.Setup(p => p.Version.Major).Returns(1);
            otherPackageStub.Setup(p => p.Version.Minor).Returns(1);
            otherPackageStub.Setup(p => p.Version.Patch).Returns(1);
            otherPackageStub.Setup(p => p.Version.VersionType).Returns(VersionType.alpha);

            //Act
            var result = sut.Equals(otherPackageStub.Object);

            //Assert
            Assert.AreEqual(false, result);
        }
        [Test]
        public void ReturnFalse_WhenVersionPatchOfThePackagesAreDifferent()
        {
            // Arrange
            string name = "ValidName";
            var versionStub = new Mock<IVersion>();
            versionStub.Setup(v => v.Major).Returns(1);
            versionStub.Setup(v => v.Minor).Returns(1);
            versionStub.Setup(v => v.Patch).Returns(2);
            versionStub.Setup(v => v.VersionType).Returns(VersionType.alpha);
            var sut = new Package(name, versionStub.Object);
            var otherPackageStub = new Mock<IPackage>();
            otherPackageStub.Setup(p => p.Name).Returns(name);
            otherPackageStub.Setup(p => p.Version.Major).Returns(1);
            otherPackageStub.Setup(p => p.Version.Minor).Returns(1);
            otherPackageStub.Setup(p => p.Version.Patch).Returns(1);
            otherPackageStub.Setup(p => p.Version.VersionType).Returns(VersionType.alpha);

            //Act
            var result = sut.Equals(otherPackageStub.Object);

            //Assert
            Assert.AreEqual(false, result);
        }
        [Test]
        public void ReturnFalse_WhenVersionTypeOfThePackagesAreDifferent()
        {
            // Arrange
            string name = "ValidName";
            var versionStub = new Mock<IVersion>();
            versionStub.Setup(v => v.Major).Returns(1);
            versionStub.Setup(v => v.Minor).Returns(1);
            versionStub.Setup(v => v.Patch).Returns(1);
            versionStub.Setup(v => v.VersionType).Returns(VersionType.beta);
            var sut = new Package(name, versionStub.Object);
            var otherPackageStub = new Mock<IPackage>();
            otherPackageStub.Setup(p => p.Name).Returns(name);
            otherPackageStub.Setup(p => p.Version.Major).Returns(1);
            otherPackageStub.Setup(p => p.Version.Minor).Returns(1);
            otherPackageStub.Setup(p => p.Version.Patch).Returns(1);
            otherPackageStub.Setup(p => p.Version.VersionType).Returns(VersionType.alpha);

            //Act
            var result = sut.Equals(otherPackageStub.Object);

            //Assert
            Assert.AreEqual(false, result);
        }
    }
}
