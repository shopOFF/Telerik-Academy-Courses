﻿using Moq;
using NUnit.Framework;
using PackageManager.Models;
using PackageManager.Models.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PackageManager.Tests.Models.PackageTests
{
    [TestFixture]
    public class SetVersion_Should
    {
        [Test]
        public void AssignProperVersion_WhenValidDataIsPassed()
        {
            //Arrange
            string name = "ValidName";
            var versionStub = new Mock<IVersion>();
            var sut = new Package(name, versionStub.Object);
            var expectedVersionMock = new Mock<IVersion>();
            //Act
            sut.Version = expectedVersionMock.Object;
            //Assert
            Assert.AreEqual(expectedVersionMock.Object, sut.Version);
        }
    }
}
