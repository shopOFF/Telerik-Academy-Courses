﻿using NUnit.Framework;
using PackageManager.Enums;
using PackageManager.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PackageManager.Tests.Models.PackageVersionTest
{
    [TestFixture]
    public class Constructor_Should
    {
        [Test]
        public void AssignProperMajorValue_WhenValidDataIsPassed()
        {
            //Arrange & Act
            int major = 1;
            int minor = 1;
            int patch = 1;
            VersionType type = VersionType.alpha;
            var sut = new PackageVersion(major, minor, patch, type);
            //Assert
            Assert.AreEqual(major, sut.Major);
        }
        [Test]
        public void AssignProperMinorValue_WhenValidDataIsPassed()
        {
            //Arrange & Act
            int major = 1;
            int minor = 1;
            int patch = 1;
            VersionType type = VersionType.alpha;
            var sut = new PackageVersion(major, minor, patch, type);
            //Assert
            Assert.AreEqual(minor, sut.Minor);
        }
        [Test]
        public void AssignProperPatchValue_WhenValidDataIsPassed()
        {
            //Arrange & Act
            int major = 1;
            int minor = 1;
            int patch = 1;
            VersionType type = VersionType.alpha;
            var sut = new PackageVersion(major, minor, patch, type);
            //Assert
            Assert.AreEqual(patch, sut.Patch);
        }
        [Test]
        public void AssignProperVersionType_WhenValidDataIsPassed()
        {
            //Arrange & Act
            int major = 1;
            int minor = 1;
            int patch = 1;
            VersionType type = VersionType.alpha;
            var sut = new PackageVersion(major, minor, patch, type);
            //Assert
            Assert.AreEqual(type, sut.VersionType);
        }
        [Test]
        public void ThrowArgumentException_WhenInvalidMajorValueIsPassed()
        {
            //Arrange & Act & Assert
            int major = -1;
            int minor = 1;
            int patch = 1;
            VersionType type = VersionType.alpha;
            Assert.Throws<ArgumentException>(() => new PackageVersion(major, minor, patch, type));
        }
        [Test]
        public void ThrowArgumentException_WhenInvalidMinorValueIsPassed()
        {
            //Arrange & Act & Assert
            int major = 1;
            int minor = -1;
            int patch = 1;
            VersionType type = VersionType.alpha;
            Assert.Throws<ArgumentException>(() => new PackageVersion(major, minor, patch, type));
        }
        [Test]
        public void ThrowArgumentException_WhenInvalidValuePatchIsPassed()
        {
            //Arrange & Act & Assert
            int major = 1;
            int minor = 1;
            int patch = -1;
            VersionType type = VersionType.alpha;
            Assert.Throws<ArgumentException>(() => new PackageVersion(major, minor, patch, type));
        }
        [Test]
        public void ThrowArgumentException_WhenInvalidVersionTypeIsPassed()
        {
            //Arrange & Act & Assert
            int major = 1;
            int minor = 1;
            int patch = 1;
            VersionType type = (VersionType)50;
            Assert.Throws<ArgumentException>(() => new PackageVersion(major, minor, patch, type));
        }
    }
}
