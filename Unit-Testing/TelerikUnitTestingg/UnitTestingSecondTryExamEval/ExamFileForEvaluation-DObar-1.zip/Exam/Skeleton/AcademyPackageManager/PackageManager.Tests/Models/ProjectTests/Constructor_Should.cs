﻿using NUnit.Framework;
using PackageManager.Models;
using PackageManager.Models.Contracts;
using PackageManager.Repositories.Contracts;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PackageManager.Tests.Models.ProjectTest
{
    [TestFixture]
    public class Constructor_Should
    {
        [Test]
        public void AssignProperName_WhenValidDataIsPassed()
        {
            //Arrange & Act
            string name = "ValidName";
            string location = "ValidLocation";
            var sut = new Project(name, location);
            //Assert
            Assert.AreEqual(name, sut.Name);
        }
        [Test]
        public void AssignProperLocation_WhenValidDataIsPassed()
        {
            //Arrange & Act
            string name = "ValidName";
            string location = "ValidLocation";
            var sut = new Project(name, location);
            //Assert
            Assert.AreEqual(location, sut.Location);
        }
        [Test]
        public void AssignProperPackageRepository_WhenOptionalParameterIsNotPassed()
        {
            //Arrange & Act
            string name = "ValidName";
            string location = "ValidLocation";
            var sut = new Project(name, location);
            //Assert
            Assert.IsInstanceOf<IRepository<IPackage>>(sut.PackageRepository);
        }
        [Test]
        public void AssignProperPackageRepository_WhenOptionalParameterIsPassed()
        {
            //Arrange & Act
            string name = "ValidName";
            string location = "ValidLocation";
            var packageRepository = new Mock<IRepository<IPackage>>();
            var sut = new Project(name, location, packageRepository.Object);
            //Assert
            Assert.AreSame(packageRepository.Object, sut.PackageRepository);
        }
        [Test]
        public void ThrowArgumentNullException_WhenNullNameIsPassed()
        {
            //Arrange
            string location = "ValidLocation";

            //Act & Assert
            Assert.Throws<ArgumentNullException>(() => new Project(null, location));
        }
        [Test]
        public void ThrowArgumentNullException_WhenNullLocationIsPassed()
        {
            //Arrange & Act
            string name = "ValidName";

            //Act & Assert
            Assert.Throws<ArgumentNullException>(() => new Project(name, null));
        }

    }
}
