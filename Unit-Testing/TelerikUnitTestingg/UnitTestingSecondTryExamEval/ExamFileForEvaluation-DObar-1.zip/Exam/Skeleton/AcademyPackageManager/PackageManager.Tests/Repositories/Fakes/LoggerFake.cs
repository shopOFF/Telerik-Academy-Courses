﻿using PackageManager.Info.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PackageManager.Tests.Repositories.Fakes
{
    public class LoggerFake : ILogger
    {

        public string Message { get; private set; } = "";

        public void Log(string message)
        {
            this.Message += message;
        }
    }
}
