﻿using Moq;
using NUnit.Framework;
using PackageManager.Info.Contracts;
using PackageManager.Models.Contracts;
using PackageManager.Repositories;
using PackageManager.Tests.Repositories.Fakes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PackageManager.Tests.Repositories.PackageRepositoryTests
{
    [TestFixture]
    public class Add_Should
    {
        [Test]
        public void ThrowArgumentNullException_WhenNullValueIsPassed()
        {
            //Arrange
            var loggerMock = new Mock<ILogger>();
            var packageMoch = new Mock<IPackage>();
            packageMoch.Setup(p => p.Name).Returns("ValidName");
            var packageCollection = new List<IPackage>() { packageMoch.Object };
            var sut = new PackageRepository(loggerMock.Object, packageCollection);
            //Act & Assert
            Assert.Throws<ArgumentNullException>(() => sut.Add(null));
        }
        [Test]
        public void AddThePackage_WhenThePackageDoesNotExist()
        {
            //Arrange
            var loggerMock = new Mock<ILogger>();
            var packageMoch = new Mock<IPackage>();
            packageMoch.Setup(p => p.Name).Returns("ValidName");
            var packageCollection = new List<IPackage>() { };
            var sut = new PackageRepository(loggerMock.Object, packageCollection);
            //Act 
            sut.Add(packageMoch.Object);
            //Assert
            Assert.AreEqual(1, packageCollection.Count);
        }
        [Test]
        public void LogStringContainingSameVersion_WhenThePackageExistWithTheSameName()
        {
            //Arrange
            var loggerFake = new LoggerFake();
            var packageMoch = new Mock<IPackage>();
            packageMoch.Setup(p => p.Name).Returns("ValidName");
            packageMoch.Setup(p => p.CompareTo(It.IsAny<IPackage>())).Returns(0);
            var packageCollection = new List<IPackage>() { packageMoch.Object };
            var sut = new PackageRepository(loggerFake, packageCollection);
            //Act 
            sut.Add(packageMoch.Object);
            //Assert
            StringAssert.Contains("Package with the same version is already installed", loggerFake.Message);
        }
        [Test]
        public void UpdateTheVersion_WhenTheNewOneIsBiggerThenExistingOne()
        {

            //Arrange
            var loggerFake = new LoggerFake();
            var packageMoch = new Mock<IPackage>();
            var packageMochBase = new Mock<IPackage>();
            packageMochBase.SetupAllProperties();
            packageMochBase.Setup(p => p.Name).Returns("ValidName");
            packageMoch.Setup(p => p.Name).Returns("ValidName");
            packageMoch.Setup(p => p.CompareTo(It.IsAny<IPackage>())).Returns(1);

            var versionMock = new Mock<IVersion>();
            packageMoch.Setup(p => p.Version).Returns(versionMock.Object);

            var packageCollection = new List<IPackage>() { packageMochBase.Object };
            var sut = new PackageRepository(loggerFake, packageCollection);
            //Act 
            sut.Add(packageMoch.Object);
            //Assert
            Assert.AreSame(versionMock.Object, packageMochBase.Object.Version);
        }
        [Test]
        public void LogStringContainingNewerVersion_WhenPackageExistWithHigherVersion()
        {
            //Arrange
            var loggerFake = new LoggerFake();
            var packageMoch = new Mock<IPackage>();
            packageMoch.Setup(p => p.Name).Returns("ValidName");
            packageMoch.Setup(p => p.CompareTo(It.IsAny<IPackage>())).Returns(-1);
            var packageCollection = new List<IPackage>() { packageMoch.Object };
            var sut = new PackageRepository(loggerFake, packageCollection);
            //Act 
            sut.Add(packageMoch.Object);
            //Assert
            StringAssert.Contains(" There is a package with newer version", loggerFake.Message);


        }
    }
}
