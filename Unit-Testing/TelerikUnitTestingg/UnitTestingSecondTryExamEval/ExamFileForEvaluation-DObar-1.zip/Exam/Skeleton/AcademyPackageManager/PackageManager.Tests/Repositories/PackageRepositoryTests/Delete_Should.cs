﻿using Moq;
using NUnit.Framework;
using PackageManager.Info.Contracts;
using PackageManager.Models.Contracts;
using PackageManager.Repositories;
using PackageManager.Tests.Repositories.Fakes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PackageManager.Tests.Repositories.PackageRepositoryTests
{
    [TestFixture]
    public class Delete_Should
    {
        [Test]
        public void ThrowArgumentNullException_WhenPassedPackageIsNull()
        {
            //Arrange
            var loggerMock = new Mock<ILogger>();
            var packageMoch = new Mock<IPackage>();
            var packageCollection = new List<IPackage>() { packageMoch.Object };
            var sut = new PackageRepository(loggerMock.Object, packageCollection);
            //Act & Assert
            Assert.Throws<ArgumentNullException>(() => sut.Delete(null));
        }
        [Test]
        public void ThrowArgumentNullExceptionAndAddOnTheLoggerPackageDoesNotExist()
        {
            //Arrange
            var loggerFake = new LoggerFake();
            var packageMoch = new Mock<IPackage>();
            var packageCollection = new List<IPackage>() { };
            var sut = new PackageRepository(loggerFake, packageCollection);

            //Act & Assert
            Assert.Throws<ArgumentNullException>(() => sut.Delete(packageMoch.Object));
            StringAssert.Contains("package does not exist", loggerFake.Message);
        }
        [Test]
        public void ReturnTheDeletedPackage()
        {
            //Arrange
            var loggerFake = new LoggerFake();
            var packageMoch = new Mock<IPackage>();
            packageMoch.Setup(p => p.Equals(It.IsAny<Object>())).Returns(true);
            packageMoch.Setup(p => p.Dependencies).Returns(new List<IPackage>());
            var packageCollection = new List<IPackage>() { packageMoch.Object };
            var sut = new PackageRepository(loggerFake, packageCollection);

            //Act 
            var deletedPackage = sut.Delete(packageMoch.Object);

            //Assert
            Assert.AreSame(deletedPackage, packageMoch.Object);
        }
        [Test]
        public void DoesNotRemove_WhenThePackageHaveDependency()
        {
            //Arrange
            var loggerFake = new LoggerFake();
            var packageMoch = new Mock<IPackage>();
            packageMoch.Setup(p => p.Equals(It.IsAny<Object>())).Returns(true);
            packageMoch.Setup(p => p.Dependencies).Returns(new List<IPackage>() { packageMoch.Object });
            var packageCollection = new List<IPackage>() { packageMoch.Object };
            var sut = new PackageRepository(loggerFake, packageCollection);

            //Act 
            sut.Delete(packageMoch.Object);

            //Assert
            StringAssert.Contains("package is a dependency", loggerFake.Message);
        }
    }
}
