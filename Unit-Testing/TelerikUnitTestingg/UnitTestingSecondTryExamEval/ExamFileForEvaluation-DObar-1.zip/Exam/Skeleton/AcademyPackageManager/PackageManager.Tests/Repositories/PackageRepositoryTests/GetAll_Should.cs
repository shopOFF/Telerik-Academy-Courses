﻿using Moq;
using NUnit.Framework;
using PackageManager.Info.Contracts;
using PackageManager.Models.Contracts;
using PackageManager.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PackageManager.Tests.Repositories.PackageRepositoryTests
{
    [TestFixture]
    public class GetAll_Should
    {
        [Test]
        public void ReturnEmptyCollection_WhenRepositoryIsCreatedWithoutPackages()
        {
            //Arrange
            var loggerMock = new Mock<ILogger>();
            var sut = new PackageRepository(loggerMock.Object);
            //Act 
            var result = sut.GetAll();
            //Assert
            Assert.AreEqual(0, result.Count());
        }
        [Test]
        public void ReturnTheCollection_WhenRepositoryIsCreatedWithNoEmptyCollection()
        {
            //Arrange
            var loggerMock = new Mock<ILogger>();
            var packageMoch = new Mock<IPackage>();
            var packageCollection = new List<IPackage>() { packageMoch.Object };
            var sut = new PackageRepository(loggerMock.Object, packageCollection);
            //Act 
            var result = sut.GetAll();
            //Assert
            Assert.AreEqual(packageCollection.Count, result.Count());
        }
    }
}
