﻿using Moq;
using NUnit.Framework;
using PackageManager.Info.Contracts;
using PackageManager.Models.Contracts;
using PackageManager.Repositories;
using PackageManager.Tests.Repositories.Fakes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PackageManager.Tests.Repositories.PackageRepositoryTests
{
    [TestFixture]
    public class Update_Should
    {
        [Test]
        public void ThrowArgumentNullException_WhenNullValueIsPassed()
        {
            //Arrange
            var loggerMock = new Mock<ILogger>();
            var packageMock = new Mock<IPackage>();
            var packageCollection = new List<IPackage>() { packageMock.Object };
            var sut = new PackageRepository(loggerMock.Object, packageCollection);
            //Act & Assert
            Assert.Throws<ArgumentNullException>(() => sut.Update(null));
        }
        [Test]
        public void ThrowArgumentNullExceptionAndLogPackageDoesNotExist()
        {
            //Arrange
            var loggerFake = new LoggerFake();
            var packageMock = new Mock<IPackage>();
            packageMock.Setup(p => p.Name).Returns("ValidName");
            var packageCollection = new List<IPackage>() { };
            var sut = new PackageRepository(loggerFake, packageCollection);
            //Act & Assert
            Assert.Throws<ArgumentNullException>(() => sut.Update(packageMock.Object));
            StringAssert.Contains("package does not exist", loggerFake.Message);
        }
        [Test]
        public void UpdateTheVersion_WhenTheNewOneIsBiggerThenExistingOne()
        {
            //Arrange
            var loggerFake = new LoggerFake();
            var packageMoch = new Mock<IPackage>();
            var packageMochBase = new Mock<IPackage>();
            packageMochBase.SetupAllProperties();
            packageMochBase.Setup(p => p.Name).Returns("ValidName");
            packageMoch.Setup(p => p.Name).Returns("ValidName");
            packageMoch.Setup(p => p.CompareTo(It.IsAny<IPackage>())).Returns(1);

            var versionMock = new Mock<IVersion>();
            packageMoch.Setup(p => p.Version).Returns(versionMock.Object);

            var packageCollection = new List<IPackage>() { packageMochBase.Object };
            var sut = new PackageRepository(loggerFake, packageCollection);
            //Act 
            var result = sut.Update(packageMoch.Object);
            //Assert
            Assert.AreEqual(true, result);
            Assert.AreSame(versionMock.Object, packageMochBase.Object.Version);
        }
        [Test]
        public void ThrowArgumentExceptionAndLogPackageHasHigherVersion()
        {
            //Arrange
            var loggerFake = new LoggerFake();
            var packageMoch = new Mock<IPackage>();
            var packageMochBase = new Mock<IPackage>();
            packageMochBase.Setup(p => p.Name).Returns("ValidName");
            packageMoch.Setup(p => p.Name).Returns("ValidName");
            packageMoch.Setup(p => p.CompareTo(It.IsAny<IPackage>())).Returns(-1);

            var versionMock = new Mock<IVersion>();
            packageMoch.Setup(p => p.Version).Returns(versionMock.Object);

            var packageCollection = new List<IPackage>() { packageMochBase.Object };
            var sut = new PackageRepository(loggerFake, packageCollection);

            //Act & Assert
            Assert.Throws<ArgumentException>(() => sut.Update(packageMoch.Object));
            StringAssert.Contains("package has higher version", loggerFake.Message);
        }
        [Test]
        public void ReturnFalseAndLogSameVersion_WhenPackageWithSameVersionIsFound()
        {
            //Arrange
            var loggerFake = new LoggerFake();
            var packageMoch = new Mock<IPackage>();
            var packageMochBase = new Mock<IPackage>();
            packageMochBase.Setup(p => p.Name).Returns("ValidName");
            packageMoch.Setup(p => p.Name).Returns("ValidName");
            packageMoch.Setup(p => p.CompareTo(It.IsAny<IPackage>())).Returns(0);

            var versionMock = new Mock<IVersion>();
            packageMoch.Setup(p => p.Version).Returns(versionMock.Object);

            var packageCollection = new List<IPackage>() { packageMochBase.Object };
            var sut = new PackageRepository(loggerFake, packageCollection);

            //Act 
            var result = sut.Update(packageMoch.Object);
            // Assert
            Assert.AreEqual(false, result);
            StringAssert.Contains("same version", loggerFake.Message);
        }
    }
}
