﻿using System;
using System.Text;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using PackageManager.Commands;
using Moq;
using PackageManager.Models.Contracts;
using PackageManager.Core.Contracts;
using PackageManager.Tests.Commands.MockObjects;
using PackageManager.Enums;

namespace PackageManager.Tests.Commands.InstallComandTests
{
    [TestClass]
    public class Constructor_Should
    {
        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void ThrowArgumentNullException_WhenInstallerIsNull()
        {
            //Arrange
            var packageMock = new Mock<IPackage>();

            //Act & Assert
            InstallCommand installCommand = new InstallCommand(null, packageMock.Object);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void ThrowArgumentNullException_WhenPackageIsNull()
        {
            //Arrange
            var installerMock = new Mock<IInstaller<IPackage>>();

            //Act & Assert
            InstallCommand installCommand = new InstallCommand(installerMock.Object, null);
        }

        [TestMethod]
        public void SetInstaller_WhenInstallerIsNotNull()
        {
            //Arrange
            var installerMock = new Mock<IInstaller<IPackage>>();

            var packageMock = new Mock<IPackage>();

            //Act
            InstallCommandMock installCommand = new InstallCommandMock(installerMock.Object, packageMock.Object);

            // Assert
            Assert.AreSame(installerMock.Object, installCommand.InstallerExposed);
        }

        [TestMethod]
        public void SetInstallerOperationToInstall_WhenInstallerIsNotNull()
        {
            //Arrange
            var installerMock = new Mock<IInstaller<IPackage>>();

            var packageMock = new Mock<IPackage>();

            //Act
            InstallCommandMock installCommand = new InstallCommandMock(installerMock.Object, packageMock.Object);

            // Assert
            Assert.AreEqual(installCommand.InstallerExposed.Operation, InstallerOperation.Install);
        }

        [TestMethod]
        public void SetPackage_WhenInstallerIsNotNull()
        {
            //Arrange
            var installerMock = new Mock<IInstaller<IPackage>>();

            var packageMock = new Mock<IPackage>();

            //Act
            InstallCommandMock installCommand = new InstallCommandMock(installerMock.Object, packageMock.Object);

            // Assert
            Assert.AreSame(packageMock.Object, installCommand.PackageExposed);
        }
    }
}
