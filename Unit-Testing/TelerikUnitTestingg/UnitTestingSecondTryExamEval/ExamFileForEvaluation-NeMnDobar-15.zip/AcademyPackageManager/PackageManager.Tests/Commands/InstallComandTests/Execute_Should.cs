﻿using System;
using System.Text;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using PackageManager.Commands;
using Moq;
using PackageManager.Models.Contracts;
using PackageManager.Core.Contracts;
using PackageManager.Tests.Commands.MockObjects;
using PackageManager.Enums;

namespace PackageManager.Tests.Commands.InstallComandTests
{
    [TestClass]
    public class Execute_Should
    {
        [TestMethod]
        public void CallInstallerPerformOperation()
        {
            //Arrange
            var installerMock = new Mock<IInstaller<IPackage>>();

            installerMock.Setup(x => x.PerformOperation(It.IsAny<IPackage>()));

            var packageMock = new Mock<IPackage>();

            InstallCommandMock installCommand = new InstallCommandMock(installerMock.Object, packageMock.Object);

            //Act
            installCommand.Execute();

            installerMock.Verify(x=> x.PerformOperation(It.IsAny<IPackage>()), Times.Once());
        }
    }
}
