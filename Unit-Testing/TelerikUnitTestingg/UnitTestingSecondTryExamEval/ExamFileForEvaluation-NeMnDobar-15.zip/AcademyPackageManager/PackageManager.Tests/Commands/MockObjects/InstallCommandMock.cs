﻿using PackageManager.Commands;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PackageManager.Core.Contracts;
using PackageManager.Models.Contracts;

namespace PackageManager.Tests.Commands.MockObjects
{
    internal class InstallCommandMock : InstallCommand
    {
        public InstallCommandMock(IInstaller<IPackage> installer, IPackage package) : base(installer, package)
        {
        }

        public IInstaller<IPackage> InstallerExposed
        {
            get
            {
                return this.Installer;
            }
        }

        public IPackage PackageExposed
        {
            get
            {
                return this.Package;
            }
        }
    }
}
