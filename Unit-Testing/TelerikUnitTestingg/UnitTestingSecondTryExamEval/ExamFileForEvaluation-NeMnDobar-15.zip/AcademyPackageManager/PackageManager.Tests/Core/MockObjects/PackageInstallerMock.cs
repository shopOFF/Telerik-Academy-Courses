﻿using PackageManager.Commands;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PackageManager.Core.Contracts;
using PackageManager.Models.Contracts;
using PackageManager.Core;

namespace PackageManager.Tests.Core.MockObjects
{
    internal class PackageInstallerMock : PackageInstaller
    {
        public PackageInstallerMock(IDownloader downloader, IProject project) : base(downloader, project)
        {
        }

        public IDownloader DownloaderExposed
        {
            get
            {
                return this.Downloader;
            }
        }

        public IProject ProjectExposed
        {
            get
            {
                return this.Project;
            }
        }
    }
}
