﻿using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using PackageManager.Models.Contracts;
using PackageManager.Core.Contracts;
using PackageManager.Enums;
using PackageManager.Tests.Core.MockObjects;

namespace PackageManager.Tests.Core.PackageInstallerTests
{
    [TestClass]
    public class Constructor_Should
    {
        [TestMethod]
        public void SetDownloader_WhenDownloaderIsPassed()
        {
            //Arrange
            var downloaderMock = new Mock<IDownloader>();

            var projectMock = new Mock<IProject>();
            projectMock.Setup(x => x.PackageRepository.GetAll()).Returns(new List<IPackage>());

            //Act
            PackageInstallerMock packageInstaller = new PackageInstallerMock(downloaderMock.Object, projectMock.Object);

            // Assert
            Assert.AreSame(downloaderMock.Object, packageInstaller.DownloaderExposed);
        }

        [TestMethod]
        public void SetProject_WhenProjectIsPassed()
        {
            //Arrange
            var downloaderMock = new Mock<IDownloader>();

            var projectMock = new Mock<IProject>();
            projectMock.Setup(x => x.PackageRepository.GetAll()).Returns(new List<IPackage>());

            //Act
            PackageInstallerMock packageInstaller = new PackageInstallerMock(downloaderMock.Object, projectMock.Object);

            // Assert
            Assert.AreSame(projectMock.Object, packageInstaller.ProjectExposed);
        }

        [TestMethod]
        public void SetDownloaderLocationToProjectLocationPlusBasicFolder()
        {
            //Arrange
            var downloaderMock = new Mock<IDownloader>();
            string location = string.Empty;
            downloaderMock.SetupProperty(x => x.Location);

            var projectMock = new Mock<IProject>();
            projectMock.Setup(x => x.PackageRepository.GetAll()).Returns(new List<IPackage>());
            projectMock.SetupGet(x => x.Location).Returns("location");
           
            //Act
            PackageInstallerMock packageInstaller = new PackageInstallerMock(downloaderMock.Object, projectMock.Object);

            // Assert
            string expectedLocation = "location" + "\\" + packageInstaller.BasicFolder;
            Assert.AreEqual(expectedLocation, packageInstaller.DownloaderExposed.Location);
        }

        [TestMethod]
        public void ChangeOperationToInstall()
        {
            //Arrange
            var downloaderMock = new Mock<IDownloader>();

            var projectMock = new Mock<IProject>();

            var packageMock = new Mock<IPackage>();
            packageMock.SetupGet(x => x.Dependencies).Returns(new List<IPackage>());

            var packagesMocked = new List<IPackage>() { packageMock.Object};
            projectMock.Setup(x => x.PackageRepository.GetAll()).Returns(packagesMocked);
            projectMock.Setup(x => x.PackageRepository.Add(It.IsAny<IPackage>()));

            //Act
            PackageInstallerMock packageInstaller = new PackageInstallerMock(downloaderMock.Object, projectMock.Object);

            // Assert           
            Assert.AreEqual(InstallerOperation.Install, packageInstaller.Operation);
        }

        [TestMethod]
        public void RestorePackages_WhenNoDependencies()
        {
            //Arrange
            var downloaderMock = new Mock<IDownloader>();

            var projectMock = new Mock<IProject>();

            var packageMock = new Mock<IPackage>();        
            var packageTwo = new Mock<IPackage>();

            packageMock.SetupGet(x => x.Dependencies).Returns(new List<IPackage>());
            packageTwo.SetupGet(x => x.Dependencies).Returns(new List<IPackage>());
            var packagesMocked = new List<IPackage>() { packageMock.Object, packageTwo.Object };

            projectMock.Setup(x => x.PackageRepository.GetAll()).Returns(packagesMocked);
            projectMock.Setup(x => x.PackageRepository.Add(It.IsAny<IPackage>()));
            
            //Act
            PackageInstallerMock packageInstaller = new PackageInstallerMock(downloaderMock.Object, projectMock.Object);

            // Assert           
            projectMock.Verify(x => x.PackageRepository.Add(It.IsAny<IPackage>()), Times.Exactly(2));
        }

        [TestMethod]
        public void RestorePackages_WhenThereAreDependencies()
        {
            //Arrange
            var downloaderMock = new Mock<IDownloader>();

            var projectMock = new Mock<IProject>();

            var packageMock = new Mock<IPackage>();
            var packageTwo = new Mock<IPackage>();

            packageTwo.SetupGet(x => x.Dependencies).Returns(new List<IPackage>());
            packageMock.SetupGet(x => x.Dependencies).Returns(new List<IPackage>() { packageTwo.Object});
           
            var packagesMocked = new List<IPackage>() { packageMock.Object};

            projectMock.Setup(x => x.PackageRepository.GetAll()).Returns(packagesMocked);
            projectMock.Setup(x => x.PackageRepository.Add(It.IsAny<IPackage>()));

            //Act
            PackageInstallerMock packageInstaller = new PackageInstallerMock(downloaderMock.Object, projectMock.Object);

            // Assert           
            projectMock.Verify(x => x.PackageRepository.Add(It.IsAny<IPackage>()), Times.Exactly(2));
        }

        [TestMethod]
        public void NotAddPackageIfThereAreNone()
        {
            //Arrange
            var downloaderMock = new Mock<IDownloader>();

            var projectMock = new Mock<IProject>();

            projectMock.Setup(x => x.PackageRepository.GetAll()).Returns(new List<IPackage>());
            projectMock.Setup(x => x.PackageRepository.Add(It.IsAny<IPackage>()));

            //Act
            PackageInstallerMock packageInstaller = new PackageInstallerMock(downloaderMock.Object, projectMock.Object);

            // Assert           
            projectMock.Verify(x => x.PackageRepository.Add(It.IsAny<IPackage>()), Times.Never);
        }
    }
}
