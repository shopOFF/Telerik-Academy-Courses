﻿using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using PackageManager.Models.Contracts;
using PackageManager.Core.Contracts;
using PackageManager.Enums;
using PackageManager.Tests.Core.MockObjects;

namespace PackageManager.Tests.Core.PackageInstallerTests
{
    [TestClass]
    public class PerformOperation_Should
    {
        [TestMethod]
        public void CallDownloadTwice_WhenInstallAndNoDependencies()
        {
            //Arrange
            var downloaderMock = new Mock<IDownloader>();
            downloaderMock.Setup(x => x.Download(It.IsAny<string>()));

            var projectMock = new Mock<IProject>();

            var packageMock = new Mock<IPackage>();

            packageMock.SetupGet(x => x.Dependencies).Returns(new List<IPackage>());
            var packagesMocked = new List<IPackage>() { packageMock.Object};

            projectMock.Setup(x => x.PackageRepository.GetAll()).Returns(packagesMocked);
            projectMock.Setup(x => x.PackageRepository.Add(It.IsAny<IPackage>()));

            //Act
            PackageInstallerMock packageInstaller = new PackageInstallerMock(downloaderMock.Object, projectMock.Object);

            // Assert           
            downloaderMock.Verify(x => x.Download(It.IsAny<string>()), Times.Exactly(2));
        }

        [TestMethod]
        public void CallDownloadTwiceForeachDependency_WhenInstallAndThereAreDependencies()
        {
            //Arrange
            var downloaderMock = new Mock<IDownloader>();
            downloaderMock.Setup(x => x.Download(It.IsAny<string>()));

            var projectMock = new Mock<IProject>();

            var packageMock = new Mock<IPackage>();
            var packageTwo = new Mock<IPackage>();

            packageTwo.SetupGet(x => x.Dependencies).Returns(new List<IPackage>());
            packageMock.SetupGet(x => x.Dependencies).Returns(new List<IPackage>() { packageTwo.Object });
            var packagesMocked = new List<IPackage>() { packageMock.Object};

            projectMock.Setup(x => x.PackageRepository.GetAll()).Returns(packagesMocked);
            projectMock.Setup(x => x.PackageRepository.Add(It.IsAny<IPackage>()));

            //Act
            PackageInstallerMock packageInstaller = new PackageInstallerMock(downloaderMock.Object, projectMock.Object);

            // Assert           
            downloaderMock.Verify(x => x.Download(It.IsAny<string>()), Times.Exactly(4));
        }
    }
}
