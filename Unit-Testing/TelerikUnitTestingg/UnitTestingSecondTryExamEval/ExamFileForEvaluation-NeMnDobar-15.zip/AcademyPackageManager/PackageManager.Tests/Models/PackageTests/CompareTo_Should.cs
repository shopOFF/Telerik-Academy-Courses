﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using PackageManager.Models;
using PackageManager.Enums;
using Moq;
using PackageManager.Models.Contracts;
using System.Collections.Generic;

namespace PackageManager.Tests.Models.PackageTests
{
    [TestClass]
    public class CompareTo_Should
    {
        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void ThrowArgumentNullException_WhenTheComparedWithObjectIsNull()
        {
            //Arrange
            var versionMock = new Mock<IVersion>();
            var dependenciesMock = new Mock<ICollection<IPackage>>();
            Package sut = new Package("pesho", versionMock.Object, dependenciesMock.Object);

            //Act & Assert
            sut.CompareTo(null);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void ThrowArgumentException_WhenTheComparedObjectsNamesAreNotEqual()
        {
            //Arrange
            var versionMock = new Mock<IVersion>();
            var dependenciesMock = new Mock<ICollection<IPackage>>();
            Package sut = new Package("pesho", versionMock.Object, dependenciesMock.Object);
            Package packageToCompareWith = new Package("pesho124", versionMock.Object, dependenciesMock.Object);
            //Act & Assert
            sut.CompareTo(packageToCompareWith);
        }

        [TestMethod]
        public void ReturnOne_WhenTheMajorVersionOfComparingPackageIsBiggerThanTheOtherObject()
        {
            //Arrange
            var versionMock = new Mock<IVersion>();
            versionMock.SetupGet(x => x.Major).Returns(2);
            versionMock.SetupGet(x => x.Minor).Returns(1);
            versionMock.SetupGet(x => x.Patch).Returns(4);
            versionMock.SetupGet(x => x.VersionType).Returns(VersionType.alpha);
            var versionMock2 = new Mock<IVersion>();

            versionMock2.SetupGet(x => x.Major).Returns(1);
            versionMock2.SetupGet(x => x.Minor).Returns(1);
            versionMock2.SetupGet(x => x.Patch).Returns(4);
            versionMock2.SetupGet(x => x.VersionType).Returns(VersionType.alpha);
           
            Package sut = new Package("pesho", versionMock.Object);

            Package packageToCompareWith = new Package("pesho", versionMock2.Object);
            //Act & Assert
            Assert.AreEqual(1, sut.CompareTo(packageToCompareWith));
        }

        [TestMethod]
        public void ReturnOne_WhenTheMajorVersionsAreSameButMinorIsBigger()
        {
            //Arrange
            var versionMock = new Mock<IVersion>();
            versionMock.SetupGet(x => x.Major).Returns(2);
            versionMock.SetupGet(x => x.Minor).Returns(2);
            versionMock.SetupGet(x => x.Patch).Returns(4);
            versionMock.SetupGet(x => x.VersionType).Returns(VersionType.alpha);
            var versionMock2 = new Mock<IVersion>();

            versionMock2.SetupGet(x => x.Major).Returns(2);
            versionMock2.SetupGet(x => x.Minor).Returns(1);
            versionMock2.SetupGet(x => x.Patch).Returns(4);
            versionMock2.SetupGet(x => x.VersionType).Returns(VersionType.alpha);

            Package sut = new Package("pesho", versionMock.Object);

            Package packageToCompareWith = new Package("pesho", versionMock2.Object);
            //Act & Assert
            Assert.AreEqual(1, sut.CompareTo(packageToCompareWith));
        }

        [TestMethod]
        public void ReturnOne_WhenTheMajorAndMinorVersionsAreSameButPatchIsBigger()
        {
            //Arrange
            var versionMock = new Mock<IVersion>();
            versionMock.SetupGet(x => x.Major).Returns(2);
            versionMock.SetupGet(x => x.Minor).Returns(2);
            versionMock.SetupGet(x => x.Patch).Returns(5);
            versionMock.SetupGet(x => x.VersionType).Returns(VersionType.alpha);
            var versionMock2 = new Mock<IVersion>();

            versionMock2.SetupGet(x => x.Major).Returns(2);
            versionMock2.SetupGet(x => x.Minor).Returns(2);
            versionMock2.SetupGet(x => x.Patch).Returns(4);
            versionMock2.SetupGet(x => x.VersionType).Returns(VersionType.alpha);

            Package sut = new Package("pesho", versionMock.Object);

            Package packageToCompareWith = new Package("pesho", versionMock2.Object);
            //Act & Assert
            Assert.AreEqual(1, sut.CompareTo(packageToCompareWith));
        }

        [TestMethod]
        public void ReturnOne_WhenTheMajorAndMinorAndPatchVersionsAreSameButVersionTypeIsBigger()
        {
            //Arrange
            var versionMock = new Mock<IVersion>();
            versionMock.SetupGet(x => x.Major).Returns(2);
            versionMock.SetupGet(x => x.Minor).Returns(2);
            versionMock.SetupGet(x => x.Patch).Returns(4);
            versionMock.SetupGet(x => x.VersionType).Returns(VersionType.beta);
            var versionMock2 = new Mock<IVersion>();

            versionMock2.SetupGet(x => x.Major).Returns(2);
            versionMock2.SetupGet(x => x.Minor).Returns(2);
            versionMock2.SetupGet(x => x.Patch).Returns(4);
            versionMock2.SetupGet(x => x.VersionType).Returns(VersionType.alpha);

            Package sut = new Package("pesho", versionMock.Object);

            Package packageToCompareWith = new Package("pesho", versionMock2.Object);
            //Act & Assert
            Assert.AreEqual(1, sut.CompareTo(packageToCompareWith));
        }

        [TestMethod]
        public void ReturnZero_WhenNameAndVersionIsTheSame()
        {
            //Arrange
            var versionMock = new Mock<IVersion>();
            versionMock.SetupGet(x => x.Major).Returns(2);
            versionMock.SetupGet(x => x.Minor).Returns(2);
            versionMock.SetupGet(x => x.Patch).Returns(4);
            versionMock.SetupGet(x => x.VersionType).Returns(VersionType.alpha);
            var versionMock2 = new Mock<IVersion>();

            versionMock2.SetupGet(x => x.Major).Returns(2);
            versionMock2.SetupGet(x => x.Minor).Returns(2);
            versionMock2.SetupGet(x => x.Patch).Returns(4);
            versionMock2.SetupGet(x => x.VersionType).Returns(VersionType.alpha);

            Package sut = new Package("pesho", versionMock.Object);

            Package packageToCompareWith = new Package("pesho", versionMock2.Object);
            //Act & Assert
            Assert.AreEqual(0, sut.CompareTo(packageToCompareWith));
        }

        [TestMethod]
        public void ReturnMinusOne_WhenVersionMajorIsSmaller()
        {
            //Arrange
            var versionMock = new Mock<IVersion>();
            versionMock.SetupGet(x => x.Major).Returns(1);
            versionMock.SetupGet(x => x.Minor).Returns(2);
            versionMock.SetupGet(x => x.Patch).Returns(4);
            versionMock.SetupGet(x => x.VersionType).Returns(VersionType.alpha);
            var versionMock2 = new Mock<IVersion>();

            versionMock2.SetupGet(x => x.Major).Returns(2);
            versionMock2.SetupGet(x => x.Minor).Returns(2);
            versionMock2.SetupGet(x => x.Patch).Returns(4);
            versionMock2.SetupGet(x => x.VersionType).Returns(VersionType.alpha);

            Package sut = new Package("pesho", versionMock.Object);

            Package packageToCompareWith = new Package("pesho", versionMock2.Object);
            //Act & Assert
            Assert.AreEqual(-1, sut.CompareTo(packageToCompareWith));
        }

        [TestMethod]
        public void ReturnOne_WhenTheMajorVersionsAreSameButMinorIsBiggerSmaller()
        {
            //Arrange
            var versionMock = new Mock<IVersion>();
            versionMock.SetupGet(x => x.Major).Returns(2);
            versionMock.SetupGet(x => x.Minor).Returns(1);
            versionMock.SetupGet(x => x.Patch).Returns(4);
            versionMock.SetupGet(x => x.VersionType).Returns(VersionType.alpha);
            var versionMock2 = new Mock<IVersion>();

            versionMock2.SetupGet(x => x.Major).Returns(2);
            versionMock2.SetupGet(x => x.Minor).Returns(2);
            versionMock2.SetupGet(x => x.Patch).Returns(4);
            versionMock2.SetupGet(x => x.VersionType).Returns(VersionType.alpha);

            Package sut = new Package("pesho", versionMock.Object);

            Package packageToCompareWith = new Package("pesho", versionMock2.Object);
            //Act & Assert
            Assert.AreEqual(-1, sut.CompareTo(packageToCompareWith));
        }

        [TestMethod]
        public void ReturnOne_WhenTheMajorAndMinorVersionsAreSameButPatchIsSmaller()
        {
            //Arrange
            var versionMock = new Mock<IVersion>();
            versionMock.SetupGet(x => x.Major).Returns(2);
            versionMock.SetupGet(x => x.Minor).Returns(2);
            versionMock.SetupGet(x => x.Patch).Returns(4);
            versionMock.SetupGet(x => x.VersionType).Returns(VersionType.alpha);
            var versionMock2 = new Mock<IVersion>();

            versionMock2.SetupGet(x => x.Major).Returns(2);
            versionMock2.SetupGet(x => x.Minor).Returns(2);
            versionMock2.SetupGet(x => x.Patch).Returns(5);
            versionMock2.SetupGet(x => x.VersionType).Returns(VersionType.alpha);

            Package sut = new Package("pesho", versionMock.Object);

            Package packageToCompareWith = new Package("pesho", versionMock2.Object);
            //Act & Assert
            Assert.AreEqual(-1, sut.CompareTo(packageToCompareWith));
        }

        [TestMethod]
        public void ReturnOne_WhenTheMajorAndMinorAndPatchVersionsAreSameButVersionTypeIsSmaller()
        {
            //Arrange
            var versionMock = new Mock<IVersion>();
            versionMock.SetupGet(x => x.Major).Returns(2);
            versionMock.SetupGet(x => x.Minor).Returns(2);
            versionMock.SetupGet(x => x.Patch).Returns(4);
            versionMock.SetupGet(x => x.VersionType).Returns(VersionType.alpha);
            var versionMock2 = new Mock<IVersion>();

            versionMock2.SetupGet(x => x.Major).Returns(2);
            versionMock2.SetupGet(x => x.Minor).Returns(2);
            versionMock2.SetupGet(x => x.Patch).Returns(4);
            versionMock2.SetupGet(x => x.VersionType).Returns(VersionType.beta);

            Package sut = new Package("pesho", versionMock.Object);

            Package packageToCompareWith = new Package("pesho", versionMock2.Object);
            //Act & Assert
            Assert.AreEqual(-1, sut.CompareTo(packageToCompareWith));
        }
    }
}
