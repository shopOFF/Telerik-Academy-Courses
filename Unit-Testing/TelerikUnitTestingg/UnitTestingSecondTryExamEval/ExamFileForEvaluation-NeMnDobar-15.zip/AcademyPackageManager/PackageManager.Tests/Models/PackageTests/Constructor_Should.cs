﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using PackageManager.Models;
using PackageManager.Enums;
using Moq;
using PackageManager.Models.Contracts;
using System.Collections.Generic;

namespace PackageManager.Tests.Models.PackageTests
{
    [TestClass]
    public class Constructor_Should
    {
        [TestMethod]
        public void SetNameValue_WhenGivenValidValue()
        {
            // Arrange
            string name = "Pesho";
            var versionMock = new Mock<IVersion>();

            //Act
            Package package = new Package(name, versionMock.Object);

            //Assert
            Assert.AreEqual(name, package.Name);
        }

        [TestMethod]
        public void SetVersionValue_WhenGivenNotNullVersion()
        {
            // Arrange
            string name = "Pesho";
            var versionMock = new Mock<IVersion>();

            //Act
            Package package = new Package(name, versionMock.Object);

            //Assert
            Assert.AreSame(versionMock.Object, package.Version);
        }

        [TestMethod]
        public void SetUrlValue_WhenAllDataIsValid()
        {
            // Arrange
            string name = "Pesho";
            var versionMock = new Mock<IVersion>();
            versionMock.SetupGet(x => x.Major).Returns(2);
            versionMock.SetupGet(x => x.Minor).Returns(1);
            versionMock.SetupGet(x => x.Patch).Returns(4);
            versionMock.SetupGet(x => x.VersionType).Returns(VersionType.alpha);

            //Act
            Package package = new Package(name, versionMock.Object);

            //Assert
            StringAssert.Contains(package.Url, versionMock.Object.Major.ToString());
            StringAssert.Contains(package.Url, versionMock.Object.Minor.ToString());
            StringAssert.Contains(package.Url, versionMock.Object.Patch.ToString());
            StringAssert.Contains(package.Url, versionMock.Object.VersionType.ToString());
        }

        [TestMethod]
        public void InitialiseDependencies_WhenNoDependenciesPassed()
        {
            // Arrange
            string name = "Pesho";
            var versionMock = new Mock<IVersion>();

            //Act
            Package package = new Package(name, versionMock.Object);

            //Assert
            Assert.IsNotNull(package.Dependencies);
        }

        [TestMethod]
        public void SetDependencies_WhenDependenciesPassed()
        {
            // Arrange
            string name = "Pesho";
            var versionMock = new Mock<IVersion>();
            var dependenciesMock = new Mock<ICollection<IPackage>>();

            //Act
            Package package = new Package(name, versionMock.Object, dependenciesMock.Object);

            //Assert
            Assert.AreSame(dependenciesMock.Object, package.Dependencies);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void ThrowArgumentNullException_WhenNameIsNull()
        {
            //Arrange
            var versionMock = new Mock<IVersion>();
            var dependenciesMock = new Mock<ICollection<IPackage>>();

            //Act & Assert
            Package package = new Package(null, versionMock.Object, dependenciesMock.Object);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void ThrowArgumentNullException_WhenVersionIsNull()
        {
            //Arrange
            var dependenciesMock = new Mock<ICollection<IPackage>>();

            //Act & Assert
            Package package = new Package("pesho", null, dependenciesMock.Object);
        }
    }
}


