﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using PackageManager.Models;
using PackageManager.Enums;
using Moq;
using PackageManager.Models.Contracts;
using System.Collections.Generic;

namespace PackageManager.Tests.Models.PackageTests
{
    [TestClass]
    public class Equals_Should
    {
        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void ThrowArgumentNullException_WhenPassedNull()
        {
            //Arrange
            var versionMock = new Mock<IVersion>();
            Package sut = new Package("pesho", versionMock.Object);

            //Act & Assert
            sut.Equals(null);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void ThrowArgumentException_WhenTheObjectIsNotIPackage()
        {
            //Arrange
            var versionMock = new Mock<IVersion>();
            Package sut = new Package("pesho", versionMock.Object);

            //Act & Assert
            sut.Equals(versionMock.Object);
        }

        [TestMethod]
        public void ReturnTrue_WhenNameAndVersionIsTheSame()
        {
            //Arrange
            var versionMock = new Mock<IVersion>();
            versionMock.SetupGet(x => x.Major).Returns(2);
            versionMock.SetupGet(x => x.Minor).Returns(2);
            versionMock.SetupGet(x => x.Patch).Returns(4);
            versionMock.SetupGet(x => x.VersionType).Returns(VersionType.alpha);
            var versionMock2 = new Mock<IVersion>();

            versionMock2.SetupGet(x => x.Major).Returns(2);
            versionMock2.SetupGet(x => x.Minor).Returns(2);
            versionMock2.SetupGet(x => x.Patch).Returns(4);
            versionMock2.SetupGet(x => x.VersionType).Returns(VersionType.alpha);

            Package sut = new Package("pesho", versionMock.Object);

            Package packageToCompareWith = new Package("pesho", versionMock2.Object);
            
            //Act & Assert
            Assert.IsTrue(sut.Equals(packageToCompareWith));
        }

        [TestMethod]
        public void ReturnFalse_WhenNameIsTheSameButTheMajorVersionsAreNot()
        {
            //Arrange
            var versionMock = new Mock<IVersion>();
            versionMock.SetupGet(x => x.Major).Returns(2);
            versionMock.SetupGet(x => x.Minor).Returns(2);
            versionMock.SetupGet(x => x.Patch).Returns(4);
            versionMock.SetupGet(x => x.VersionType).Returns(VersionType.alpha);
            var versionMock2 = new Mock<IVersion>();

            versionMock2.SetupGet(x => x.Major).Returns(3);
            versionMock2.SetupGet(x => x.Minor).Returns(2);
            versionMock2.SetupGet(x => x.Patch).Returns(4);
            versionMock2.SetupGet(x => x.VersionType).Returns(VersionType.alpha);

            Package sut = new Package("pesho", versionMock.Object);

            Package packageToCompareWith = new Package("pesho", versionMock2.Object);

            //Act & Assert
            Assert.IsFalse(sut.Equals(packageToCompareWith));
        }

        [TestMethod]
        public void ReturnFalse_WhenNameIsTheSameButTheMinorVersionsAreNot()
        {
            //Arrange
            var versionMock = new Mock<IVersion>();
            versionMock.SetupGet(x => x.Major).Returns(3);
            versionMock.SetupGet(x => x.Minor).Returns(2);
            versionMock.SetupGet(x => x.Patch).Returns(4);
            versionMock.SetupGet(x => x.VersionType).Returns(VersionType.alpha);
            var versionMock2 = new Mock<IVersion>();

            versionMock2.SetupGet(x => x.Major).Returns(3);
            versionMock2.SetupGet(x => x.Minor).Returns(1);
            versionMock2.SetupGet(x => x.Patch).Returns(4);
            versionMock2.SetupGet(x => x.VersionType).Returns(VersionType.alpha);

            Package sut = new Package("pesho", versionMock.Object);

            Package packageToCompareWith = new Package("pesho", versionMock2.Object);

            //Act & Assert
            Assert.IsFalse(sut.Equals(packageToCompareWith));
        }

        [TestMethod]
        public void ReturnFalse_WhenNameIsTheSameButThePatchVersionsAreNot()
        {
            //Arrange
            var versionMock = new Mock<IVersion>();
            versionMock.SetupGet(x => x.Major).Returns(3);
            versionMock.SetupGet(x => x.Minor).Returns(1);
            versionMock.SetupGet(x => x.Patch).Returns(3);
            versionMock.SetupGet(x => x.VersionType).Returns(VersionType.alpha);
            var versionMock2 = new Mock<IVersion>();

            versionMock2.SetupGet(x => x.Major).Returns(3);
            versionMock2.SetupGet(x => x.Minor).Returns(1);
            versionMock2.SetupGet(x => x.Patch).Returns(4);
            versionMock2.SetupGet(x => x.VersionType).Returns(VersionType.alpha);

            Package sut = new Package("pesho", versionMock.Object);

            Package packageToCompareWith = new Package("pesho", versionMock2.Object);

            //Act & Assert
            Assert.IsFalse(sut.Equals(packageToCompareWith));
        }

        [TestMethod]
        public void ReturnFalse_WhenNameIsTheSameButTheVersionTypesAreNot()
        {
            //Arrange
            var versionMock = new Mock<IVersion>();
            versionMock.SetupGet(x => x.Major).Returns(3);
            versionMock.SetupGet(x => x.Minor).Returns(1);
            versionMock.SetupGet(x => x.Patch).Returns(3);
            versionMock.SetupGet(x => x.VersionType).Returns(VersionType.beta);
            var versionMock2 = new Mock<IVersion>();

            versionMock2.SetupGet(x => x.Major).Returns(3);
            versionMock2.SetupGet(x => x.Minor).Returns(1);
            versionMock2.SetupGet(x => x.Patch).Returns(3);
            versionMock2.SetupGet(x => x.VersionType).Returns(VersionType.alpha);

            Package sut = new Package("pesho", versionMock.Object);

            Package packageToCompareWith = new Package("pesho", versionMock2.Object);

            //Act & Assert
            Assert.IsFalse(sut.Equals(packageToCompareWith));
        }

        [TestMethod]
        public void ReturnFalse_WhenVersionsAreTheSameButNamesAreNot()
        {
            //Arrange
            var versionMock = new Mock<IVersion>();
            versionMock.SetupGet(x => x.Major).Returns(3);
            versionMock.SetupGet(x => x.Minor).Returns(1);
            versionMock.SetupGet(x => x.Patch).Returns(3);
            versionMock.SetupGet(x => x.VersionType).Returns(VersionType.beta);
            var versionMock2 = new Mock<IVersion>();

            versionMock2.SetupGet(x => x.Major).Returns(3);
            versionMock2.SetupGet(x => x.Minor).Returns(1);
            versionMock2.SetupGet(x => x.Patch).Returns(3);
            versionMock2.SetupGet(x => x.VersionType).Returns(VersionType.alpha);

            Package sut = new Package("pesho", versionMock.Object);

            Package packageToCompareWith = new Package("pesho124", versionMock2.Object);

            //Act & Assert
            Assert.IsFalse(sut.Equals(packageToCompareWith));
        }
    }
}
