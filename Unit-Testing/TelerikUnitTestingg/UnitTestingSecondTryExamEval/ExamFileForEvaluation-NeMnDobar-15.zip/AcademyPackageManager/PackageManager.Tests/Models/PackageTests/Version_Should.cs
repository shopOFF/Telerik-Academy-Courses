﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using PackageManager.Models;
using PackageManager.Enums;
using Moq;
using PackageManager.Models.Contracts;
using System.Collections.Generic;


namespace PackageManager.Tests.Models.PackageTests
{
    [TestClass]
    public class Version_Should
    {
        [TestMethod]
        public void BeEqualToTheSetValue_WhenItIsSet()
        {
            // Arrange
            string name = "Pesho";
            var versionMock = new Mock<IVersion>();
            var versionMock2 = new Mock<IVersion>();

            Package package = new Package(name, versionMock.Object);

            //Act
            package.Version = versionMock2.Object;

            //Assert
            Assert.AreSame(package.Version, versionMock2.Object);
        }

        [TestMethod]
        public void SetMajor()
        {
            // Arrange
            string name = "Pesho";
            var versionMock = new Mock<IVersion>();
            var versionMock2 = new Mock<IVersion>();

            versionMock2.SetupGet(x => x.Major).Returns(2);

            Package package = new Package(name, versionMock.Object);

            //Act
            package.Version = versionMock2.Object;

            //Assert
            Assert.AreEqual(versionMock2.Object.Major, package.Version.Major);
        }

        [TestMethod]
        public void SetMinor()
        {
            // Arrange
            string name = "Pesho";
            var versionMock = new Mock<IVersion>();
            var versionMock2 = new Mock<IVersion>();

            versionMock2.SetupGet(x => x.Minor).Returns(1);

            Package package = new Package(name, versionMock.Object);

            //Act
            package.Version = versionMock2.Object;

            //Assert
            Assert.AreEqual(versionMock2.Object.Minor, package.Version.Minor);
        }

        [TestMethod]
        public void SetPatch()
        {
            // Arrange
            string name = "Pesho";
            var versionMock = new Mock<IVersion>();
            var versionMock2 = new Mock<IVersion>();

            versionMock2.SetupGet(x => x.Patch).Returns(2);

            Package package = new Package(name, versionMock.Object);

            //Act
            package.Version = versionMock2.Object;

            //Assert
            Assert.AreEqual(versionMock2.Object.Patch, package.Version.Patch);
        }

        [TestMethod]
        public void SetVersionType()
        {
            // Arrange
            string name = "Pesho";
            var versionMock = new Mock<IVersion>();
            var versionMock2 = new Mock<IVersion>();

            versionMock2.SetupGet(x => x.VersionType).Returns(VersionType.alpha);

            Package package = new Package(name, versionMock.Object);

            //Act
            package.Version = versionMock2.Object;

            //Assert
            Assert.AreEqual(versionMock2.Object.VersionType, package.Version.VersionType);
        }
    }
}
