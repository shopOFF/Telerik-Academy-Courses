﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using PackageManager.Models;
using PackageManager.Enums;

namespace PackageManager.Tests.Models.PackageVersionTests
{
    [TestClass]
    public class Constructor_Should
    {

        [TestMethod]
        public void SetMajorValue_WhenGivenValidValue()
        {
            // Arrange & Act
            PackageVersion package = new PackageVersion(1, 2, 2, VersionType.alpha);

            //Assert
            Assert.AreEqual(1, package.Major);
        }


        [TestMethod]
        public void SetMinorValue_WhenGivenValidValue()
        {
            // Arrange & Act
            PackageVersion package = new PackageVersion(1, 2, 2, VersionType.alpha);

            //Assert
            Assert.AreEqual(2, package.Minor);
        }

        [TestMethod]
        public void SetPatchValue_WhenGivenValidValue()
        {
            // Arrange & Act
            PackageVersion package = new PackageVersion(1, 2, 3, VersionType.alpha);

            //Assert
            Assert.AreEqual(3, package.Patch);
        }


        [TestMethod]
        public void SetVersionType_WhenGivenValidVersionType()
        {
            // Arrange & Act
            PackageVersion package = new PackageVersion(1, 2, 3, VersionType.alpha);

            //Assert
            Assert.AreEqual(VersionType.alpha, package.VersionType);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void ThrowArgumentException_WhenMajorGivenNegativeValue()
        {
            //Arrange & Act & Assert
            var packageVersion = new PackageVersion(-1, 2, 2, VersionType.alpha);
        }


        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void ThrowArgumentException_WhenMinorGivenNegativeValue()
        {
            //Arrange & Act & Assert
            var packageVersion = new PackageVersion(1, -2, 2, VersionType.alpha);
        }


        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void ThrowArgumentException_WhenPatchGivenNegativeValue()
        {
            //Arrange & Act & Assert
            var packageVersion = new PackageVersion(1, 2, -2, VersionType.alpha);
        }


        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void ThrowArgumentException_WhenVersionTypeGivenInvalidType()
        {
            //Arrange & Act & Assert
            var packageVersion = new PackageVersion(1, 2, 2, (VersionType)5);
        }
    }
}


