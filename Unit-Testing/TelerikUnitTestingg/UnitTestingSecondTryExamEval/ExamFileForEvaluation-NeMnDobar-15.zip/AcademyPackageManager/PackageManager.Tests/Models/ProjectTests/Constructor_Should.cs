﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using PackageManager.Models;
using PackageManager.Enums;
using PackageManager.Repositories;
using Moq;
using PackageManager.Repositories.Contracts;
using PackageManager.Models.Contracts;

namespace PackageManager.Tests.Models.ProjectTests
{
    [TestClass]
    public class Constructor_Should
    {

        [TestMethod]
        public void SetNameValue_WhenGivenValidValue()
        {
            // Arrange & Act
            string name = "Pesho";
            Project project = new Project(name, "location");

            //Assert
            Assert.AreEqual(name, project.Name);
        }


        [TestMethod]
        public void SetLocationValue_WhenGivenValidValue()
        {
            // Arrange & Act
            string location = "location";
            Project project = new Project("Pesho", location);

            //Assert
            Assert.AreEqual(location, project.Location);
        }

        [TestMethod]
        public void InitialisePackages_WhenNoPackagesPassed()
        {
            // Arrange & Act
            Project project = new Project("Pesho", "location");

            //Assert
            Assert.IsNotNull(project.PackageRepository);
        }

        [TestMethod]
        public void InitialisePackagesAsPackageRepository_WhenNoPackagesPassed()
        {
            // Arrange & Act
            Project project = new Project("Pesho", "location");

            //Assert
            Assert.IsInstanceOfType(project.PackageRepository, typeof(PackageRepository));
        }

        [TestMethod]
        public void SetPackageRepository_WhenPackageRepositoryIsPassed()
        {
            // Arrange
            var packageMock = new Mock<IRepository<IPackage>>();

            //Act
            Project project = new Project("Pesho", "location", packageMock.Object);

            //Assert
            Assert.AreSame(packageMock.Object, project.PackageRepository);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void ThrowArgumentNullException_WhenNameIsNull()
        {
            //Arrange & Act & Assert
            Project project = new Project(null, "location");
        }


        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void ThrowArgumentNullException_WhenLocationIsNull()
        {
            //Arrange & Act & Assert
            Project project = new Project("pesho",null);
        }
    }
}


