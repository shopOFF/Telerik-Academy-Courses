﻿using PackageManager.Commands;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PackageManager.Core.Contracts;
using PackageManager.Models.Contracts;
using PackageManager.Core;
using PackageManager.Repositories;
using PackageManager.Info.Contracts;

namespace PackageManager.Tests.PackageRepositoryTests.MockObjects
{
    internal class PackageRepositoryMock : PackageRepository
    {
        public PackageRepositoryMock(ILogger logger, ICollection<IPackage> packages = null) : base(logger, packages)
        {
        }

        public ILogger LoggerExposed
        {
            get
            {
                return this.Logger;
            }
        }

        public ICollection<IPackage> PackagesExposed
        {
            get
            {
                return this.Packages;
            }
        }
    }
}
