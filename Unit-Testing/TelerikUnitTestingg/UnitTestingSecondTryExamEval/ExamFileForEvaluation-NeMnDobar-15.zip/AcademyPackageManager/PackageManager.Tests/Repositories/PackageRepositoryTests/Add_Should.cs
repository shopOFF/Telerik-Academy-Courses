﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using PackageManager.Models;
using PackageManager.Enums;
using PackageManager.Repositories;
using Moq;
using PackageManager.Models.Contracts;
using PackageManager.Info.Contracts;
using System.Collections.Generic;

namespace PackageManager.Tests.Repositories.PackageRepositoryTests
{
    [TestClass]
    public class Add_Should
    {
        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void ThrowArgumentNullException_WhenPassedNullPackage()
        {
            //Arrange
            var logger = new Mock<ILogger>();
            var packages = new Mock<ICollection<IPackage>>();
            PackageRepository sut = new PackageRepository(logger.Object, packages.Object);

            //Act & Assert
            sut.Add(null);
        }

        [TestMethod]
        public void AddPackage_WhenPackageANewPackageIsPassed()
        {
            //Arrange
            var logger = new Mock<ILogger>();

            //var packageMocked = new Mock<IPackage>();
            var packages = new List<IPackage>();

            PackageRepository sut = new PackageRepository(logger.Object, packages);
            var packageMock = new Mock<IPackage>();
            //Act
            sut.Add(packageMock.Object);

            //Assert
            Assert.AreEqual(1, packages.Count);
        }

        [TestMethod]
        public void LogMessage_WhenPackageANewPackageIsPassed()
        {
            //Arrange
            var logger = new Mock<ILogger>();
            logger.Setup(x => x.Log(It.IsAny<string>()));
            //var packageMocked = new Mock<IPackage>();
            var packages = new List<IPackage>();

            PackageRepository sut = new PackageRepository(logger.Object, packages);
            var packageMock = new Mock<IPackage>();
            //Act
            sut.Add(packageMock.Object);

            //Assert
            logger.Verify(x => x.Log(It.Is<string>(s => s.Contains("added"))));
        }

        [TestMethod]
        public void NotAddPackage_WhenAlreadyAdded()
        {
            //Arrange
            var logger = new Mock<ILogger>();
            logger.Setup(x => x.Log(It.IsAny<string>()));

            string name = "Pesho";
            var versionMock = new Mock<IVersion>();
            versionMock.SetupGet(x => x.Major).Returns(2);
            versionMock.SetupGet(x => x.Minor).Returns(1);
            versionMock.SetupGet(x => x.Patch).Returns(4);
            versionMock.SetupGet(x => x.VersionType).Returns(VersionType.alpha);

            //Act
            Package package = new Package(name, versionMock.Object);
            var packages = new List<IPackage>() { package};

            PackageRepository sut = new PackageRepository(logger.Object, packages);

            var versionMockToAdd = new Mock<IVersion>();
            versionMockToAdd.SetupGet(x => x.Major).Returns(2);
            versionMockToAdd.SetupGet(x => x.Minor).Returns(1);
            versionMockToAdd.SetupGet(x => x.Patch).Returns(4);
            versionMockToAdd.SetupGet(x => x.VersionType).Returns(VersionType.alpha);

            Package packageToAdd = new Package("Pesho", versionMockToAdd.Object);

            //Act
            sut.Add(packageToAdd);

            //Assert
            Assert.AreEqual(1, packages.Count);
        }

        [TestMethod]
        public void LogMessage_WhenAlreadyAdded()
        {
            //Arrange
            var logger = new Mock<ILogger>();
            logger.Setup(x => x.Log(It.IsAny<string>()));

            string name = "Pesho";
            var versionMock = new Mock<IVersion>();
            versionMock.SetupGet(x => x.Major).Returns(2);
            versionMock.SetupGet(x => x.Minor).Returns(1);
            versionMock.SetupGet(x => x.Patch).Returns(4);
            versionMock.SetupGet(x => x.VersionType).Returns(VersionType.alpha);

            //Act
            Package package = new Package(name, versionMock.Object);
            var packages = new List<IPackage>() { package };

            PackageRepository sut = new PackageRepository(logger.Object, packages);

            var versionMockToAdd = new Mock<IVersion>();
            versionMockToAdd.SetupGet(x => x.Major).Returns(2);
            versionMockToAdd.SetupGet(x => x.Minor).Returns(1);
            versionMockToAdd.SetupGet(x => x.Patch).Returns(4);
            versionMockToAdd.SetupGet(x => x.VersionType).Returns(VersionType.alpha);

            Package packageToAdd = new Package("Pesho", versionMockToAdd.Object);

            //Act
            sut.Add(packageToAdd);

            //Assert          
            logger.Verify(x => x.Log(It.Is<string>(s => s.Contains("already installed"))));
        }

        [TestMethod]
        public void AddPackage_WhenNameIsDifferent()
        {
            //Arrange
            var logger = new Mock<ILogger>();
            logger.Setup(x => x.Log(It.IsAny<string>()));

            string name = "Pesho";
            var versionMock = new Mock<IVersion>();
            versionMock.SetupGet(x => x.Major).Returns(2);
            versionMock.SetupGet(x => x.Minor).Returns(1);
            versionMock.SetupGet(x => x.Patch).Returns(4);
            versionMock.SetupGet(x => x.VersionType).Returns(VersionType.alpha);

            //Act
            Package package = new Package(name, versionMock.Object);
            var packages = new List<IPackage>() { package };

            PackageRepository sut = new PackageRepository(logger.Object, packages);

            var versionMockToAdd = new Mock<IVersion>();
            versionMockToAdd.SetupGet(x => x.Major).Returns(2);
            versionMockToAdd.SetupGet(x => x.Minor).Returns(1);
            versionMockToAdd.SetupGet(x => x.Patch).Returns(4);
            versionMockToAdd.SetupGet(x => x.VersionType).Returns(VersionType.alpha);

            Package packageToAdd = new Package("stamat", versionMockToAdd.Object);

            //Act
            sut.Add(packageToAdd);

            //Assert
            Assert.AreEqual(2, packages.Count);
        }

        [TestMethod]
        public void UpdatePackage_WhenVersionOfThePassedPackageIsBigger()
        {
            //Arrange
            var logger = new Mock<ILogger>();
            logger.Setup(x => x.Log(It.IsAny<string>()));

            string name = "Pesho";
            var versionMock = new Mock<IVersion>();
            versionMock.SetupGet(x => x.Major).Returns(2);
            versionMock.SetupGet(x => x.Minor).Returns(1);
            versionMock.SetupGet(x => x.Patch).Returns(4);
            versionMock.SetupGet(x => x.VersionType).Returns(VersionType.alpha);

            //Act
            Package package = new Package(name, versionMock.Object);
            var packages = new List<IPackage>() { package };

            PackageRepository sut = new PackageRepository(logger.Object, packages);

            var versionMockToAdd = new Mock<IVersion>();
            versionMockToAdd.SetupGet(x => x.Major).Returns(5);
            versionMockToAdd.SetupGet(x => x.Minor).Returns(1);
            versionMockToAdd.SetupGet(x => x.Patch).Returns(4);
            versionMockToAdd.SetupGet(x => x.VersionType).Returns(VersionType.alpha);

            Package packageToAdd = new Package("Pesho", versionMockToAdd.Object);

            //Act
            sut.Add(packageToAdd);

            //Assert
            Assert.AreEqual(packages[0].Version, versionMockToAdd.Object);
        }

        [TestMethod]
        public void NoLog_WhenUpdate()
        {
            //Arrange
            var logger = new Mock<ILogger>();
            logger.Setup(x => x.Log(It.IsAny<string>()));

            string name = "Pesho";
            var versionMock = new Mock<IVersion>();
            versionMock.SetupGet(x => x.Major).Returns(2);
            versionMock.SetupGet(x => x.Minor).Returns(1);
            versionMock.SetupGet(x => x.Patch).Returns(4);
            versionMock.SetupGet(x => x.VersionType).Returns(VersionType.alpha);

            //Act
            Package package = new Package(name, versionMock.Object);
            var packages = new List<IPackage>() { package };

            PackageRepository sut = new PackageRepository(logger.Object, packages);

            var versionMockToAdd = new Mock<IVersion>();
            versionMockToAdd.SetupGet(x => x.Major).Returns(5);
            versionMockToAdd.SetupGet(x => x.Minor).Returns(1);
            versionMockToAdd.SetupGet(x => x.Patch).Returns(4);
            versionMockToAdd.SetupGet(x => x.VersionType).Returns(VersionType.alpha);

            Package packageToAdd = new Package("Pesho", versionMockToAdd.Object);

            //Act
            sut.Add(packageToAdd);

            //Assert
            logger.Verify(x => x.Log(It.IsAny<string>()), Times.Never);
        }

        [TestMethod]
        public void Log_WhenThePassedPackagesIsWithLowerVersion()
        {
            //Arrange
            var logger = new Mock<ILogger>();
            logger.Setup(x => x.Log(It.IsAny<string>()));

            string name = "Pesho";
            var versionMock = new Mock<IVersion>();
            versionMock.SetupGet(x => x.Major).Returns(3);
            versionMock.SetupGet(x => x.Minor).Returns(1);
            versionMock.SetupGet(x => x.Patch).Returns(4);
            versionMock.SetupGet(x => x.VersionType).Returns(VersionType.alpha);

            //Act
            Package package = new Package(name, versionMock.Object);
            var packages = new List<IPackage>() { package };

            PackageRepository sut = new PackageRepository(logger.Object, packages);

            var versionMockToAdd = new Mock<IVersion>();
            versionMockToAdd.SetupGet(x => x.Major).Returns(1);
            versionMockToAdd.SetupGet(x => x.Minor).Returns(1);
            versionMockToAdd.SetupGet(x => x.Patch).Returns(4);
            versionMockToAdd.SetupGet(x => x.VersionType).Returns(VersionType.alpha);

            Package packageToAdd = new Package("Pesho", versionMockToAdd.Object);

            //Act
            sut.Add(packageToAdd);

            //Assert
            logger.Verify(x => x.Log(It.Is<string>(s => s.Contains("There is a package with newer version"))));
        }


        [TestMethod]
        public void NotAddPackage_WhenPassedLowerVersion()
        {
            //Arrange
            var logger = new Mock<ILogger>();
            logger.Setup(x => x.Log(It.IsAny<string>()));

            string name = "Pesho";
            var versionMock = new Mock<IVersion>();
            versionMock.SetupGet(x => x.Major).Returns(3);
            versionMock.SetupGet(x => x.Minor).Returns(1);
            versionMock.SetupGet(x => x.Patch).Returns(4);
            versionMock.SetupGet(x => x.VersionType).Returns(VersionType.alpha);

            //Act
            Package package = new Package(name, versionMock.Object);
            var packages = new List<IPackage>() { package };

            PackageRepository sut = new PackageRepository(logger.Object, packages);

            var versionMockToAdd = new Mock<IVersion>();
            versionMockToAdd.SetupGet(x => x.Major).Returns(2);
            versionMockToAdd.SetupGet(x => x.Minor).Returns(1);
            versionMockToAdd.SetupGet(x => x.Patch).Returns(4);
            versionMockToAdd.SetupGet(x => x.VersionType).Returns(VersionType.alpha);

            Package packageToAdd = new Package("Pesho", versionMockToAdd.Object);

            //Act
            sut.Add(packageToAdd);

            //Assert
            Assert.AreEqual(1, packages.Count);
        }

    }
}
