﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using PackageManager.Models;
using PackageManager.Enums;
using PackageManager.Repositories;
using Moq;
using PackageManager.Models.Contracts;
using PackageManager.Info.Contracts;
using System.Collections.Generic;

namespace PackageManager.Tests.Repositories.PackageRepositoryTests
{
    [TestClass]
    public class Delete_Should
    {
        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void ThrowArgumentNullException_WhenPassedNullPackage()
        {
            //Arrange
            var logger = new Mock<ILogger>();
            var packages = new Mock<ICollection<IPackage>>();
            PackageRepository sut = new PackageRepository(logger.Object, packages.Object);

            //Act & Assert
            sut.Delete(null);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void ThrowArgumentNullException_WhenPassedPackageThatDoesNotExist()
        {
            //Arrange
            var logger = new Mock<ILogger>();

            //var packageMocked = new Mock<IPackage>();
            var packages = new List<IPackage>();

            PackageRepository sut = new PackageRepository(logger.Object, packages);
            var packageMock = new Mock<IPackage>();
            //Act & Assert
            sut.Delete(packageMock.Object);
        }

        [TestMethod]
        public void LogMessage_WhenPassedPackageThatDoesNotExist()
        {
            //Arrange
            var logger = new Mock<ILogger>();
            logger.Setup(x => x.Log(It.IsAny<string>()));
            //var packageMocked = new Mock<IPackage>();
            var packages = new List<IPackage>();

            PackageRepository sut = new PackageRepository(logger.Object, packages);
            var packageMock = new Mock<IPackage>();

            //Act
            try
            {
                sut.Delete(packageMock.Object);
            }
            catch(ArgumentNullException)
            {

            }
            

            //Assert
            logger.Verify(x => x.Log(It.Is<string>(s => s.Contains("does not exist"))));
        }

        [TestMethod]
        public void NotDelete_WhenThePackageHasDependencies()
        {
            //Arrange
            var logger = new Mock<ILogger>();
            logger.Setup(x => x.Log(It.IsAny<string>()));
            //var packageMocked = new Mock<IPackage>();
            string name = "Pesho";
            var versionMock = new Mock<IVersion>();
            versionMock.SetupGet(x => x.Major).Returns(2);
            versionMock.SetupGet(x => x.Minor).Returns(1);
            versionMock.SetupGet(x => x.Patch).Returns(4);
            versionMock.SetupGet(x => x.VersionType).Returns(VersionType.alpha);
            var packageMock = new Package(name, versionMock.Object);


            string nameDep = "Stamat";
            var versionMockDep = new Mock<IVersion>();
            versionMockDep.SetupGet(x => x.Major).Returns(2);
            versionMockDep.SetupGet(x => x.Minor).Returns(1);
            versionMockDep.SetupGet(x => x.Patch).Returns(4);
            versionMockDep.SetupGet(x => x.VersionType).Returns(VersionType.alpha);
            var packageMockDependency = new Package(nameDep, versionMockDep.Object);

            packageMock.Dependencies.Add(packageMockDependency);

            var packages = new List<IPackage>();
            packages.Add(packageMock);
            packages.Add(packageMockDependency);
            PackageRepository sut = new PackageRepository(logger.Object, packages);

            //Act
            sut.Delete(packageMockDependency);

            //Assert
            Assert.AreEqual(2, packages.Count);
        }

        [TestMethod]
        public void LogMessage_WhenThePackageHasDependencies()
        {
            //Arrange
            var logger = new Mock<ILogger>();
            logger.Setup(x => x.Log(It.IsAny<string>()));
            //var packageMocked = new Mock<IPackage>();
            string name = "Pesho";
            var versionMock = new Mock<IVersion>();
            versionMock.SetupGet(x => x.Major).Returns(2);
            versionMock.SetupGet(x => x.Minor).Returns(1);
            versionMock.SetupGet(x => x.Patch).Returns(4);
            versionMock.SetupGet(x => x.VersionType).Returns(VersionType.alpha);
            var packageMock = new Package(name, versionMock.Object);


            string nameDep = "Stamat";
            var versionMockDep = new Mock<IVersion>();
            versionMockDep.SetupGet(x => x.Major).Returns(2);
            versionMockDep.SetupGet(x => x.Minor).Returns(1);
            versionMockDep.SetupGet(x => x.Patch).Returns(4);
            versionMockDep.SetupGet(x => x.VersionType).Returns(VersionType.alpha);
            var packageMockDependency = new Package(nameDep, versionMockDep.Object);

            packageMock.Dependencies.Add(packageMockDependency);

            var packages = new List<IPackage>();
            packages.Add(packageMock);
            packages.Add(packageMockDependency);
            PackageRepository sut = new PackageRepository(logger.Object, packages);
            
            //Act
            sut.Delete(packageMockDependency);

            //Assert
            logger.Verify(x => x.Log(It.Is<string>(s => s.Contains("could not be removed"))));
        }

        [TestMethod]
        public void Delete_WhenThePackageHasNoDependencies()
        {
            //Arrange
            var logger = new Mock<ILogger>();
            logger.Setup(x => x.Log(It.IsAny<string>()));
            //var packageMocked = new Mock<IPackage>();
            string name = "Pesho";
            var versionMock = new Mock<IVersion>();
            versionMock.SetupGet(x => x.Major).Returns(2);
            versionMock.SetupGet(x => x.Minor).Returns(1);
            versionMock.SetupGet(x => x.Patch).Returns(4);
            versionMock.SetupGet(x => x.VersionType).Returns(VersionType.alpha);
            var packageMock = new Package(name, versionMock.Object);

            string nameDep = "Stamat";
            var versionMockDep = new Mock<IVersion>();
            versionMockDep.SetupGet(x => x.Major).Returns(2);
            versionMockDep.SetupGet(x => x.Minor).Returns(1);
            versionMockDep.SetupGet(x => x.Patch).Returns(4);
            versionMockDep.SetupGet(x => x.VersionType).Returns(VersionType.alpha);
            var packageMockDependency = new Package(nameDep, versionMockDep.Object);

            var packages = new List<IPackage>();
            packages.Add(packageMock);
            packages.Add(packageMockDependency);
            PackageRepository sut = new PackageRepository(logger.Object, packages);

            //Act
            sut.Delete(packageMockDependency);

            //Assert
            Assert.AreEqual(1, packages.Count);
        }

        [TestMethod]
        public void ReturnDeletedPackage_WhenSuccessfulyDeleted()
        {
            //Arrange
            var logger = new Mock<ILogger>();
            logger.Setup(x => x.Log(It.IsAny<string>()));
            //var packageMocked = new Mock<IPackage>();
            string name = "Pesho";
            var versionMock = new Mock<IVersion>();
            versionMock.SetupGet(x => x.Major).Returns(2);
            versionMock.SetupGet(x => x.Minor).Returns(1);
            versionMock.SetupGet(x => x.Patch).Returns(4);
            versionMock.SetupGet(x => x.VersionType).Returns(VersionType.alpha);
            var packageMock = new Package(name, versionMock.Object);

            string nameDep = "Stamat";
            var versionMockDep = new Mock<IVersion>();
            versionMockDep.SetupGet(x => x.Major).Returns(2);
            versionMockDep.SetupGet(x => x.Minor).Returns(1);
            versionMockDep.SetupGet(x => x.Patch).Returns(4);
            versionMockDep.SetupGet(x => x.VersionType).Returns(VersionType.alpha);
            var packageMockDependency = new Package(nameDep, versionMockDep.Object);

            var packages = new List<IPackage>();
            packages.Add(packageMock);
            packages.Add(packageMockDependency);
            PackageRepository sut = new PackageRepository(logger.Object, packages);

            //Act
            var result = sut.Delete(packageMockDependency);

            //Assert
            Assert.AreSame(result, packageMockDependency);
        }
    }
}
