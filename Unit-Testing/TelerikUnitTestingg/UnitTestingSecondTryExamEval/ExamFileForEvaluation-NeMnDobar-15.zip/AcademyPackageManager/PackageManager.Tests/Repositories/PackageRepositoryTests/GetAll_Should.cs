﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using PackageManager.Models;
using PackageManager.Enums;
using PackageManager.Repositories;
using Moq;
using PackageManager.Models.Contracts;
using PackageManager.Info.Contracts;
using System.Collections.Generic;

namespace PackageManager.Tests.Repositories.PackageRepositoryTests
{
    [TestClass]
    public class GetAll_Should
    {
        [TestMethod]
        public void ReturnEmptyCollection_WhenNoItems()
        {
            //Arrange
            var logger = new Mock<ILogger>();
            var packages = new Mock<ICollection<IPackage>>();
            PackageRepository sut = new PackageRepository(logger.Object, packages.Object);

            //Act
            var result = sut.GetAll();

            //Assert
            Assert.AreSame(packages.Object, result);
        }
    }
}
