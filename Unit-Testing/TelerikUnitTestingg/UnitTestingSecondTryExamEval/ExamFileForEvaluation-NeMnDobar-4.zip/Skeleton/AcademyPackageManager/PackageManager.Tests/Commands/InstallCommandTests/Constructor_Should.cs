﻿using Moq;
using NUnit.Framework;
using PackageManager.Core.Contracts;
using PackageManager.Models.Contracts;
using PackageManager.Tests.Commands.Mocks;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PackageManager.Tests.Commands.InstallCommandTests
{
    [TestFixture]
    public class Constructor_Should
    {
        [Test]
        public void CorrectlySetInstaller_WhenCommandIsConstructed()
        {
            // Arrange & Act
            var installerMock = new Mock<IInstaller<IPackage>>();
            var packageMock = new Mock<IPackage>();
        
            var command = new InstallCommandMock(installerMock.Object, packageMock.Object);
        
            // Assert
            Assert.AreEqual(installerMock.Object, command.InstallerMock);
        
        }
        
        [Test]
        public void CorrectlySetPackage_WhenCommandIsConstructed()
        {
            // Arrange & Act
            var installerMock = new Mock<IInstaller<IPackage>>();
            var packageMock = new Mock<IPackage>();
        
            var command = new InstallCommandMock(installerMock.Object, packageMock.Object);
        
            // Assert
            Assert.AreEqual(packageMock.Object, command.PackageMock);
        
        }
    }
}
