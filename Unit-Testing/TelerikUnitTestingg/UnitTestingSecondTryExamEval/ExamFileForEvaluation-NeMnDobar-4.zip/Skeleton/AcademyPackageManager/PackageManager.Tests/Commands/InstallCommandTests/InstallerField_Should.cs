﻿using Moq;
using NUnit.Framework;
using PackageManager.Core.Contracts;
using PackageManager.Models.Contracts;
using PackageManager.Tests.Commands.Mocks;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PackageManager.Tests.Commands.InstallCommandTests
{
    [TestFixture]
    public class InstallerField_Should
    {
        [Test]
        public void ReturnProperValue_WhenTheGetMethodIsCalled()
        {
            // Arrange
            var installerMock = new Mock<IInstaller<IPackage>>();
            var packageMock = new Mock<IPackage>();

            var command = new InstallCommandMock(installerMock.Object, packageMock.Object);

            //Act
            var result = command.InstallerMock;

            // Assert
            Assert.AreEqual(installerMock.Object, result);
        }
    }
}
