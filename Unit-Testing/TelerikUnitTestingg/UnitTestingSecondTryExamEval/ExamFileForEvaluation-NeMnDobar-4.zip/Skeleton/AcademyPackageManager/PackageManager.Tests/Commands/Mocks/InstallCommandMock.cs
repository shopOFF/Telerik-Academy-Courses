﻿using PackageManager.Commands;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PackageManager.Core.Contracts;
using PackageManager.Models.Contracts;

namespace PackageManager.Tests.Commands.Mocks
{
    internal class InstallCommandMock : InstallCommand
    {
        public InstallCommandMock(IInstaller<IPackage> installer, IPackage package) : base(installer, package)
        {
        }

        internal IInstaller<IPackage> InstallerMock
        {
            get
            {
                return this.Installer;
            }
        }

        internal IPackage PackageMock
        {
            get
            {
                return this.Package;
            }
        }

    }
}
