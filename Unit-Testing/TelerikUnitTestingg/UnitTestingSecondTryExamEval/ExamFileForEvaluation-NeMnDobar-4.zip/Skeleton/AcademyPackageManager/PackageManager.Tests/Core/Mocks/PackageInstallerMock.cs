﻿using PackageManager.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PackageManager.Core.Contracts;
using PackageManager.Models.Contracts;

namespace PackageManager.Tests.Core.Mocks
{
    internal class PackageInstallerMock : PackageInstaller
    {
        public PackageInstallerMock(IDownloader downloader, IProject project) : base(downloader, project)
        {
        }

        internal IProject ProjectMock
        {
            get
            {
                return this.Project;
            }
        }

        protected IDownloader DownloaderMock
        {
            get
            {
                return this.Downloader;
            }
        }
    }
}
