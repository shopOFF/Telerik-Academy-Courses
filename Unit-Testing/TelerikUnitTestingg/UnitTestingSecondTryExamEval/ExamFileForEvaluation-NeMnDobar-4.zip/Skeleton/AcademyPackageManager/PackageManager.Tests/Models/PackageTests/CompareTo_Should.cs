﻿using Moq;
using NUnit.Framework;
using PackageManager.Models;
using PackageManager.Models.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PackageManager.Tests.Models.PackageTests
{
    [TestFixture]
    public class CompareTo_Should
    {
        [Test]
        public void ThrowArgumentNullException_WhenPassedObjectIsNull()
        {
            // Arrange
            var mockVersion = new Mock<IVersion>();
            var mockDependencies = new Mock<ICollection<IPackage>>();
            var package = new Package("Valid Name", mockVersion.Object, mockDependencies.Object);

            // Act & Assert 
            Assert.Throws<ArgumentNullException>(() => package.CompareTo(null));
        }

        [Test]
        public void ThrowArgumentException_WhenThePassedObjectNameIsDifferent()
        {
            // Arrange
            var stubVersion = new Mock<IVersion>();
            var stubDependencies = new Mock<ICollection<IPackage>>();
            var mockPackage = new Mock<IPackage>();
            
            var package = new Package("Valid Name", stubVersion.Object, stubDependencies.Object);

            // Act & Assert 
            Assert.Throws<ArgumentException>(() => package.CompareTo(mockPackage.Object));
        }


        [Test]
        public void RetunrZero_WhenThePassedObjectVerisonIsSameAsTheMainVerison()
        {
            // Arrange
            var stubVersion = new Mock<IVersion>();
            var stubDependencies = new Mock<ICollection<IPackage>>();
            var mockPackage = new Mock<IPackage>();

            var package = new Package("Valid Name", stubVersion.Object, stubDependencies.Object);
            var secondPackage = new Package("Valid Name", stubVersion.Object, stubDependencies.Object);

            // Act 
            var result = package.CompareTo(secondPackage);

            // Assert 
            Assert.AreEqual(0, result);
        }

        [Test]
        public void RetunrOne_WhenThePassedObjectIsHigherThanTheMainVerison()
        {
            // Arrange
            var stubVersion = new Mock<IVersion>();
            var stubDependencies = new Mock<ICollection<IPackage>>();
            var mockPackage = new Mock<IPackage>();

            var package = new Package("Valid Name", stubVersion.Object, stubDependencies.Object);
            var secondPackage = new Package("Valid Name", stubVersion.Object, stubDependencies.Object);

            // Act 
            var result = package.CompareTo(secondPackage);

            // Assert 
            Assert.AreEqual(0, result);
        }
    }
}
