﻿using Moq;
using NUnit.Framework;
using PackageManager.Models;
using PackageManager.Models.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PackageManager.Tests.Models.PackageTests
{
    [TestFixture]
    public class Constructor_Should
    {
        [Test]
        public void SetProperName_WhenTheObjectIsConstructed()
        {
            // Arrange & Act
            var mockVersion = new Mock<IVersion>();
            var mockDependencies = new Mock<ICollection<IPackage>>();
            var package = new Package("Valid Name", mockVersion.Object, mockDependencies.Object);

            // Assert
            Assert.AreEqual("Valid Name", package.Name);
        }

        [Test]
        public void SetProperVersion_WhenTheObjectIsConstructed()
        {
            // Arrange & Act
            var mockVersion = new Mock<IVersion>();
            var mockDependencies = new Mock<ICollection<IPackage>>();
            var package = new Package("Valid Name", mockVersion.Object, mockDependencies.Object);

            // Assert
            Assert.AreEqual(mockVersion.Object, package.Version);
        }

        [Test]
        public void SetProperNotNullDependencies_WhenTheObjectIsConstructed()
        {
            // Arrange & Act
            var mockVersion = new Mock<IVersion>();
            var mockDependencies = new Mock<ICollection<IPackage>>();
            var package = new Package("Valid Name", mockVersion.Object, mockDependencies.Object);

            // Assert
            Assert.AreEqual(mockDependencies.Object, package.Dependencies);
        }

        [Test]
        public void SetProperNullDependencies_WhenTheObjectIsConstructed()
        {
            // Arrange 
            var mockVersion = new Mock<IVersion>();
            var mockDependencies = new Mock<ICollection<IPackage>>();
            var package = new Package("Valid Name", mockVersion.Object, null);

            // Act & Assert 
            Assert.IsInstanceOf<HashSet<IPackage>>(package.Dependencies);
        }
    }
}
