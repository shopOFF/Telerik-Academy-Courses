﻿using Moq;
using NUnit.Framework;
using PackageManager.Models;
using PackageManager.Models.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PackageManager.Tests.Models.PackageTests
{
    [TestFixture]
    public class Equals_Should
    {
        [Test]
        public void ThrowArgumentNullException_WhenPassedObjIsNull()
        {
            // Arrange
            var stubVersion = new Mock<IVersion>();
            var stubDependencies = new Mock<ICollection<IPackage>>();

            var package = new Package("Valid Name", stubVersion.Object, stubDependencies.Object);

            // Act & Assert 
            Assert.Throws<ArgumentNullException>(() => package.Equals(null));
        }

        [Test]
        public void ThrowArgumentException_WhenPassedObjIsNotIPaCkage()
        {
            // Arrange
            var stubVersion = new Mock<IVersion>();
            var stubDependencies = new Mock<ICollection<IPackage>>();
 
            var package = new Package("Valid Name", stubVersion.Object, stubDependencies.Object);

            // Act & Assert 
            Assert.Throws<ArgumentException>(() => package.Equals(stubVersion));
        }

        [Test]
        public void ReturnTrue_WhenThePassedObjIsEqualToTheMainPackage()
        {
            // Arrange
            var stubVersion = new Mock<IVersion>();
            var stubDependencies = new Mock<ICollection<IPackage>>();

            var package = new Package("Valid Name", stubVersion.Object, stubDependencies.Object);
            var secondPackage = new Package("Valid Name", stubVersion.Object, stubDependencies.Object);

            // Act 
            var result = package.Equals(secondPackage);

            // Assert 
            Assert.IsTrue(result);
        }

        [Test]
        public void ReturnFalse_WhenThePassedObjIsNotEqualToTheMainPackage()
        {
            // Arrange
            var stubVersion = new Mock<IVersion>();
            var stubDependencies = new Mock<ICollection<IPackage>>();
            var mockPackage = new Mock<IPackage>();

            var package = new Package("Valid Name", stubVersion.Object, stubDependencies.Object);

            // Act 
            var result = package.Equals(mockPackage.Object);

            // Assert 
            Assert.IsFalse(result);
        }
    }
}
