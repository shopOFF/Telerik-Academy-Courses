﻿using Moq;
using NUnit.Framework;
using PackageManager.Models;
using PackageManager.Models.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PackageManager.Tests.Models.PackageTests
{
    [TestFixture]
    public class GetUrl_Should
    {
        [Test]
        public void ReturnProperUrl_WhenTheGetMethodIsCalled()
        {
            // Arrange
            var mockVersion = new Mock<IVersion>();
            var mockDependencies = new Mock<ICollection<IPackage>>();
            var expectedResult = string.Format("{0}.{1}.{2}-{3}", mockVersion.Object.Major, mockVersion.Object.Minor, mockVersion.Object.Patch, mockVersion.Object.VersionType);
            var package = new Package("Valid Name", mockVersion.Object, mockDependencies.Object);

            // Act
            var result = package.Url;

            // Assert
            Assert.AreEqual(expectedResult, result);
        }
    }
}
