﻿using Moq;
using NUnit.Framework;
using PackageManager.Models;
using PackageManager.Models.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PackageManager.Tests.Models.PackageTests
{
    [TestFixture]
    public class GetVersion_Should
    {
        [Test]
        public void ReturnProperVersion_WhenGetMethodIsCalled()
        {
            // Arrange
            var mockVersion = new Mock<IVersion>();
            var mockDependencies = new Mock<ICollection<IPackage>>();
            var package = new Package("Valid Name", mockVersion.Object, mockDependencies.Object);

            // Act
            var result = package.Version;

            // Assert
            Assert.AreEqual(mockVersion.Object, result);
        }
    }
}
