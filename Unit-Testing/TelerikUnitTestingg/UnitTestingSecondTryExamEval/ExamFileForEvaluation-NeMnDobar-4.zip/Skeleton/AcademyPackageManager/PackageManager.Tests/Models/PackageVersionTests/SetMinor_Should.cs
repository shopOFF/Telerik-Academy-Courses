﻿using NUnit.Framework;
using PackageManager.Enums;
using PackageManager.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PackageManager.Tests.Models.PackageVersionTests
{
    [TestFixture]
    public class SetMinor_Should
    {
        [Test]
        public void ThrowArgumentException_WhenInvalidValueIsPassed()
        {
            // Arrange, Act & Assert
            Assert.Throws<ArgumentException>(() => new PackageVersion(2, -1, 2, VersionType.alpha));
        }
    }
}
