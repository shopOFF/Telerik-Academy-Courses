﻿using Moq;
using NUnit.Framework;
using PackageManager.Models;
using PackageManager.Models.Contracts;
using PackageManager.Repositories;
using PackageManager.Repositories.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PackageManager.Tests.Models.ProjectTests
{
    [TestFixture]
    public class Constructor_Should
    {
        [Test]
        public void SetProperName_WhenTheObjectIsConstructed()
        {
            // Arrange & Act
            var project = new Project("Valid Name", "Valid Location", null);

            // Assert
            Assert.AreEqual("Valid Name", project.Name);
        }

        [Test]
        public void SetProperLocation_WhenTheObjectIsConstructed()
        {
            // Arrange & Act
            var project = new Project("Valid Name", "Valid Location", null);

            // Assert
            Assert.AreEqual("Valid Location", project.Location);
        }

        [Test]
        public void SetProperPackageRepository_WhenTheObjectIsConstructed()
        {
            // Arrange & Act
            var project = new Project("Valid Name", "Valid Location", null);

            // Assert
            Assert.IsInstanceOf<PackageRepository>(project.PackageRepository);
        }

        [Test]
        public void SetProperNotNullPackageRepository_WhenTheObjectIsConstructed()
        {
            // Arrange & Act
            var mockPackages = new Mock<IRepository<IPackage>>();
            var project = new Project("Valid Name", "Valid Location", mockPackages.Object);

            // Assert
            Assert.AreEqual(mockPackages.Object , project.PackageRepository);
        }
    }
}
