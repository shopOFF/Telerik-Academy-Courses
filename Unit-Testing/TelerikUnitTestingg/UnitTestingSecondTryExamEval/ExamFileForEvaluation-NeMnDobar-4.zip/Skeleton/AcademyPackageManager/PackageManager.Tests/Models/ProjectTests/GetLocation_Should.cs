﻿using NUnit.Framework;
using PackageManager.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PackageManager.Tests.Models.ProjectTests
{
    [TestFixture]
    public class GetLocation_Should
    {
        [Test]
        public void ReturnProperLocation_WhenTheGetMethodIsCalled()
        {
            // Arrange 
            var project = new Project("Valid Name", "Valid Location", null);

            // Act
            var result = project.Location;

            // Assert
            Assert.AreEqual("Valid Location", result);
        }
    }
}
