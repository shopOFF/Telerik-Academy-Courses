﻿using NUnit.Framework;
using PackageManager.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PackageManager.Tests.Models.ProjectTests
{
    [TestFixture]
    public class GetName_Should
    {
        [Test]
        public void ReturnProperName_WhenGetMethodIsCalled()
        { 
            // Arrange 
            var project = new Project("Valid Name", "Valid Location", null);

            // Act
            var result = project.Name;

            // Assert
            Assert.AreEqual("Valid Name", result);
        }
    }
}
