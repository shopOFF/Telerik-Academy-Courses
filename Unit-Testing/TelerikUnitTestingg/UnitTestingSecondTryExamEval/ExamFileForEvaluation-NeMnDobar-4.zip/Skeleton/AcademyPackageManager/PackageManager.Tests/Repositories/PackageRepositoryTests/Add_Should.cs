﻿using PackageManager.Info.Contracts;
using Moq;
using NUnit.Framework;
using PackageManager.Models.Contracts;
using PackageManager.Repositories;
using PackageManager.Tests.Repositories.Mocks;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PackageManager.Repositories.Contracts;

namespace PackageManager.Tests.Repositories.PackageRepositoryTests
{
    [TestFixture]
    public class Add_Should
    {
        [Test]
        public void ThrowArgumentNullException_WhenNullValueIsPassed()
        {
            // Arrange
            var packagesMock = new Mock<ICollection<IPackage>>();
            var loggerMock = new Mock<ILogger>();

            var package = new PackageRepositoryMock(loggerMock.Object, packagesMock.Object);
            
            // Act & Assert
            Assert.Throws<ArgumentNullException>(() => package.Add(null));
        }

        
    }
}
