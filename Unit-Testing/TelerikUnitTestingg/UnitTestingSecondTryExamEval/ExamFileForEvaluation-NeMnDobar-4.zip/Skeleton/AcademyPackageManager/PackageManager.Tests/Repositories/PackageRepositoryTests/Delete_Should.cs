﻿using Moq;
using NUnit.Framework;
using PackageManager.Info.Contracts;
using PackageManager.Models;
using PackageManager.Models.Contracts;
using PackageManager.Tests.Repositories.Mocks;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PackageManager.Tests.Repositories.PackageRepositoryTests
{
    [TestFixture]
    public class Delete_Should
    {
        [Test]
        public void ThrowThrowArgumentNullException_WhenNullValueIsPassed()
        {
            // Arrange
            var packagesMock = new Mock<ICollection<IPackage>>();
            var loggerMock = new Mock<ILogger>();

            var package = new PackageRepositoryMock(loggerMock.Object, packagesMock.Object);

            // Act & Assert
            Assert.Throws<ArgumentNullException>(() => package.Delete(null));
        }
    }
}
