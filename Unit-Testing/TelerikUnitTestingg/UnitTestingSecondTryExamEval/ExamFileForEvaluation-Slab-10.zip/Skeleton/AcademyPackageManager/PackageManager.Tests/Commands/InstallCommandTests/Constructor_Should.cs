﻿using Moq;
using NUnit.Framework;
using PackageManager.Commands;
using PackageManager.Commands.Contracts;
using PackageManager.Core.Contracts;
using PackageManager.Models.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PackageManager.Tests.Commands.InstallCommandTests
{
    [TestFixture]
    class Constructor_Should
    {
        [Test]
        public void ConstructorSets_AppropriatePassedValues_ForInstaller() {
            var installerMock = new Mock<IInstaller<IPackage>>();
            var packageMock = new Mock<IPackage>();

            //installerMock.Setup(p => p.);
            
           var  installCommandUT = new InstallCommand(installerMock.Object, packageMock.Object);

            Assert.AreEqual(installerMock.Object, installCommandUT);
        }

        [Test]
        public void ConstructorSets_AppropriatePassedValues_ForPackAge()
        {
            var installerMock = new Mock<IInstaller<IPackage>>();
            var packageMock = new Mock<IPackage>();

            //installerMock.Setup(p => p.);

            var installCommandUT = new InstallCommand(installerMock.Object, packageMock.Object);

            Assert.AreEqual(packageMock.Object, installCommandUT);
        }
    }
}
