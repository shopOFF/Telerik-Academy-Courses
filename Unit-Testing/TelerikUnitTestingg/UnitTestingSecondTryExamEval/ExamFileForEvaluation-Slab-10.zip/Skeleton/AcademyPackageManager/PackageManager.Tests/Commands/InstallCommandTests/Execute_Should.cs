﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PackageManager.Tests.Commands.InstallCommandTests
{
    [TestFixture]
    class Execute_Should
    {
        [Test]
        public void Calling_PerformOperationFromInstaller()
        {

        }
    }
}
