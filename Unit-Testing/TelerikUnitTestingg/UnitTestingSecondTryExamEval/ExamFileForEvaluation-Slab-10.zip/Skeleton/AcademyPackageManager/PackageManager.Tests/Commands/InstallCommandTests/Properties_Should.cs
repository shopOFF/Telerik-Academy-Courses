﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PackageManager.Tests.Commands.InstallCommandTests
{
    [TestFixture]
    class Properties_Should
    {
        [Test]
        public void SetRightTest_ValuesForOpration_OfInstaller()
        {

        }
    }
}
