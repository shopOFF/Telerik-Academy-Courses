﻿using Moq;
using NUnit.Framework;
using PackageManager.Models;
using PackageManager.Models.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PackageManager.Tests.Models.PackageTests
{
    [TestFixture]
    class Constructor_Should
    {

        [Test]
        public void SetConstructorProject_WhenDependenciesIsOptional()
        {
            var versionMock = new Mock<IVersion>();
            //var packageMock = new Mock<IPackage>();
            //packageMock.Object.Equals(null);
            var dependencyMock = new Mock<ICollection<IPackage>>();
           // var packages = dependencyMock.Setup(m => m.Add(packageMock.Object));

            var package = new Package("name", versionMock.Object, dependencyMock.Object);

            Assert.AreEqual(null, package.Dependencies);

        }

        [Test]
        public void SetConstructorProject_WhenDependenciesIsPassed()
        {
            var versionMock = new Mock<IVersion>();
            //var packageMock = new Mock<IPackage>();
            //packageMock.Object.Equals(null);
            var dependencyMock = new Mock<ICollection<IPackage>>();
            // var packages = dependencyMock.Setup(m => m.Add(packageMock.Object));

            var package = new Package("name", versionMock.Object, dependencyMock.Object);

            Assert.AreEqual(dependencyMock.Object, package.Dependencies);

        }
    }
}
