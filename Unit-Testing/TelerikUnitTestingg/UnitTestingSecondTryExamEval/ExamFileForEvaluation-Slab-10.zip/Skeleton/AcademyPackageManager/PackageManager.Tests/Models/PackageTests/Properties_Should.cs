﻿using Moq;
using NUnit.Framework;
using PackageManager.Models;
using PackageManager.Models.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PackageManager.Tests.Models.PackAgeTest
{
    [TestFixture]
    class Properties_Should
    {
        [Test]
        public void SetName_WhenIsCorrectly()
        {
            var versionMock = new Mock<IVersion>(); 
            var packageMock = new Mock<IPackage>();
            var dependencyMock = new Mock<ICollection<IPackage>>();
            var packages = dependencyMock.Setup(m => m.Add(packageMock.Object));

            var package = new Package ("name", versionMock.Object, dependencyMock.Object);

            Assert.AreEqual("name", package.Name);

        }
        [Test]
        public void SetVersion_WhenIsCorrectly()
        {
            var versionMock = new Mock<IVersion>();
            var packageMock = new Mock<IPackage>();
            var dependencyMock = new Mock<ICollection<IPackage>>();
            var packages = dependencyMock.Setup(m => m.Add(packageMock.Object));

            var package = new Package("name", versionMock.Object, dependencyMock.Object);

            Assert.AreEqual(versionMock.Object, package.Version);

        }

        [Test]
        public void SetURL_WhenIsCorrectly()
        {
            var versionMock = new Mock<IVersion>();
            var packageMock = new Mock<IPackage>();
            var dependencyMock = new Mock<ICollection<IPackage>>();
            var packages = dependencyMock.Setup(m => m.Add(packageMock.Object));
            var expectedUrl = packageMock.Object.Url;

            var package = new Package("name", versionMock.Object, dependencyMock.Object);          

            Assert.AreEqual(expectedUrl, null);

        }

    }
}
