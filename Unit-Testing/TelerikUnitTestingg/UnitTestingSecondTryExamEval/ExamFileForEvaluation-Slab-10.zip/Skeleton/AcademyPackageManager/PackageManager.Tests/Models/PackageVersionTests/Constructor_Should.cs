﻿using NUnit.Framework;
using PackageManager.Enums;
using PackageManager.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PackageManager.Tests.Models.PackageVersionTests
{
    [TestFixture]
    class Constructor_Should
    {
        [Test]
        public void Constructor_Should_SetAppropriatePassedValues_ForMajor() {
            // Arrange & Act
            var packageUnderTest = new PackageVersion(1,2,3, VersionType.alpha);

            // Assert
            Assert.AreEqual(1, packageUnderTest.Major);
        }

        [Test]
        public void Constructor_Should_SetAppropriatePassedValues_ForMinor()
        {
            // Arrange & Act
            var packageUnderTest = new PackageVersion(1, 2, 3, VersionType.alpha);

            // Assert
            Assert.AreEqual(2, packageUnderTest.Minor);
        }

        [Test]
        public void Constructor_Should_SetAppropriatePassedValues_ForPatch()
        {
            // Arrange & Act
            var packageUnderTest = new PackageVersion(1, 2, 3, VersionType.alpha);

            // Assert
            Assert.AreEqual(3, packageUnderTest.Patch);
        }

        [Test]
        public void Constructor_Should_SetAppropriatePassedValues_ForVersionType()
        {
            // Arrange & Act
            var packageUnderTest = new PackageVersion(1, 2, 3, VersionType.alpha);

            // Assert
            Assert.AreEqual(VersionType.alpha, packageUnderTest.VersionType);
        }
    }
}
