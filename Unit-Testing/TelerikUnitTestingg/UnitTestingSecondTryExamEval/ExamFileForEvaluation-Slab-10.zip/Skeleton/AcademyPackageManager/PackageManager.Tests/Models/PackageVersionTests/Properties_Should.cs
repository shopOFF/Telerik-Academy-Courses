﻿using Moq;
using NUnit.Framework;
using PackageManager.Enums;
using PackageManager.Models;
using PackageManager.Tests.Models.PackageVersionTests.Mock;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PackageManager.Tests.Models.PackageVersionTests
{
    [TestFixture]
    class Properties_Should
    {
        [TestCase(1)]
        [TestCase(2)]
        public void ReturnTheCorrectMajorValue_WhenCalledWithValidValue(int major)
        {
            // Arrange & Act
            var packageUnderTest = new PackageVersion(major, 2, 3, VersionType.alpha);

            // Assert
            Assert.AreEqual(major, packageUnderTest.Major);
        }


        public void ThrowsArgumentException_WhenInvalidValueIsPassed(int major)
        {
            // Arrange & Act
            //var packageUnderTest = new Mock<PackageVersionMock>();
            //packageUnderTest.SetupGet(p => p.Major).Returns(major);
            //var packageUnderTest = new PackageVersion(major, 2, 3, VersionType.alpha);

            // Act && Assert
            // Act && Assert
           //Assert.That(() => packageUnderTest.Object.Major, Throws.ArgumentException);
           // Assert.Throws<ArgumentException>(() => packageUnderTest.Major = major);
        }

        [TestCase(1)]
        [TestCase(2)]
        public void ReturnTheCorrectMinorValue_WhenCalledWithValidValue(int minor)
        {
            // Arrange & Act
            var packageUnderTest = new PackageVersion(1, minor, 3, VersionType.alpha);

            // Assert
            Assert.AreEqual(minor, packageUnderTest.Minor);
        }

        [TestCase(1)]
        [TestCase(2)]
        public void ReturnTheCorrectPatchValue_WhenCalledWithValidValue(int patch)
        {
            // Arrange & Act
            var packageUnderTest = new PackageVersion(1, 2, patch, VersionType.alpha);

            // Assert
            Assert.AreEqual(patch, packageUnderTest.Patch);
        }

        [TestCase(VersionType.alpha)]
        [TestCase(VersionType.beta)]
        public void ReturnTheCorrectVersionType_WhenCalledWithValidValue(VersionType versionType)
        {
            // Arrange & Act
            var packageUnderTest = new PackageVersion(1, 2, 3, versionType);

            // Assert
            Assert.AreEqual(versionType, packageUnderTest.VersionType);
        }
    }
}
