﻿using Castle.Core.Resource;
using Moq;
using NUnit.Framework;
using PackageManager.Models;
using PackageManager.Models.Contracts;
using PackageManager.Repositories;
using PackageManager.Repositories.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PackageManager.Tests.Models.ProjectTest
{
    [TestFixture]
    class Constructor_Should
    {
        [Test]
        public void SetConstructorProject_WhenPackageRepositoryIsPassed()
        {
            var packageMock = new Mock<IPackage>();
            var repositoryMock = new Mock<IRepository<IPackage>>();
           // var packages = repositoryMock.Setup(m => m.Add(packageMock.Object));

            var project  = new Project("test", "test", repositoryMock.Object);

            Assert.AreEqual(repositoryMock.Object, project.PackageRepository);
        }

        [Test]
        public void SetConstructorProject_WhenPackageRepositoryIsOptional()
        {

        }
    }
}
