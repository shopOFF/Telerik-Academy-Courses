﻿using Moq;
using NUnit.Framework;
using PackageManager.Models;
using PackageManager.Models.Contracts;
using PackageManager.Repositories.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PackageManager.Tests.Models.ProjectTests
{
    [TestFixture]
    class Properties_Should
    {
        [Test]
        public void SetName_WhenIsCorrectly()
        {
            var packageMock = new Mock<IPackage>();
            var repositoryMock = new Mock<IRepository<IPackage>>();
            //var packages = repositoryMock.Setup(m => m.Add(packageMock.Object));

            var project = new Project("test", "test", repositoryMock.Object);

            Assert.AreEqual("test", project.Name);

        }


        [Test]
        public void SetLocation_WhenIsCorrectly()
        {
            var packageMock = new Mock<IPackage>();
            var repositoryMock = new Mock<IRepository<IPackage>>();
            //var packages = repositoryMock.Setup(m => m.Add(packageMock.Object));

            var project = new Project("test", "test", repositoryMock.Object);

            Assert.AreEqual("test", project.Location);

        }
    }
}
