﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Moq;
using NUnit.Framework;
using PackageManager.Commands.Contracts;

namespace PackageManager.Tests.Commands.InstallCommand
{ /*
    [TestFixture]
    public class ConstructorTests
    {
        [Test] // Testing null installer
        public void InstallCommandConstructor_NullIsPassedAsInstaller_ShouldThrowArgumentNullException()
        {
            // Arrange
            var sut = new 
        }
    }*/
}
