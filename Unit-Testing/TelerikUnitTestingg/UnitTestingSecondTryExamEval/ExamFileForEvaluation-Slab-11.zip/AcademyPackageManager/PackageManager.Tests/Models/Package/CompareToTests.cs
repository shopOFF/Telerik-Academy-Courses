﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using Moq;
using PackageManager.Models.Contracts;
using PackageManager.Models;
namespace PackageManager.Tests.Models.Package
{
    [TestFixture]
    public class CompareToTests
    {
        [Test] // Testing if other is null
        public void PackagesCompareTo_PassingNullAsArgument_ShouldThrowArgumentException()
        {
            // Arrange
            var iVersionStub = new Mock<IVersion>();
            var sut = new PackageManager.Models.Package("name", iVersionStub.Object);

            // Act and Assert
            Assert.Throws<ArgumentNullException>(()=>sut.CompareTo(null));
        }

        [Test] // Testing if the names are not the same
        public void PackageCompareTo_APackageWithADifferentName_ShouldThrowAnArgumentException()
        {
            // Arrange
            var iVersionStub = new Mock<IVersion>();
            var sut = new PackageManager.Models.Package("package one", iVersionStub.Object);
            var otherPackage = new PackageManager.Models.Package("package two", iVersionStub.Object);

            // Act and Assert
            Assert.Throws<ArgumentException>(()=>sut.CompareTo(otherPackage));
        }

        [Test] // Testing the same version
        public void PackageCompareTo_TheSameVersion_ShouldReturnZero()
        {
            // Arrange
            var iVersionStub = new Mock<IVersion>();
            var sut = new PackageManager.Models.Package("package", iVersionStub.Object);

            // Act
            var comaprisonResult = sut.CompareTo(sut);

            // Assert
            Assert.Zero(comaprisonResult);
        }

        [Test] // Testing a lower version
        public void PackageCompareTo_ALowerVersion_ShouldReturnMinusOne()
        {
            // Arrange
            var sutHigher = new PackageManager.Models.Package("name", new PackageManager.Models.PackageVersion(4, 3, 2, Enums.VersionType.alpha));
            var sutLower = new PackageManager.Models.Package("name", new PackageManager.Models.PackageVersion(2, 2, 2, Enums.VersionType.alpha));
            const int expectedOutcome = -1;

            // Act
            var comaprisonResult = sutLower.CompareTo(sutHigher);

            // Assert
            Assert.AreEqual(expectedOutcome, comaprisonResult);
        }

        [Test] // Testing with a greater version
        public void PackageCompareTo_AHigherVersion_ShouldReturnPlusOne()
        {
            // Arrange
            var sutHigher = new PackageManager.Models.Package("name", new PackageManager.Models.PackageVersion(4, 3, 2, Enums.VersionType.alpha));
            var sutLower = new PackageManager.Models.Package("name", new PackageManager.Models.PackageVersion(2, 2, 2, Enums.VersionType.alpha));
            const int expectedOutcome = 1;

            // Act
            var comaprisonResult = sutHigher.CompareTo(sutLower);

            // Assert
            Assert.AreEqual(expectedOutcome, comaprisonResult);
        }
    }
}
