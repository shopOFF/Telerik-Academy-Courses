﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Moq;
using NUnit.Framework;
using PackageManager.Models.Contracts;

namespace PackageManager.Tests.Models.Package
{
    [TestFixture]
    class EqualsTests
    {
        [Test] // Testing if the object is null
        public void PackageCompareTo_aNullObject_ShouldThrowArgumentNullException()
        {
            // Arrange
            var iVersionStub = new Mock<IVersion>();
            var sut = new PackageManager.Models.Package("name", iVersionStub.Object);

            // Act and Assert
            Assert.Throws<ArgumentNullException>(()=>sut.Equals(null));
        }

        [Test] // Testing if the object is not a package
        public void PackageCompareTo_aNonIPackageObject_ShouldThrowArgumentException()
        {
            // Arrange
            var iVersionStub = new Mock<IVersion>();
            var sut = new PackageManager.Models.Package("name", iVersionStub.Object);
            var stringObject = "not IPackage";

            // Act and Assert
            Assert.Throws<ArgumentException>(()=>sut.Equals(stringObject));
        }

        [Test] // Testing two equal objects
        public void PackageCompareTo_AnEqualPackage_ShouldReturnTrue()
        {
            // Arrange
            var iVersionStub = new Mock<IVersion>();
            var sut = new PackageManager.Models.Package("name", iVersionStub.Object);

            // Act
            bool comparisonResult = sut.Equals(sut);

            // Assert
            Assert.True(comparisonResult);
        }

        [Test] // Testing two different objects
        public void PackageCompareTo_aNonEqualValue_ShouldReturnFalse()
        {
            // Arrange
            var iVersionStub = new Mock<IVersion>();
            var sut = new PackageManager.Models.Package("name", iVersionStub.Object);
            var otherSut = new PackageManager.Models.Package("other name", iVersionStub.Object);

            // Act
            bool comparisonResult = sut.Equals(otherSut);

            // Assert
            Assert.False(comparisonResult);
        }
    }
}
