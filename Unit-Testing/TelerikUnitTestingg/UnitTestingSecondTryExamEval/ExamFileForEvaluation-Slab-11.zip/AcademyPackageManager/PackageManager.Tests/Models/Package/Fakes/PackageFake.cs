﻿using PackageManager.Models.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PackageManager.Tests.Models.Package.Fakes
{
    internal class PackageFake : PackageManager.Models.Package
    {
        public PackageFake(string name, IVersion version, ICollection<IPackage> dependencies = null) : base(name, version, dependencies) { }

        public string ExposedUrl
        {
            get
            {
                return base.Url;
            } 
            set
            {
                //base. = value;
            }
        }
    }
}
