﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PackageManager.Tests.Models.Package
{
    using NUnit.Framework;
    using Moq;
    using PackageManager.Models.Contracts;
    using PackageManager.Models;

    [TestFixture]
    public class NameTests
    {
        [Test] // Testing if name is valid
        public void PackageNameProperty_IsSetToAValidString_ShouldBeSetCorrectly()
        {
            // Arrange
            var iVersionStub= new Mock<IVersion>();
            var targetValue = "valid name";

            // Act
            var sut = new Package(targetValue, iVersionStub.Object);

            // Assert
            Assert.AreEqual(targetValue, sut.Name);
        }

        [Test] //Testing if name is null
        public void PackageNameProperty_IsNull_ShouldThrowArgumentNullException ()
        {
            // Arrange
            var iVersionStub = new Mock<IVersion>();

            // Act and Assert
            Assert.Throws<ArgumentNullException>(()=> new Package(null, iVersionStub.Object));
        }
    }
}
