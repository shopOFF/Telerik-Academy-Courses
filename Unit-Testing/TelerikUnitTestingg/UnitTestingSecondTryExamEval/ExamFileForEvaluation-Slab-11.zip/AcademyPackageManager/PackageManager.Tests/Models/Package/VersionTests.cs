﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Moq;
using NUnit.Framework;
using PackageManager.Models;
using PackageManager.Models.Contracts;

namespace PackageManager.Tests.Models.Package
{
    [TestFixture]
    public class VersionTests
    {
        [Test] // Testing if version is correct
        public void PackageVersionProperty_IsSetToAValidIVersion_ShouldCreateAnObjectCorrectly()
        {
            // Arrange
            var iVersionMock = new Mock<IVersion>();

            // Act
            var sut = new PackageManager.Models.Package("name", iVersionMock.Object);

            // Assert
            Assert.IsInstanceOf(typeof(IVersion), sut.Version);
        }

        [Test] // Testing if version is null
        public void PackageVersionProperty_IsNull_ShouldThrowAnArgumentNullException()
        {
            // Arrange and Act and Assert
            Assert.Throws<ArgumentNullException>(()=> new PackageManager.Models.Package("name", null));
        }
    }
}
