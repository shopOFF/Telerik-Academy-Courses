﻿namespace PackageManager.Tests.Models.PackageVersion
{
    using NUnit.Framework;
    using PackageManager.Enums;
    using PackageManager.Models;

    [TestFixture]
    public class ConstructorTests
    {
        [Test] // Testing major
        public void PackageVersionConstructor_SettingAValidMajorVersion_ShouldCreateAnObjectWithValidMajorVersion()
        {
            // Arrange and Act
            const int validMajorVersion = 5;
            var sut = new PackageVersion(validMajorVersion, 4, 5, VersionType.alpha);

            // Assert
            Assert.AreEqual(validMajorVersion, sut.Major);
        }

        [Test] // Testing minor
        public void PackageVersionConstructor_SettingAValidMinorVersion_ShouldCreateAnObjectWithValidMinorVersion()
        {
            // Arrange and Act
            const int validMinorVersion = 5;
            var sut = new PackageVersion(4, validMinorVersion,  5, VersionType.alpha);

            // Assert
            Assert.AreEqual(validMinorVersion, sut.Minor);
        }

        [Test] // Testing patch
        public void PackageVersionConstructor_SettingAValidPatchVersion_ShouldCreateAnObjectWithAValidPatchVersion()
        {
            // Arrange and Act
            const int validPatchVersion = 5;
            var sut = new PackageVersion(1, 2, validPatchVersion, VersionType.alpha);

            // Assert
            Assert.AreEqual(validPatchVersion, sut.Patch);
        }

        [Test] // Testing VersionType
        public void PackageVersionConstructor_SettingAValidVersionType_ShouldCreateAnObjectWithAValidVersionType()
        {
            // Arrange and Act
            VersionType validVersionType = VersionType.final;
            var sut = new PackageVersion(1, 2, 3, validVersionType);
            // Assert
            Assert.AreEqual(validVersionType, sut.VersionType);
        }

        [Test] // Testing object type
        public void PackageVersionConstructor_IsCalledWithValidArguments_ShouldCreateAValidPackageVersionObject()
        {
            // Arrange and Act
            var sut = new PackageVersion(1, 2, 3, VersionType.final);

            // Assert
            Assert.IsInstanceOf((typeof(PackageVersion)), sut);
        }
    }
}
