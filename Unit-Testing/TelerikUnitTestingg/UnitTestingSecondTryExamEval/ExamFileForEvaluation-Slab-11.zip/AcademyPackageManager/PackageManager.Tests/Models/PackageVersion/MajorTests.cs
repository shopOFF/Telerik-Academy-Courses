﻿namespace PackageManager.Tests.Models.PackageVersion
{
    using NUnit.Framework;
    using PackageManager.Models;
    using System;

    [TestFixture]
    public class MajorTests
    {
        [Test] // Testing when major = 0
        public void PackageVersionMajorProperty_AssigningZeroValue_ShouldAssignAZeroValueWithNoExceptionsThrown()
        {
            // Arrange
            const int targetValue = 0;

            // Act
            PackageVersion sut = new PackageVersion(targetValue,4,5,Enums.VersionType.beta);
            
            // Assert
            Assert.AreEqual(targetValue, sut.Major);
        }

        [Test] // Testing when major = -10
        public void PackageVersionMajorProperty_AssigningNegativeValue_ShouldThrowAnArgumentException()
        {
            // Arrange 
            const int targetValue = -10;

            // Act and Assert
            Assert.Throws<ArgumentException>(() => new PackageVersion(targetValue, 4, 5, Enums.VersionType.beta));
        }
    }
}
