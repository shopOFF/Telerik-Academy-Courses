﻿namespace PackageManager.Tests.Models.PackageVersion
{
    using NUnit.Framework;
    using PackageManager.Models;
    using System;

    [TestFixture]
    public class MinorTests
    {
        [Test] // Testing when minor = 0
        public void PackageVersionMinorProperty_AssigningZeroValue_ShouldAssignAZeroValueWithNoExceptionsThrown()
        {
            // Arrange
            const int targetValue = 0;

            // Act
            PackageVersion sut = new PackageVersion(4, targetValue, 5, Enums.VersionType.beta);

            // Assert
            Assert.AreEqual(targetValue, sut.Minor);
        }

        [Test] // Testing when minor = -10
        public void PackageVersionMinorProperty_AssigningNegativeValue_ShouldThrowAnArgumentException()
        {
            // Arrange 
            const int targetValue = -10;

            // Act and Assert
            Assert.Throws<ArgumentException>(() => new PackageVersion(4, targetValue, 5, Enums.VersionType.beta));
        }
    }
}
