﻿namespace PackageManager.Tests.Models.PackageVersion
{
    using NUnit.Framework;
    using PackageManager.Models;
    using System;

    [TestFixture]
    public class PatchTests
    {
        [Test] // Testing when patch = 0
        public void PackageVersionPatchProperty_AssigningZeroValue_ShouldAssignAZeroValueWithNoExceptionsThrown()
        {
            // Arrange
            const int targetValue = 0;

            // Act
            PackageVersion sut = new PackageVersion(4, 5, targetValue, Enums.VersionType.beta);

            // Assert
            Assert.AreEqual(targetValue, sut.Patch);
        }

        [Test] // Testing when patch = -10
        public void PackageVersionPatchProperty_AssigningNegativeValue_ShouldThrowAnArgumentException()
        {
            // Arrange 
            const int targetValue = -10;

            // Act and Assert
            Assert.Throws<ArgumentException>(() => new PackageVersion(4, 5, targetValue, Enums.VersionType.beta));
        }
    }
}
