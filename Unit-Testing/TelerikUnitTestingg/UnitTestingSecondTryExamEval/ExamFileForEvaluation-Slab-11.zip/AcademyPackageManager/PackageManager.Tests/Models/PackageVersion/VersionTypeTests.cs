﻿namespace PackageManager.Tests.Models.PackageVersion
{
    using System;
    using NUnit.Framework;
    using PackageManager.Enums;
    using PackageManager.Models;

    [TestFixture]
    public class VersionTypeTests
    {
        [Test] // Testing correct VersionType
        public void PackageVersionVersionType_AssigningACorrectValue_ShouldAssignTheCorrectValueWithNoExceptionsThrown ()
        {
            // Arrange
            VersionType targetValue = VersionType.beta;

            // Act
            var sut = new PackageVersion(4, 5, 6, targetValue);

            // Assert
            Assert.AreEqual(targetValue, sut.VersionType);
        }

        // TODO: Finish Test 2 - 4
        /*
        [Test] // Testing incorrect VersionType
        public void PackageVersionVersionType_AssigningAnIncorrectValue_ShouldThrowAnArgumentException ()
        {
            // Arrange
            var targetValue = Enum.Parse( typeof(VersionType), "incorrect");

            // Act and Assert
            Assert.Throws<ArgumentException>(() => new PackageVersion(1,2,3,));
        }
        */
    }
}
