﻿namespace PackageManager.Tests.Models.Project
{
    using NUnit.Framework;
    using PackageManager.Models;

    [TestFixture]
    public class ConstructorTests
    {
        // TODO: Need to finish this one : 3 - 1, 3 - 2
        //[Test] // Testing optional argument
        //public void ProjectConstructor_NotSupplyingPackageRepository_ShouldCreateAnEmptyPackageRepository()
        //{
            // Arrange and Act
        //}
    }
}
