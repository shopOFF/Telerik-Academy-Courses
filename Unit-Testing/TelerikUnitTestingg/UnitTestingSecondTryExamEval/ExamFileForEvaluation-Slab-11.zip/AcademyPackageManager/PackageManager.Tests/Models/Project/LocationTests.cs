﻿namespace PackageManager.Tests.Models.Project
{
    using System;
    using NUnit.Framework;
    using PackageManager.Models;

    [TestFixture]
    public class LocationTests
    {
        [Test] // Testing if location is correct
        public void ProjectLocationProperty_IsSetToAValidString_ShouldCreateAnObjectWithACorretlySetLocation()
        {
            // Arrange
            string targetValue = "valid string";

            // Act
            var sut = new Project("name", targetValue);

            // Assert
            Assert.AreEqual(targetValue, sut.Location);
        }

        [Test] // Testing if location is null
        public void ProjectLocationProperty_IsSetToNull_ShouldThrowAnArgumentException()
        {
            // Arrange and Act and Assert
            Assert.Throws<ArgumentNullException>(() => new Project("location", null));
        }
    }
}
