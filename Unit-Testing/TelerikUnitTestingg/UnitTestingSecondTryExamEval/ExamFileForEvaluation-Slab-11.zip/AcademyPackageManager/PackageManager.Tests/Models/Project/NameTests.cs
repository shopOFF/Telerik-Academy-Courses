﻿namespace PackageManager.Tests.Models.Project
{
    using System;
    using NUnit.Framework;
    using PackageManager.Models;

    [TestFixture]
    public class NameTests
    {
        [Test] // Testing if name is correct
        public void ProjectNameProperty_IsSetToAValidString_ShouldCreateAnObjectWithACorretlySetName()
        {
            // Arrange
            string targetValue = "valid string";

            // Act
            var sut = new Project(targetValue, "location");

            // Assert
            Assert.AreEqual(targetValue, sut.Name);
        }

        [Test] // Testing if name is null
        public void ProjectNameProperty_IsSetToNull_ShouldThrowAnArgumentException()
        {
            // Arrange and Act and Assert
            Assert.Throws<ArgumentNullException>(() => new Project(null, "location"));
        }
    }
}
