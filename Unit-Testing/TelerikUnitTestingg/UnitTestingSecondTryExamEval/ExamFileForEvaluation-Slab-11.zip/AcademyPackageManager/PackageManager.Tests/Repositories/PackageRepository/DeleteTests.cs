﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Moq;
using NUnit.Framework;
using PackageManager.Info.Contracts;
using PackageManager.Repositories;

namespace PackageManager.Tests.Repositories.PackageRepository
{
    [TestFixture]
    public class DeleteTests
    {
        [Test] // Testing if null
        public void PackageRepositoryDelete_NullValueProvided_ShouldThrowArgumentNullException()
        {
            // Arrange
            var iLoggerStub = new Mock<ILogger>();
            var sut = new PackageManager.Repositories.PackageRepository(iLoggerStub.Object);

            // Act and Assert
            Assert.Throws<ArgumentNullException>(()=>sut.Delete(null));
        }
    }
}
