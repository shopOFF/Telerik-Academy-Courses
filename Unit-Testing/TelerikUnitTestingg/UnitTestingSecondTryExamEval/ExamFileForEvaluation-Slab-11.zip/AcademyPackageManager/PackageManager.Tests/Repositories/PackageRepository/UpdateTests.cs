﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Moq;
using NUnit.Framework;
using PackageManager.Repositories;
using PackageManager.Info.Contracts;

namespace PackageManager.Tests.Repositories
{
    [TestFixture]
    public class UpdateTests
    {
        [Test] // Testing if package is null
        public void PackageRepositoryUpdate_aNullPackage_ShouldThrowAnArgumentNullException()
        {
            // Arrange
            var iLoggerStub = new Mock<ILogger>();
            var sut = new PackageManager.Repositories.PackageRepository(iLoggerStub.Object);

            // Act and Assert
            Assert.Throws<ArgumentNullException>(() => sut.Update(null));
        }
    }
}
