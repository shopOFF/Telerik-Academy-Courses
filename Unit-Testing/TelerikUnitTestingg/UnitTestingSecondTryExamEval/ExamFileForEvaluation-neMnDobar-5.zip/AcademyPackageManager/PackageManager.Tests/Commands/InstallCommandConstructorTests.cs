﻿using Moq;
using NUnit.Framework;
using PackageManager.Models.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PackageManager.Tests.Commands
{
    [TestFixture]
    public class InstallCommandConstructorTests
    {
        [Test]
        public void TestIfPassedValuesAreValid_WhenObjectIsConstructed()
        {
            var package = new Mock<IPackage>();
            // Fail
        }
    }
}
