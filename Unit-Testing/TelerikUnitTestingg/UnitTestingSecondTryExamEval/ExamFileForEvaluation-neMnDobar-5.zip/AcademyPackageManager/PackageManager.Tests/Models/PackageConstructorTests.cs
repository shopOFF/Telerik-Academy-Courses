﻿using Moq;
using NUnit.Framework;
using PackageManager.Models;
using PackageManager.Models.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PackageManager.Tests.Models
{
    [TestFixture]
    class PackageConstructorTests
    {

        [Test]
        public void SetValidName_WhenObjectIsConstructed()
        {
            var mockedVersion = new Mock<IVersion>();

            // Arrange & Act
            var package = new Package("PackageName", mockedVersion.Object);

            // Assert
            Assert.AreEqual("PackageName", package.Name);
        }

        [Test]
        public void ThrowArgumentNullExceptionIfNameIsNull_WhenObjectIsConstructed()
        {
            var mockedVersion = new Mock<IVersion>();
            Assert.Throws<ArgumentNullException>(() => new Package(null, mockedVersion.Object));
        }

        [Test]
        public void SetValidVersion_WhenObjectIsConstructed()
        {
            var mockedVersion = new Mock<IVersion>();

            // Arrange & Act
            var package = new Package("PackageName", mockedVersion.Object);

            // Assert
            Assert.AreEqual(mockedVersion.Object, package.Version);
        }

        [Test]
        public void ThrowArgumentNullExceptionIfVersionIsNull_WhenObjectIsConstructed()
        {
            Assert.Throws<ArgumentNullException>(() => new Package("PackageName", null));
        }

        [Test]
        public void SetValidURL_WhenObjectIsConstruted()
        {
            var mockedVersion = new Mock<IVersion>();

            var package = new Package("PackageName", mockedVersion.Object);

            Assert.IsNotNull(package.Url, "The URL string is null!");
            
            // Start of useless poorly written asserts
            StringAssert.Contains(package.Version.Major.ToString(), package.Url, "The URL string does not contain Version.Major");
            StringAssert.Contains(package.Version.Minor.ToString(), package.Url, "The URL string does not contain Version.Minor");
            StringAssert.Contains(package.Version.Patch.ToString(), package.Url, "The URL string does not contain Version.Patch");
            // End of useless poorly written asserts

            StringAssert.Contains(package.Version.VersionType.ToString(), package.Url, "The URL string does not contain Version.VersionType");
        }

        // Test for optional parameter dependencies
        [Test]
        public void InitializeDependenciesIfNotPassedAsParameter_WhenObjectIsConstructed()
        {
            var mockedVersion = new Mock<IVersion>();

            // Arrange & Act
            var package = new Package("PackageName", mockedVersion.Object);

            // Assert
            Assert.IsNotNull(package.Dependencies);
        }

        // Test for passed parameter packages
        [Test]
        public void SetValidDependencies_WhenObjectIsConstructed()
        {
            var mockedVersion = new Mock<IVersion>();
            var mockedPackage = new Mock<IPackage>();

            // Arrange & Act
            var package = new Package("PackageName", mockedVersion.Object, new List<IPackage>() { mockedPackage.Object });

            // Assert
            Assert.AreEqual(mockedPackage.Object, package.Dependencies.ElementAt(0));
        }

    }
}
