﻿using Moq;
using NUnit.Framework;
using PackageManager.Enums;
using PackageManager.Models;
using PackageManager.Models.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PackageManager.Tests.Models
{
    [TestFixture]
    public class PackageMethodsTests
    {
        [Test]
        public void ThrowArgumentNullExceptionIfOtherObjectHasDifferentName_WhenCallingCompareTo()
        {
            var mockedVersion = new Mock<IVersion>();

            var package = new Package("PackageName", mockedVersion.Object);

            Assert.Throws<ArgumentNullException>(() => package.CompareTo(null));
        }

        [Test]
        public void ThrowArgumentExceptionIfOtherObjectHasDifferentName_WhenCallingCompareTo()
        {
            var mockedVersion = new Mock<IVersion>();

            var package = new Package("PackageName", mockedVersion.Object);
            var anotherPackage = new Package("AnotherPackageName", mockedVersion.Object);

            Assert.Throws<ArgumentException>(() => package.CompareTo(anotherPackage));
        }

        [Test]
        public void TestPassedPackageToHaveHigherVersion_WhenCallingCompareTo()
        {
            var mockedVersion = new Mock<IVersion>();
            var anotherMockedVersion = new Mock<IVersion>();

            mockedVersion.Setup(x => x.Major).Returns(2);
            mockedVersion.Setup(x => x.Minor).Returns(2);
            mockedVersion.Setup(x => x.Patch).Returns(2);
            mockedVersion.Setup(x => x.VersionType).Returns(VersionType.alpha);
            anotherMockedVersion.Setup(x => x.Major).Returns(3);
            anotherMockedVersion.Setup(x => x.Minor).Returns(3);
            anotherMockedVersion.Setup(x => x.Patch).Returns(3);
            anotherMockedVersion.Setup(x => x.VersionType).Returns(VersionType.beta);

            var package = new Package("PackageName", mockedVersion.Object);
            var anotherPackage = new Package("PackageName", anotherMockedVersion.Object);

            Assert.AreEqual(-1, package.CompareTo(anotherPackage));
        }

        [Test]
        public void TestPassedPackageToHaveLowerVersion_WhenCallingCompareTo()
        {
            var mockedVersion = new Mock<IVersion>();
            var anotherMockedVersion = new Mock<IVersion>();

            mockedVersion.Setup(x => x.Major).Returns(2);
            mockedVersion.Setup(x => x.Minor).Returns(2);
            mockedVersion.Setup(x => x.Patch).Returns(2);
            mockedVersion.Setup(x => x.VersionType).Returns(VersionType.alpha);
            anotherMockedVersion.Setup(x => x.Major).Returns(1);
            anotherMockedVersion.Setup(x => x.Minor).Returns(1);
            anotherMockedVersion.Setup(x => x.Patch).Returns(1);
            anotherMockedVersion.Setup(x => x.VersionType).Returns(VersionType.beta);

            var package = new Package("PackageName", mockedVersion.Object);
            var anotherPackage = new Package("PackageName", anotherMockedVersion.Object);

            Assert.AreEqual(1, package.CompareTo(anotherPackage));
        }

        [Test]
        public void TestPassedPackageToHaveTheSameVersion_WhenCallingCompareTo()
        {
            var mockedVersion = new Mock<IVersion>();
            var anotherMockedVersion = new Mock<IVersion>();

            mockedVersion.Setup(x => x.Major).Returns(2);
            mockedVersion.Setup(x => x.Minor).Returns(2);
            mockedVersion.Setup(x => x.Patch).Returns(2);
            mockedVersion.Setup(x => x.VersionType).Returns(VersionType.alpha);
            anotherMockedVersion.Setup(x => x.Major).Returns(2);
            anotherMockedVersion.Setup(x => x.Minor).Returns(2);
            anotherMockedVersion.Setup(x => x.Patch).Returns(2);
            anotherMockedVersion.Setup(x => x.VersionType).Returns(VersionType.alpha);

            var package = new Package("PackageName", mockedVersion.Object);
            var anotherPackage = new Package("PackageName", anotherMockedVersion.Object);

            Assert.AreEqual(0, package.CompareTo(anotherPackage));
        }

        [Test]
        public void ThrowArgumentNullExceptionIfPassedObjectIsNull_WhenCallingEquals()
        {
            var mockedVersion = new Mock<IVersion>();

            var package = new Package("PackageName", mockedVersion.Object);

            Assert.Throws<ArgumentNullException>(() => package.Equals(null));
        }

        [Test]
        public void ThrowArgumentNullExceptionIfPassedObjectIsNotIPackage_WhenCallingEquals()
        {
            var mockedVersion = new Mock<IVersion>();

            var package = new Package("PackageName", mockedVersion.Object);
            
            Assert.Throws<ArgumentException>(() => package.Equals(mockedVersion));
        }

        [Test]
        public void TestPackageToBeEqualToPassedPackage_WhenCallingEquals()
        {
            var mockedVersion = new Mock<IVersion>();

            var package = new Package("PackageName", mockedVersion.Object);
            var anotherPackage = new Package("PackageName", mockedVersion.Object);

            Assert.True(package.Equals(anotherPackage));
        }

        [Test]
        public void TestPackageToBeDifferentThanThePassedPackage_WhenCallingEquals()
        {
            var mockedVersion = new Mock<IVersion>();

            var package = new Package("PackageName", mockedVersion.Object);
            var anotherPackage = new Package("AnotherPackageName", mockedVersion.Object);

            Assert.False(package.Equals(anotherPackage));
        }

    }
}
