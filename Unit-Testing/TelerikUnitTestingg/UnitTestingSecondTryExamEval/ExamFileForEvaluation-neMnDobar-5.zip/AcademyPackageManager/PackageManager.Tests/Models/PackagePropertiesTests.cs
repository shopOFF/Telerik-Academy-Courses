﻿using Moq;
using NUnit.Framework;
using PackageManager.Models;
using PackageManager.Models.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PackageManager.Tests.Models
{
    [TestFixture]
    public class PackagePropertiesTests
    {

        [Test]
        public void ReturnValidName_WhenGetMethodIsCalled()
        {
            var mockedVersion = new Mock<IVersion>();

            // Arrange
            var package = new Package("PackageName", mockedVersion.Object);

            // Act
            var result = package.Name;

            // Assert
            Assert.AreEqual("PackageName", result);
        }

        [Test]
        public void ReturnValidVersion_WhenGetMethodIsCalled()
        {
            var mockedVersion = new Mock<IVersion>();

            // Arrange
            var package = new Package("PackageName", mockedVersion.Object);

            // Act
            var result = package.Version;

            // Assert
            Assert.AreEqual(mockedVersion.Object, result);
        }
    }
}
