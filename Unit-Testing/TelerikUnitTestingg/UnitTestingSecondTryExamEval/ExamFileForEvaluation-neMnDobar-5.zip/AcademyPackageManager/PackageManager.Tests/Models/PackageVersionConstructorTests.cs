﻿using NUnit.Framework;
using PackageManager.Enums;
using PackageManager.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PackageManager.Tests.Models
{

    [TestFixture]
    public class PackageVersionConstructorTests
    {
        [Test]
        public void SetValidMajor_WhenObjectIsConstructed()
        {
            // Arrange & Act
            var packageVersion = new PackageVersion(2, 2, 2, VersionType.alpha);

            // Assert
            Assert.AreEqual(2, packageVersion.Major);
        }

        [Test]
        public void ThrowArgumentException_WhenInvalidMajorIsPassedAsParameter()
        {
            Assert.Throws<ArgumentException>(() => new PackageVersion(-2, 2, 2, VersionType.alpha));
        }

        [Test]
        public void SetValidMinor_WhenObjectIsConstructed()
        {
            // Arrange & Act
            var packageVersion = new PackageVersion(2, 2, 2, VersionType.alpha);

            // Assert
            Assert.AreEqual(2, packageVersion.Minor);
        }

        [Test]
        public void ThrowArgumentException_WhenInvalidMinorIsPassedAsParameter()
        {
            Assert.Throws<ArgumentException>(() => new PackageVersion(2, -2, 2, VersionType.alpha));
        }

        [Test]
        public void SetValidPatch_WhenObjectIsConstructed()
        {
            // Arrange & Act
            var packageVersion = new PackageVersion(2, 2, 2, VersionType.alpha);

            // Assert
            Assert.AreEqual(2, packageVersion.Patch);
        }

        [Test]
        public void ThrowArgumentException_WhenInvalidPatchIsPassedAsParameter()
        {
            Assert.Throws<ArgumentException>(() => new PackageVersion(2, 2, -2, VersionType.alpha));
        }

        [Test]
        public void SetValidVersionType_WhenObjectIsConstructed()
        {
            // Arrange & Act
            var packageVersion = new PackageVersion(2, 2, 2, VersionType.alpha);

            // Assert
            Assert.AreEqual(VersionType.alpha, packageVersion.VersionType);
        }

        //[Test]
        //public void ThrowArgumentException_WhenInvalidVersionTypeIsPassedAsParameter()
        //{
        //    // Should pass invalid enum value
        //    Assert.Throws<ArgumentException>(() => new PackageVersion(2, 2, 2, VersionType.alpha));
        //}

    }
}
