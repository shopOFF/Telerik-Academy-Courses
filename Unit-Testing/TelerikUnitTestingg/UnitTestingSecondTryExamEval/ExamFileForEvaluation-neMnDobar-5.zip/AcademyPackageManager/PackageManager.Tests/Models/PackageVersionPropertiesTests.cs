﻿using NUnit.Framework;
using PackageManager.Enums;
using PackageManager.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PackageManager.Tests.Models
{
    [TestFixture]
    public class PackageVersionPropertiesTests
    {

        // NOTE: Tests for the setters are in the constructor tests class

        [Test]
        public void ReturnValidMajor_WhenGetMethodIsCalled()
        {
            // Arrange
            var packageVersion = new PackageVersion(2, 2, 2, VersionType.alpha);

            // Act
            var result = packageVersion.Major;

            // Assert
            Assert.AreEqual(2, result);
        }

        [Test]
        public void ReturnValidMinor_WhenGetMethodIsCalled()
        {
            // Arrange
            var packageVersion = new PackageVersion(2, 2, 2, VersionType.alpha);

            // Act
            var result = packageVersion.Minor;

            // Assert
            Assert.AreEqual(2, result);
        }


        [Test]
        public void ReturnValidPatch_WhenGetMethodIsCalled()
        {
            // Arrange
            var packageVersion = new PackageVersion(2, 2, 2, VersionType.alpha);

            // Act
            var result = packageVersion.Patch;

            // Assert
            Assert.AreEqual(2, result);
        }


        [Test]
        public void ReturnValidVersionType_WhenGetMethodIsCalled()
        {
            // Arrange
            var packageVersion = new PackageVersion(2, 2, 2, VersionType.alpha);

            // Act
            var result = packageVersion.VersionType;

            // Assert
            Assert.AreEqual(VersionType.alpha, result);
        }
    }
}
