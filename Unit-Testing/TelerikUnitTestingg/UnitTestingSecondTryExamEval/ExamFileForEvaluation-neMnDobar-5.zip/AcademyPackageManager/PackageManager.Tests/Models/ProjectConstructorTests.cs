﻿using Castle.Core.Logging;
using NUnit.Framework;
using PackageManager.Enums;
using PackageManager.Models;
using PackageManager.Models.Contracts;
using PackageManager.Repositories;
using PackageManager.Repositories.Contracts;
using System;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PackageManager.Info.Contracts;
using System.Collections.Generic;
using Moq;

namespace PackageManager.Tests.Models
{
    [TestFixture]
    public class ProjectConstructorTests
    {

        [Test]
        public void SetValidName_WhenObjectIsConstructed()
        {
            // Arrange & Act
            var project = new Project("ProjectName", "Location");

            // Assert
            Assert.AreEqual("ProjectName", project.Name);
        }

        [Test]
        public void ThrowArgumentNullExceptionIfNameIsNull_WhenObjectIsConstructed()
        {
            Assert.Throws<ArgumentNullException>(() => new Project(null, "Location"));
        }

        [Test]
        public void SetValidLocation_WhenObjectIsConstructed()
        {
            // Arrange & Act
            var project = new Project("ProjectName", "Location");

            // Assert
            Assert.AreEqual("Location", project.Location);
        }

        [Test]
        public void ThrowArgumentNullExceptionIfLocationIsNull_WhenObjectIsConstructed()
        {
            Assert.Throws<ArgumentNullException>(() => new Project("ProjectName", null));
        }

        // Test for optional parameter packages
        [Test]
        public void InitializePackageRepositoryIfNotPassedAsParameter_WhenObjectIsConstructed()
        {
            // Arrange & Act
            var project = new Project("ProjectName", "Location");

            // Assert
            Assert.IsNotNull(project.PackageRepository);
        }

        // Test for passed parameter packages
        [Test]
        public void SetValidPackageRepository_WhenObjectIsConstructed()
        {
            var mockedLogger = new Mock<Info.Contracts.ILogger>();
            var mockedPackage = new Mock<IPackage>();

            // Arrange & Act
            var project = new Project("ProjectName", "Location", new PackageRepository(mockedLogger.Object, new List<IPackage>() { mockedPackage.Object }));

            // Assert
            Assert.AreEqual(mockedPackage.Object, project.PackageRepository.GetAll().ElementAt(0));
        }

    }
}
