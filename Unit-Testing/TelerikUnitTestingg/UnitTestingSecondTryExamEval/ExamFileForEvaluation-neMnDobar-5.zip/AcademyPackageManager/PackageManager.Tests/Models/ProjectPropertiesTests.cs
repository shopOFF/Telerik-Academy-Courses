﻿using NUnit.Framework;
using PackageManager.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PackageManager.Tests.Models
{
    [TestFixture]
    public class ProjectPropertiesTests
    {

        [Test]
        public void ReturnValidName_WhenGetMethodIsCalled()
        {
            // Arrange
            var project = new Project("ProjectName", "Location");

            // Act
            var result = project.Name;

            // Assert
            Assert.AreEqual("ProjectName", result);
        }

        [Test]
        public void ReturnValidLocation_WhenGetMethodIsCalled()
        {
            // Arrange
            var project = new Project("ProjectName", "Location");

            // Act
            var result = project.Location;

            // Assert
            Assert.AreEqual("Location", result);
        }

    }
}
