﻿using NUnit.Framework;
using PackageManager.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PackageManager.Tests.Repositories
{
    [TestFixture]
    public class PackageRepositoryConstructorTests
    {
        [Test]
        public void ThrowArgumentNullExceptionIfLoggerIsNull_WhenObjectIsConstructed()
        {
            Assert.Throws<ArgumentNullException>(() => new PackageRepository(null));
        }
    }
}
