﻿using Castle.Core.Logging;
using Moq;
using NUnit.Framework;
using PackageManager.Enums;
using PackageManager.Models;
using PackageManager.Models.Contracts;
using PackageManager.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PackageManager.Tests.Repositories
{
    [TestFixture]
    public class PackageRepositoryDeleteMethodTests
    {

        [Test]
        public void ThrowArgumentNullExceptionIfPassedPackageIsNull_WhenDeleteMethodIsCalled()
        {
            var mockedLogger = new Mock<Info.Contracts.ILogger>();
            var packageRepository = new PackageRepository(mockedLogger.Object);

            Assert.Throws<ArgumentNullException>(() => packageRepository.Delete(null));
        }

        [Test]
        public void ReturnDeletedPackage_WhenDeleteMethodIsCalled()
        {
            var mockedVersion = new Mock<IVersion>();

            mockedVersion.Setup(x => x.Major).Returns(2);
            mockedVersion.Setup(x => x.Minor).Returns(2);
            mockedVersion.Setup(x => x.Patch).Returns(2);
            mockedVersion.Setup(x => x.VersionType).Returns(VersionType.alpha);

            var package = new Package("PackageName", mockedVersion.Object);

            var mockedLogger = new Mock<Info.Contracts.ILogger>();
            var packageRepository = new PackageRepository(mockedLogger.Object, new List<IPackage>() { package });

            Assert.AreEqual(package, packageRepository.Delete(package));
        }
    }
}
