﻿using Castle.Core.Logging;
using Moq;
using NUnit.Framework;
using PackageManager.Models.Contracts;
using PackageManager.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PackageManager.Tests.Repositories
{
    [TestFixture]
    public class PackageRepositoryUpdateMethodTests
    {

        [Test]
        public void ThrowArgumentNullExceptionIfPassedPackageIsNull_WhenUpdateMethodIsCalled()
        {
            var mockedLogger = new Mock<Info.Contracts.ILogger>();
            var packageRepository = new PackageRepository(mockedLogger.Object);

            Assert.Throws<ArgumentNullException>(() => packageRepository.Update(null));
        }
    }
}