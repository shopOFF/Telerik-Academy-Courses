const connectionString = 'mongodb://localhost:27017/superheroes-ws';
const port = 3001;

module.exports = {
  connectionString,
  port
};