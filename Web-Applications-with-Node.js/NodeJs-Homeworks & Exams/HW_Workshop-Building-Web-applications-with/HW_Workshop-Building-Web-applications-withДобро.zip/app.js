/* globals require */

'use strict';

const models = require('./models');
const config = require('./config');
const data = require('./data')(config, models);

let powers = [{ name: 'Flying' }, { name: 'Crawling' }];
let city = {
    name: 'Den Ksero',
    country: {
        name: 'USA',
        planet: {
            name: 'Earth'
        }
    }
};


data.createSuperhero('Spiderman', 'Peter Parker', 'good', 'Yadee yadee ya', powers, city)
    .then(console.log)
    .catch(console.log);