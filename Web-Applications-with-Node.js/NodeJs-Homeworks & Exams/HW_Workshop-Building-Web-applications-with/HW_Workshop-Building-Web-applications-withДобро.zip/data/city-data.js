/* globals module */

'use strict';

module.exports = function (models) {
    return {
        getAllCities() {
            return new Promise((resolve, reject) => {
                return models.city.find((err, res) => {
                    if (err) {
                        return reject(err);
                    }

                    return resolve(res);
                });
            });
        },
        createCity(cityName, countryName, planetName) {
            let planet;
            models.planet.find((err, res) => {
                if (err) {
                    throw err;
                }

                if (res) {
                    planet = {
                        name: res.name,
                        planetId: res._id
                    };
                }
                else {
                    let planet = new models.planet({
                        name: planetName
                    });

                    planet.save((innerErr, savedPlanet) => {
                        if (innerErr) {
                            throw innerErr;
                        }

                        planet = {
                            name: savedPlanet.name,
                            planetId: savedPlanet._id
                        };
                    });
                }
            });

            let city;
            models.country.find({ name: countryName }, (err, res) => {
                if (err) {
                    throw err;
                }

                if (res) {
                    city = new models.city({
                        name: cityName,
                        country: {
                            name: countryName,
                            countryId: res._id,
                            planet: planet
                        }
                    });
                }
                else {
                    let country = new models.country({
                        name: planetName,
                        planet: planet
                    });

                    country.save((innerErr, savedCountry) => {
                        if (innerErr) {
                            throw innerErr;
                        }

                        city = new models.city({
                            name: cityName,
                            country: {
                                name: savedCountry.name,
                                countryId: savedCountry._id,
                                planet: planet
                            }
                        });
                    });
                }
            });

            return new Promise((resolve, reject) => {
                city.save((err, res) => {
                    if (err) {
                        return reject(err);
                    }

                    return resolve(res);
                });
            });
        }
    };
};