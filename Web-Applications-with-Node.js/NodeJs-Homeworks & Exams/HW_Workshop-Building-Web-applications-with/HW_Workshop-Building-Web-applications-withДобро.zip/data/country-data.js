/* globals module */

'use strict';

module.exports = function (models) {
    return {
        getAllCountries() {
            return new Promise((resolve, reject) => {
                return models.country.find((err, res) => {
                    if (err) {
                        return reject(err);
                    }

                    return resolve(res);
                });
            });
        },
        createCountry(countryName, planetName) {
            let country;
            models.planet.find({ name: planetName }, (err, res) => {
                if (err) {
                    throw err;
                }

                if (res) {
                    country = new models.country({
                        name: countryName,
                        planet: {
                            name: res.name,
                            planetId: res._id
                        }
                    });
                }
                else {
                    let planet = new models.planet({
                        name: planetName
                    });

                    planet.save((innerErr, savedPlanet) => {
                        if (innerErr) {
                            throw innerErr;
                        }

                        country = new models.country({
                            name: countryName,
                            planet: {
                                name: savedPlanet.name,
                                planetId: savedPlanet._id
                            }
                        });
                    });
                }
            });

            return new Promise((resolve, reject) => {
                country.save((err, res) => {
                    if (err) {
                        return reject(err);
                    }

                    return resolve(res);
                });
            });
        }
    };
};