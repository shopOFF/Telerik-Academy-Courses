/* globals module */

'use strict';

module.exports = function (models) {
    return {
        getAllPlanets() {
            return new Promise((resolve, reject) => {
                return models.planet.find((err, res) => {
                    if (err) {
                        return reject(err);
                    }

                    return resolve(res);
                });
            });
        },
        createPlanet(name) {
            let planet = new models.planet(
                name
            );

            return new Promise((resolve, reject) => {
                planet.save((err, res) => {
                    if (err) {
                        return reject(err);
                    }

                    return resolve(res);
                });
            });
        }
    };
};