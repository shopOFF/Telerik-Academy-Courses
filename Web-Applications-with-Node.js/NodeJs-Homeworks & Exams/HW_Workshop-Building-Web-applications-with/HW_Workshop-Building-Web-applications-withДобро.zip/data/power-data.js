/* globals module */

'use strict';

module.exports = function (models) {
    return {
        getAllPowers() {
            return new Promise((resolve, reject) => {
                return models.power.find((err, res) => {
                    if (err) {
                        return reject(err);
                    }

                    return resolve(res);
                });
            });
        },
        createPower(name) {
            let power = new models.power(
                name
            );

            return new Promise((resolve, reject) => {
                power.save((err, res) => {
                    if (err) {
                        return reject(err);
                    }

                    return resolve(res);
                });
            });
        }
    };
};