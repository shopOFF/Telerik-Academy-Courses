/* globals module */

'use strict';

module.exports = function(models) {
    return {
        getAllSuperheroes() {
            return new Promise((resolve, reject) => {
                models.superheroes.find((err, superheroes) => {
                    if (err) {
                        return reject(err);
                    }

                    return resolve(superheroes);
                });
            });
        },

        // TODO: implement the fracttions relation
        createSuperhero(name, secretIdentity, alignment, story, powers, city, imageUrl) {
            let dbPowers = [];

            powers.forEach(power => {
                models.power.findOne({ name: power.name }, (err, res) => {
                    if (err) {
                        throw err;
                    }

                    if (res) {
                        let newPower = {
                            name: res.name,
                            powerId: res._id
                        };

                        dbPowers.push(newPower);
                    }
                    else {
                        let powerToAdd = new models.power({
                            name: power
                        });

                        powerToAdd.save((innerErr, savedPower) => {
                            if (innerErr) {
                                throw innerErr;
                            }

                            dbPowers.push({
                                name: savedPower.name,
                                powerId: savedPower._id
                            });
                        });
                    }
                });
            });

            let superhero = new models.superhero({
                name,
                secretIdentity,
                alignment,
                story,
                powers,
                city,
                imageUrl,
               // fractions
            });

            return new Promise((resolve, reject) => {
                superhero.save((err, hero) => {
                    if (err) {
                        return reject(err);
                    }

                    return resolve(hero);
                });
            });
        }
    };
};