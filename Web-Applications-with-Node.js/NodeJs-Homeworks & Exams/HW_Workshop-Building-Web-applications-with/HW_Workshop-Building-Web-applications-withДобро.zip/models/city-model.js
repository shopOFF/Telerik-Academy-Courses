/* globals require module */

'use strict';

const mongoose = require('mongoose'),
    Schema = mongoose.Schema,
    validator = require('./validator');

let schema = new Schema({
    name: {
        type: String,
        required: true,
        validate: (value) => validator.stringLength(value, 2, 30),
        unique: true
    }
});

mongoose.model('City', schema);
let City = mongoose.model('City');

module.exports = City;