/* globals require module */

'use strict';

const mongoose = require('mongoose'),
    Schema = mongoose.Schema,
    validator = require('./validator');

let alignments = ['good', 'evil', 'neutral'];
let schema = new Schema({
    name: {
        type: String,
        required: true,
        validate: (value) => validator.stringLength(value, 2, 30),
        unique: true
    },
    alignments: {
        type: String,
        required: true,
        enum: alignments
    },
    superheroes: {
        type: [{
            name: String,
            heroId: Schema.Types.ObjectId
        }]
    },
    planets: {
        type: [{
            name: String,
            planetId: Schema.Types.ObjectId
        }]
    }
});

mongoose.model('Fraction', schema);
let Fraction = mongoose.model('Fraction');

module.exports = Fraction;