/* globals require module */

'use strict';

module.exports = {
    superhero: require('./superhero-model'),
    city: require('./city-model'),
    country: require('./country-model'),
    planet: require('./planet-model'),
    power: require('./power-model'),
    fraction: require('./fraction-model')
};