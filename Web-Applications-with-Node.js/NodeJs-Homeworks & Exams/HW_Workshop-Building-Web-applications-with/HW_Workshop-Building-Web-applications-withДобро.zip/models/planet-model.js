/* globals require module */

'use strict';

const mongoose = require('mongoose'),
    Schema = mongoose.Schema,
    validator = require('./validator');

let schema = new Schema({
    name: {
        type: String,
        required: true,
        validate: (value) => validator.stringLength(value, 2, 30),
        unique: true
    }
});

mongoose.model('Planet', schema);
let Planet = mongoose.model('Planet');

module.exports = Planet;