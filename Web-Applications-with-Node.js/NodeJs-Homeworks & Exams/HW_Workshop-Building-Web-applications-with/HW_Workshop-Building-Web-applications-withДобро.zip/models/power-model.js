/* globals require module */

'use strict';

const mongoose = require('mongoose'),
    Schema = mongoose.Schema,
    validator = require('./validator');

let schema = new Schema({
    name: {
        type: String,
        required: true,
        validate: (value) => validator.stringLength(value, 4, 35),
        unique: true
    }
});

mongoose.model('Power', schema);
let Power = mongoose.model('Power');

module.exports = Power;