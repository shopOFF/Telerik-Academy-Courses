/* globals module require */

'use strict';

const mongoose = require('mongoose'),
    Schema = mongoose.Schema,
    validator = require('./validator');

let alignments = ['good', 'evil', 'neutral'];
let schema = new Schema({
    name: {
        type: String,
        required: true,
        validate: (value) => validator.stringLength(value, 2, 30)
    },
    secretIdentity: {
        type: String,
        required: true,
        validate: (value) => validator.stringLength(value, 2, 60),
        unique: true
    },
    alignment: {
        type: String,
        required: true,
        enum: alignments
    },
    story: {
        type: String,
        required: true,
        validate: (value) => validator.stringLength(value, 1, 1000)
    },
    powers: {
        type: [{
            name: {
                type: String,
                required: true
            },
            powerId: Schema.Types.ObjectId
        }],
        required: true
    },
    city: {
        name: {
            type: String,
            required: true,
            validate: (value) => validator.stringLength(value, 2, 30)
        },
        cityId: Schema.Types.ObjectId,
        country: {
            name: {
                type: String,
                required: true,
                validate: (value) => validator.stringLength(value, 2, 30)
            },
            countryId: Schema.Types.ObjectId,
            planet: {
                name: {
                    type: String,
                    required: true,
                    validate: (value) => validator.stringLength(value, 2, 30)
                },
                planetId: {
                    type: Schema.Types.ObjectId
                }
            }
        }
    },
    imageUrl: {
        type: String,
        default: 'http://www.flickfilosopher.com/wptest/wp-content/uploads/2012/11/unknownsuperhero.gif'
    },
    fractions: {
        type: [{
            name: {
                type: String,
                required: true
            },
            fractionId: Schema.Types.ObjectId
        }]
    }
});

mongoose.model('Superhero', schema);
let Superhero = mongoose.model('Superhero');

module.exports = Superhero;