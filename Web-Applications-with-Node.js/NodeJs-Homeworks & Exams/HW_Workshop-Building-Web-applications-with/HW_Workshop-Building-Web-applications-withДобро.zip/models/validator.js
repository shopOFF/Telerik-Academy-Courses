/* globals module */

'use strict';

module.exports = {
    stringLength(str, minLength, maxLength) {
        return str.length >= minLength && str.length <= maxLength;
    }
};